# Dummy file to make this directory a package.
import service as serialzone