#python /media/hdd/ipkg-tools/zip2ipk.py gp-setting-sat-pauk-07.0w_08032019_all.zip 

import os,sys,shutil
zipfile=sys.argv[1]##gp-setting-sat-pauk-13.0e_190123-r0_all.zip
print "zipfile",zipfile
#sys.exit()
try:option=sys.argv[2]
except:option=''
package=zipfile.replace(".zip","") #gp-setting-sat-pauk-13.0e
package_name=package.split("_")[0]
try:package_version=package.split("_")[1]#08-3-2019
except:package_version="1.0"
try:package_description=sys.argv[2]
except:package_description=package_name

ipkg_tools_dir='/media/hdd/ipkg-tools/'
package_dir=zipfile[:-4]
control_dir=package_dir+"/CONTROL"
control_file=package_dir+"/CONTROL/control"
preinst_file=package_dir+"/CONTROL/preinst"
postinst_file=package_dir+"/CONTROL/postinst"
ipkfile=package+"_all.ipk"
def deflatezip():
            if not os.path.exists(package_dir):
                   print "package_dir is not present,created ",package_dir
                  
                   os.mkdir(package_dir)
            else:
                   
                   shutil.rmtree("/media/hdd/ipkg-tools/"+package_dir)
                   os.mkdir(package_dir)
                   print "package_dir is  present,deleted and created ",package_dir
                   
            destination = package_dir
           
           
            cmd =  ' unzip -o ' + "/tmp/"+zipfile + ' -d ' + destination 
            ret=os.popen(cmd).read()
            print "ret",ret
            return ret
def createcontrol_file():
        
         
            
            if not os.path.exists(control_dir):
                   os.mkdir(control_dir)
                
            cfile=open(control_file,"w")
            package_line='Package: %s'%package_name
            cfile.write(package_line)
            version_line='Version: %s'%package_version
            cfile.write("\n"+version_line)
            description_line='Description: %s'%package_description
            cfile.write("\n"+description_line)
            
           
            cfile.write("\n"+'Architecture: all')

            section_line='Section: eigma2'
            cfile.write("\n"+section_line)


            priority_line='Priority: optional'
            cfile.write("\n"+priority_line)

            maintainer_line='Maintainer: tunisia_sat'
            cfile.write("\n"+maintainer_line)

            homePage_line='HomePage: http://tunisia_sat'
            cfile.write("\n"+homePage_line)

            source_line='Source: http://tunisia_sat'
            cfile.write("\n"+source_line+"\n")
            cfile.close()
            os.chmod(control_file,755)
            

def createpreinst_file():
                   
            cfile=open(preinst_file,"w")
            rmsaatxml_line='#!/bin/sh\nrm -rf /etc/tuxbox/satellites.xml > /dev/null 2>&1\nexit 0'
            cfile.write(rmsaatxml_line)
            cfile.close()
            os.chmod(preinst_file,755)
            print "preinst file created"

            
def createpostinst_file():
  
                
            cfile=open(postinst_file,"w")
            load_line='#!/bin/sh\nwget -q -O - http://127.0.0.1/web/servicelistreload?mode=0\nexit 0'
            cfile.write(load_line)
            cfile.close()
            os.chmod(postinst_file,755)
            print "postinst file created"

                
def createipk_file():
    #os.chdir('/tmp')
    cmd="/media/hdd/ipkg-tools/ipkg-build %s"%package_dir
    print "cmd",cmd
    ret=os.popen(cmd).read()
    shutil.rmtree("/media/hdd/ipkg-tools/"+package_dir)
    shutil.move("/media/hdd/ipkg-tools/"+ipkfile, "/tmp/"+ipkfile)
    if option=='':
       os.remove("/media/hdd/ipkg-tools/"+zipfile)
    #os.remove("/media/hdd/ipkg-tools/ipkg-build/"+ipkfile)
    print ret
    print "/tmp/"+ipkfile+" created successfully"
            
                      
def start():

    ret=deflatezip()
    print ret
                                  
    ret=createcontrol_file()
    #createpreinst_file()
    #createpostinst_file()
    createipk_file()
    
start()    
    
