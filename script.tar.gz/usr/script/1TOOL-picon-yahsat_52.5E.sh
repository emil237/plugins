wget https://raw.githubusercontent.com/emil237/picon-yahsat/main/installer.sh -qO - | /bin/sh 















