wget https://raw.githubusercontent.com/emil237/quran/main/installer.sh -qO - | /bin/sh

