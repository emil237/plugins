opkg install --force-overwrite /tmp/*.ipk
wait
sleep 2;
exit 0
