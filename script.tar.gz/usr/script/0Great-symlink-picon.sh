z="
";Dz='/hdd';Iz='e/en';Bz='s /m';Jz='igma';Az='ln -';Kz='2';Hz='shar';Cz='edia';Gz='usr/';Fz='on /';Ez='/pic';Lz='exit';
eval "$Az$Bz$Cz$Dz$Ez$Fz$Gz$Hz$Iz$Jz$Kz$z$Lz"