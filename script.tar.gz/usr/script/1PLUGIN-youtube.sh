wget https://raw.githubusercontent.com/emil237/YouTube/main/installer.sh -qO - | /bin/sh

