#!/bin/sh
 # 
 # # 
# remove old plugin #
opkg remove enigma2-plugin-extensions-xtraevent
wait
rm -rf /usr/lib/enigma2/python/Plugins/Extensions/xtraEvent/

wait
echo "Ok Removed Old Plugin"

#################################################################################

# Download and install plugin #
echo " DOWNLOAD AND INSTALL PLUGIN "
cd /tmp
set -e 
wget "https://raw.githubusercontent.com/emil237/plugins/main/xtraevent-v4.6.tar.gz"
wait
tar -xzf xtraevent-v4.6.tar.gz  -C /
wait
cd ..
set +e
rm -f /tmp/xtraevent-v4.6.tar.gz
echo "   UPLOADED BY  >>>>   EMIL_NABIL "   
sleep 4;                                                                                                                  
echo "**********************************************************************************"
wait
exit 0








