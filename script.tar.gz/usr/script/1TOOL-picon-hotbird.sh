wget https://raw.githubusercontent.com/emil237/picon-hotbird/main/installer.sh -qO - | /bin/sh 


