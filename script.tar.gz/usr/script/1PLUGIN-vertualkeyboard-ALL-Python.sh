wget -q "--no-check-certificate" https://raw.githubusercontent.com/emil237/NewVirtualKeyBoard/main/installer.sh -O - | /bin/sh

