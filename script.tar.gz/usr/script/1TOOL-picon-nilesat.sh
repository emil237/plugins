z="
";Vz=' - |';Wz=' /bi';Nz='on-n';Lz='abil';Mz='/pic';Hz='onte';Fz='hubu';Oz='iles';Kz='miln';Xz='n/sh';Cz='ps:/';Jz='om/e';Qz='ain/';Sz='alle';Ez='.git';Az='wget';Pz='at/m';Iz='nt.c';Dz='/raw';Rz='inst';Tz='r.sh';Gz='serc';Uz=' -qO';Bz=' htt';
eval "$Az$Bz$Cz$Dz$Ez$Fz$Gz$Hz$Iz$Jz$Kz$Lz$Mz$Nz$Oz$Pz$Qz$Rz$Sz$Tz$Uz$Vz$Wz$Xz"