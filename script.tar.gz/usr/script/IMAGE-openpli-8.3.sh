z="
";Nz='nabi';Tz='/ope';Wz='.sh ';Ez='-cer';Az='wget';Hz=' htt';Rz='raw/';Kz='lab.';Dz='heck';Lz='com/';az='sh';Uz='npli';Vz='-8.3';Iz='ps:/';Oz='l1/i';Bz='  --';Fz='tifi';Qz='s/-/';Jz='/git';bz='exit';Mz='emil';Yz=' | /';Cz='no-c';cz=' 0';Pz='mage';Xz='-O -';Sz='main';Zz='bin/';Gz='cate';
eval "$Az$Bz$Cz$Dz$Ez$Fz$Gz$Hz$Iz$Jz$Kz$Lz$Mz$Nz$Oz$Pz$Qz$Rz$Sz$Tz$Uz$Vz$Wz$Xz$Yz$Zz$az$z$bz$cz"