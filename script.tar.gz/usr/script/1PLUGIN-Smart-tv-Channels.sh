wget -q "--no-check-certificate" https://raw.githubusercontent.com/emil237/smart-tv-channels/main/installer.sh -O - | /bin/sh


