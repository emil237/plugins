#!/bin/sh

dispositvo="hdd"
dias="7"

echo "########################################"
echo "# del history xtravent bosters....#"
echo "########################################"

find /media/$dispositvo/xtraEvent/poster/ -type f -mtime +$dias -delete
find /media/$dispositvo/xtraEvent/banner/ -type f -mtime +$dias -delete
find /media/$dispositvo/xtraEvent/backdrop/ -type f -mtime +$dias -delete
wait
sleep ;2
exit





