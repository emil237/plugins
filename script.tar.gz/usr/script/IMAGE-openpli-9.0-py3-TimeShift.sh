wget  --no-check-certificate https://gitlab.com/emilnabil1/images-timeshift/-/raw/main/openpli-9.0-py3-TimeShift.sh -O - | /bin/sh
exit 0
