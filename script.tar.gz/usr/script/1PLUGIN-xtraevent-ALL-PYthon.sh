wget https://raw.githubusercontent.com/emil237/xtraevent/main/installer.sh -O - | /bin/sh



