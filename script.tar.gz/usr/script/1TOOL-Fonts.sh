wget https://raw.githubusercontent.com/emil237/fonts/main/installer.sh -qO - | /bin/sh 













