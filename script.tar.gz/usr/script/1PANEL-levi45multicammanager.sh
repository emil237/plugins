z="
";Lz='37/l';Jz='om/e';Qz='ager';Yz='in/s';Sz='n/in';Wz='O - ';Pz='mman';Gz='serc';Vz='sh -';Iz='nt.c';Kz='mil2';Oz='tica';Fz='hubu';Bz=' htt';Hz='onte';Mz='evi4';Rz='/mai';Nz='5mul';Zz='h';Xz='| /b';Uz='ler.';Az='wget';Ez='.git';Cz='ps:/';Tz='stal';Dz='/raw';
eval "$Az$Bz$Cz$Dz$Ez$Fz$Gz$Hz$Iz$Jz$Kz$Lz$Mz$Nz$Oz$Pz$Qz$Rz$Sz$Tz$Uz$Vz$Wz$Xz$Yz$Zz"