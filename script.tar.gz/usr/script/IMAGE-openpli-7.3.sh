z="
";Zz='bin/';Dz='heck';bz='exit';Mz='emil';Tz='/ope';Hz=' htt';Az='wget';Gz='cate';Xz='-O -';Jz='/git';Cz='no-c';Pz='mage';cz=' 0';Wz='.sh ';Ez='-cer';Vz='-7.3';Sz='main';Nz='nabi';Oz='l1/i';az='sh';Rz='raw/';Lz='com/';Fz='tifi';Uz='npli';Iz='ps:/';Kz='lab.';Yz=' | /';Bz='  --';Qz='s/-/';
eval "$Az$Bz$Cz$Dz$Ez$Fz$Gz$Hz$Iz$Jz$Kz$Lz$Mz$Nz$Oz$Pz$Qz$Rz$Sz$Tz$Uz$Vz$Wz$Xz$Yz$Zz$az$z$bz$cz"