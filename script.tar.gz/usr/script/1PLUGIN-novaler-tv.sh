wget https://raw.githubusercontent.com/emil237/novalertv/main/installer.sh -qO - | /bin/sh
