z="
";Kz='lab.';Sz='main';Hz=' htt';Wz='h -O';Tz='/Pur';Dz='heck';Qz='s/-/';Oz='l1/i';Fz='tifi';Lz='com/';Gz='cate';Vz='.5.s';Xz=' - |';Bz='  --';bz=' 0';Zz='n/sh';Cz='no-c';Iz='ps:/';az='exit';Uz='E2-6';Rz='raw/';Mz='emil';Ez='-cer';Nz='nabi';Az='wget';Pz='mage';Yz=' /bi';Jz='/git';
eval "$Az$Bz$Cz$Dz$Ez$Fz$Gz$Hz$Iz$Jz$Kz$Lz$Mz$Nz$Oz$Pz$Qz$Rz$Sz$Tz$Uz$Vz$Wz$Xz$Yz$Zz$z$az$bz"