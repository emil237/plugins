# Plugin by WooshMan for use with WooshBuild
# stuck for ideas? That's OK you can use mine.

from Plugins.Plugin import PluginDescriptor
import shutil
import os, random

screens = '/usr/lib/enigma2/python/Plugins/Extensions/BootLogoSwapper/bootlogos/'
logopath='/etc/enigma2/'
secondpath = '/usr/share/'


def autostart(reason, **kwargs):
	if os.path.exists (logopath+'bootlogo.mvi'):
		os.remove(logopath+'bootlogo.mvi')
	if os.path.exists (logopath+'backdrop.mvi'):
		os.remove(logopath+'backdrop.mvi')
	if os.path.exists (logopath+'bootlogo_wait.mvi'):
		os.remove(logopath+'bootlogo_wait.mvi')

	if os.path.exists (screens +'bootlogo1.mvi'):
		newscreen = random.choice(os.listdir(screens))
		final = screens+newscreen
		shutil.copy(final, secondpath +'bootlogo.mvi')
		shutil.copy(final, secondpath +'backdrop.mvi')
		

def Plugins(**kwargs):
 return PluginDescriptor(
   name="-Boot Logo Swap",
   description="Boot Logo Swapper",
   where = PluginDescriptor.WHERE_AUTOSTART,
   icon="/usr/lib/enigma2/python/Plugins/Extensions/BootLogoSwapper/images/plugin.png",
   fnc=autostart)

