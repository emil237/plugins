# 2017.01.31 12:23:05 Jerusalem Standard Time
#Embedded file name: /usr/lib/enigma2/python/Plugins/TSimage/TSimagePanel/Stools/TSsatEditor/__init__.py
pass
# okay decompyling G:\TSpanel\7.8\6\tsimageopentsimage\TSimage\TSimagePanel\Stools\TSsatEditor\__init__.pyo 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.01.31 12:23:05 Jerusalem Standard Time
