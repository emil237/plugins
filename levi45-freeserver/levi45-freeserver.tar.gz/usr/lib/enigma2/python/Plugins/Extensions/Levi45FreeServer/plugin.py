from Plugins.Plugin import PluginDescriptor
from .ui import Levi45FreeServerScreen
from .downloader import FreeServerDownloader
from Screens.MessageBox import MessageBox
from . import PLUGIN_VERSION  # Changed import location

def main(session, **kwargs):
    if kwargs.get('manual_update'):
        downloader = FreeServerDownloader()
        servers = downloader.download_sync()
        if servers:
            session.open(MessageBox, 
                f"Success! Found {len(servers)} servers (v{PLUGIN_VERSION})",
                MessageBox.TYPE_INFO)
        else:
            session.open(MessageBox,
                f"No servers found. Try again later (v{PLUGIN_VERSION})",
                MessageBox.TYPE_ERROR)
    else:
        session.open(Levi45FreeServerScreen)

def Plugins(**kwargs):
    return [
        PluginDescriptor(
            name=f"Levi45 Free Server (v{PLUGIN_VERSION})",
            description=f"Download CCcam servers (v{PLUGIN_VERSION})",
            where=PluginDescriptor.WHERE_PLUGINMENU,
            fnc=main,
            icon="plugin.png"
        ),
        PluginDescriptor(
            name=f"Levi45 Manual Update (v{PLUGIN_VERSION})",
            description=f"Force update server list (v{PLUGIN_VERSION})",
            where=PluginDescriptor.WHERE_EXTENSIONSMENU,
            fnc=lambda s, **k: main(s, manual_update=True)
        )
    ]