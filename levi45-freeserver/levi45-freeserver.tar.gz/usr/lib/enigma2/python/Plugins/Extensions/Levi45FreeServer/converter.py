import re
import logging
from os.path import join, exists
from os import makedirs

# Set up logging
LOG_FILE = '/tmp/levi45_converter.log'
logging.basicConfig(
    filename=LOG_FILE,
    level=logging.DEBUG,
    format='%(asctime)s - %(levelname)s - %(message)s'
)

class FreeServerToOscamConverter:
    def convert(self, server_lines):
        logging.info("Starting conversion to Oscam format")
        config = "# OSCam Server Configuration\n\n"
        server_count = 1
        n_line_count = 0
        c_line_count = 0
        
        for line in server_lines:
            try:
                line = line.strip()
                if not line or line.startswith('#'):
                    continue

                logging.debug(f"Processing line: {line}")

                # Handle N-lines (must start with N:)
                if line.upper().startswith('N:'):
                    # Strict N-line pattern: N: host port user pass deskey
                    match = re.match(r'^N:\s+([^\s]+)\s+(\d+)\s+([^\s]+)\s+([^\s]+)\s+([0-9a-fA-F\s]+)', line)
                    if match:
                        host = match.group(1)
                        port = match.group(2)
                        user = match.group(3)
                        pwd = match.group(4)
                        des_key = self._format_des_key(match.group(5))
                        
                        config += self._create_newcamd_reader(
                            server_count,
                            host,
                            port,
                            user,
                            pwd,
                            des_key
                        )
                        server_count += 1
                        n_line_count += 1
                        logging.info(f"Converted N-line: {host}:{port}")
                    else:
                        logging.warning(f"Invalid N-line format: {line[:50]}...")
                    continue

                # Handle C-lines (must start with C: or no prefix)
                if line.upper().startswith('C:') or re.match(r'^[^N:]\S+\s+\d+\s+\S+\s+\S+', line):
                    # Clean line and extract parts
                    clean_line = re.sub(r'<[^>]+>', '', line)  # Remove HTML
                    clean_line = re.sub(r'#.*$', '', clean_line).strip()
                    parts = clean_line.split()
                    
                    # Remove C: prefix if present
                    if parts[0].upper() == 'C:':
                        parts = parts[1:]
                    
                    if len(parts) >= 4:
                        config += self._create_cccam_reader(
                            server_count,
                            parts[0],  # host
                            parts[1],  # port
                            parts[2],  # user
                            parts[3]   # pass
                        )
                        server_count += 1
                        c_line_count += 1
                        logging.info(f"Converted C-line: {parts[0]}:{parts[1]}")
                    else:
                        logging.warning(f"Invalid C-line format: {line[:50]}...")
                    continue

                logging.warning(f"Unrecognized line format: {line[:50]}...")

            except Exception as e:
                logging.error(f"Error processing line '{line}': {str(e)}")

        logging.info(f"Conversion completed - {n_line_count} N-lines, {c_line_count} C-lines converted")
        return config

    def _format_des_key(self, key_input):
        """Format DES key as continuous 28-digit hex string"""
        # Remove all non-hex characters
        clean_key = re.sub(r'[^0-9a-fA-F]', '', key_input)
        
        # If we have at least 28 hex digits
        if len(clean_key) >= 28:
            return clean_key[:28].lower()
            
        # If we have exactly 14 numbers (01-14 format)
        if len(clean_key) == 14 and clean_key.isdigit():
            return clean_key.ljust(28, '0')
            
        # Default fallback - standard test key
        return "0102030405060708091011121314"

    def _create_cccam_reader(self, idx, host, port, user, pwd):
        return f"""[reader]
label = CCcam_{idx}
protocol = cccam
device = {host},{port}
user = {user}
password = {pwd}
group = 1
cccversion = 2.3.2
ccckeepalive = 1
cccreconnect = 1
audisabled = 1

"""

    def _create_newcamd_reader(self, idx, host, port, user, pwd, des_key):
        return f"""[reader]
label = Newcamd_{idx}
protocol = newcamd
device = {host},{port}
key = {des_key}
user = {user}
password = {pwd}
group = 1
emmcache = 1,3,2
blockemm-unknown = 1
blockemm-g = 1
audisabled = 1

"""

class FreeServerToNcamConverter(FreeServerToOscamConverter):
    def _create_newcamd_reader(self, idx, host, port, user, pwd, des_key):
        return f"""[reader]
label = Newcamd_{idx}
enable = 1
protocol = newcamd
device = {host},{port}
key = {des_key}
user = {user}
password = {pwd}
group = 1
emmcache = 1,3,2
blockemm-unknown = 1
blockemm-g = 1
audisabled = 1

"""