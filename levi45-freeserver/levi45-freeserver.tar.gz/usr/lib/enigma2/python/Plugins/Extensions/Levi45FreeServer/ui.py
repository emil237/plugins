from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
from Components.ActionMap import ActionMap
from Components.Sources.StaticText import StaticText
from Components.MenuList import MenuList
from Components.Button import Button
from Components.ProgressBar import ProgressBar
from .downloader import FreeServerDownloader
from .converter import FreeServerToOscamConverter
import threading
import requests
import re
import os
from . import PLUGIN_VERSION

class Levi45FreeServerScreen(Screen):
    skin = """
    <screen position="center,center" size="700,550" title="Levi45 Free Server v{version}">
        <widget name="progress" position="10,10" size="680,20" />
        <widget name="status" position="10,40" size="680,30" font="Regular;22" />
        <widget name="debug_info" position="10,80" size="680,100" font="Regular;18" foregroundColor="#FFA500" />
        <widget name="menu" position="10,190" size="680,310" scrollbarMode="showOnDemand" itemHeight="28" />
        <ePixmap name="red" position="10,510" size="160,40" pixmap="skin_default/buttons/red.png" zPosition="1" />
        <ePixmap name="green" position="190,510" size="160,40" pixmap="skin_default/buttons/green.png" zPosition="1" />
        <ePixmap name="yellow" position="370,510" size="160,40" pixmap="skin_default/buttons/yellow.png" zPosition="1" />
        <widget name="key_red" position="10,510" size="160,40" valign="center" halign="center" zPosition="2" font="Regular;20" transparent="1" foregroundColor="white" />
        <widget name="key_green" position="190,510" size="160,40" valign="center" halign="center" zPosition="2" font="Regular;20" transparent="1" foregroundColor="white" />
        <widget name="key_yellow" position="370,510" size="160,40" valign="center" halign="center" zPosition="2" font="Regular;20" transparent="1" foregroundColor="white" />
    </screen>
    """.format(version=PLUGIN_VERSION)

    def __init__(self, session):
        Screen.__init__(self, session)
        self.session = session
        self.downloader = FreeServerDownloader()
        self.server_lines = []
        self.is_downloading = False
        
        self["progress"] = ProgressBar()
        self["status"] = StaticText(f"Ready - Press GREEN to download (v{PLUGIN_VERSION})")
        self["debug_info"] = StaticText(f"Plugin version: {PLUGIN_VERSION}")
        self["menu"] = MenuList([])
        self["key_red"] = Button("Exit")
        self["key_green"] = Button("Download")
        self["key_yellow"] = Button("Convert")
        
        self["actions"] = ActionMap(["ColorActions", "OkCancelActions"], {
            "red": self.exit_plugin,
            "green": self.start_download,
            "yellow": self.convert_servers,
            "cancel": self.exit_plugin,
        }, -1)
        
        self.onLayoutFinish.append(self.setInitialFocus)

    def setInitialFocus(self):
        try:
            from enigma import eWidget
            self["key_green"].instance.setFocus(eWidget.FocusNext)
        except:
            try:
                self.setFocus(self["key_green"])
            except:
                pass

    def exit_plugin(self):
        if self.is_downloading:
            self.downloader.stop_download()
            self["status"].setText(f"Download stopped (v{PLUGIN_VERSION})")
        self.close()

    def start_download(self):
        if self.is_downloading:
            return
            
        self.is_downloading = True
        self.server_lines = []
        self["status"].setText(f"Downloading... (v{PLUGIN_VERSION})")
        self["debug_info"].setText(f"Plugin v{PLUGIN_VERSION}\nConnecting to sources...")
        self["progress"].setRange((0, 100))
        self["progress"].setValue(0)
        self["menu"].setList(["Starting download process"])
        self["key_green"].setText("Working...")

        def download_thread():
            try:
                servers = self.downloader.download_sync()
                self["progress"].setValue(100)
                
                if servers:
                    self.server_lines = servers
                    server_list = [f"{i+1}. {s.split()[1]}:{s.split()[2]}" for i, s in enumerate(servers)]
                    self["menu"].setList(server_list)
                    self["status"].setText(f"Found {len(servers)} servers (v{PLUGIN_VERSION})")
                    self["debug_info"].setText(f"Plugin v{PLUGIN_VERSION}\nFirst server: {servers[0]}\nLast server: {servers[-1]}")
                else:
                    self.show_error(f"No valid servers found (v{PLUGIN_VERSION})")
                    
            except Exception as e:
                self["debug_info"].setText(f"Plugin v{PLUGIN_VERSION}\nException: {str(e)}")
                self.show_error(f"Download failed: {str(e)} (v{PLUGIN_VERSION})")
            finally:
                self.is_downloading = False
                self["key_green"].setText("Download")
                self.setInitialFocus()

        threading.Thread(target=download_thread).start()

    def parse_github_servers(self, text):
        """Special parser for GitHub server format"""
        servers = []
        debug_info = []
        
        for line in text.split('\n'):
            line = line.strip()
            if not line or line.startswith('#'):
                continue
                
            patterns = [
                r'^(?:C:|c:)?\s*([\w.-]+)\s+(\d{1,5})\s+([\w]+)\s+([\w]+)',
                r'^([\w.-]+)\s+(\d{1,5})\s+([\w]+)\s+([\w]+)',
                r'^([\w.-]+):(\d{1,5})\s+([\w]+)\s+([\w]+)'
            ]
            
            matched = False
            for pattern in patterns:
                match = re.match(pattern, line)
                if match:
                    host, port, user, pwd = match.groups()
                    if self.validate_server(host, port):
                        servers.append(f"C: {host} {port} {user} {pwd}")
                        matched = True
                        break
            
            if not matched:
                debug_info.append(f"SKIPPED: {line[:40]}...")

        if debug_info:
            self["debug_info"].setText("\n".join([
                f"Plugin v{PLUGIN_VERSION}",
                f"Parsed {len(servers)} servers",
                f"Skipped {len(debug_info)} lines",
                debug_info[0] if debug_info else ""
            ]))
        
        return servers

    def validate_server(self, host, port):
        """Strict validation with debug"""
        if not host or not port:
            return False
        if not port.isdigit() or not 1 <= int(port) <= 65535:
            return False
        if any(x in host.lower() for x in ['example', 'test']):
            return False
        return True

    def show_debug_info(self, text):
        """Display raw content for debugging"""
        lines = text.split('\n')
        debug_lines = ["Last 5 lines of server file:"] + lines[-5:]
        self["menu"].setList(debug_lines)
        self["debug_info"].setText(f"Plugin v{PLUGIN_VERSION}\nFile length: {len(text)} chars")

    def show_error(self, message):
        self["status"].setText(message)
        self["menu"].setList([f"Error occurred - check debug info (v{PLUGIN_VERSION})"])

    def convert_servers(self):
        if not self.server_lines:
            self.show_error(f"No servers to convert (v{PLUGIN_VERSION})")
            return
            
        try:
            converter = FreeServerToOscamConverter()
            config = converter.convert(self.server_lines)
            
            oscam_path = "/etc/tuxbox/config/oscam.server"
            
            # Check if file exists and read existing content
            existing_content = ""
            try:
                if os.path.exists(oscam_path):
                    with open(oscam_path, "r") as f:
                        existing_content = f.read()
            except IOError as e:
                self.show_error(f"Error reading existing config: {str(e)} (v{PLUGIN_VERSION})")
                return
            
            # Determine write mode and prepare content
            if existing_content:
                # Remove any existing appended section to avoid duplicates
                existing_content = existing_content.split("# Appended by Levi45 Free Server")[0].strip()
                config = f"\n\n# Appended by Levi45 Free Server v{PLUGIN_VERSION}\n{config}"
                mode = "w"  # We'll rewrite the entire file
                full_content = f"{existing_content}{config}"
                message = f"Appended {len(self.server_lines)} servers to existing config (v{PLUGIN_VERSION})"
            else:
                full_content = config
                mode = "w"
                message = f"Created new config with {len(self.server_lines)} servers (v{PLUGIN_VERSION})"
            
            # Write to file
            try:
                with open(oscam_path, mode) as f:
                    f.write(full_content)
                
                self.session.open(
                    MessageBox,
                    message,
                    MessageBox.TYPE_INFO
                )
            except IOError as e:
                self.show_error(f"Error writing config: {str(e)} (v{PLUGIN_VERSION})")
                
        except Exception as e:
            self.show_error(f"Conversion failed: {str(e)} (v{PLUGIN_VERSION})")