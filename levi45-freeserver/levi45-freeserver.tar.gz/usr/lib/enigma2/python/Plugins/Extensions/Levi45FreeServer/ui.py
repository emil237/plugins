from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
from Components.ActionMap import ActionMap
from Components.Sources.StaticText import StaticText
from Components.MenuList import MenuList
from Components.Button import Button
from Components.ProgressBar import ProgressBar
from .downloader import FreeServerDownloader
from .converter import FreeServerToOscamConverter, FreeServerToNcamConverter
import threading
import requests
import re
import os
import time
from . import PLUGIN_VERSION

class Levi45FreeServerScreen(Screen):
    skin = """
    <screen position="center,center" size="700,550" title="Levi45 Free Server v{version}">
        <widget name="progress" position="10,10" size="680,20" />
        <widget name="status" position="10,40" size="680,30" font="Regular;22" />
        <widget name="debug_info" position="10,80" size="680,100" font="Regular;18" foregroundColor="#FFA500" />
        <widget name="menu" position="10,190" size="680,310" scrollbarMode="showOnDemand" itemHeight="28" />
        <ePixmap name="red" position="10,510" size="160,40" pixmap="skin_default/buttons/red.png" zPosition="1" />
        <ePixmap name="green" position="190,510" size="160,40" pixmap="skin_default/buttons/green.png" zPosition="1" />
        <ePixmap name="yellow" position="370,510" size="160,40" pixmap="skin_default/buttons/yellow.png" zPosition="1" />
        <ePixmap name="blue" position="550,510" size="160,40" pixmap="skin_default/buttons/blue.png" zPosition="1" />
        <widget name="key_red" position="10,510" size="160,40" valign="center" halign="center" zPosition="2" font="Regular;20" transparent="1" foregroundColor="white" />
        <widget name="key_green" position="190,510" size="160,40" valign="center" halign="center" zPosition="2" font="Regular;20" transparent="1" foregroundColor="white" />
        <widget name="key_yellow" position="370,510" size="160,40" valign="center" halign="center" zPosition="2" font="Regular;20" transparent="1" foregroundColor="white" />
        <widget name="key_blue" position="550,510" size="160,40" valign="center" halign="center" zPosition="2" font="Regular;20" transparent="1" foregroundColor="white" />
    </screen>
    """.format(version=PLUGIN_VERSION)

    def __init__(self, session):
        Screen.__init__(self, session)
        self.session = session
        self.downloader = FreeServerDownloader()
        self.server_lines = []
        self.is_downloading = False
        self.download_thread = None
        
        # Initialize UI components
        self["progress"] = ProgressBar()
        self["status"] = StaticText(f"Ready - Press GREEN to download (v{PLUGIN_VERSION})")
        self["debug_info"] = StaticText(f"Plugin version: {PLUGIN_VERSION}")
        self["menu"] = MenuList([])
        self["key_red"] = Button("Exit")
        self["key_green"] = Button("Download")
        self["key_yellow"] = Button("Oscam")
        self["key_blue"] = Button("Ncam")
        
        # Setup actions
        self["actions"] = ActionMap(["ColorActions", "OkCancelActions"], {
            "red": self.close,
            "green": self.start_download,
            "yellow": lambda: self.convert_servers('oscam'),
            "blue": lambda: self.convert_servers('ncam'),
            "cancel": self.close,
        }, -1)
        
        self.onLayoutFinish.append(self.set_initial_focus)

    def set_initial_focus(self):
        try:
            from enigma import eWidget
            self["key_green"].instance.setFocus(eWidget.FocusNext)
        except:
            try:
                self["key_green"].instance.setFocus(True)
            except:
                try:
                    self.setFocus(self["key_green"])
                except:
                    pass

    def start_download(self):
        if self.is_downloading:
            return
            
        self.is_downloading = True
        self.server_lines = []
        self["status"].setText(f"Downloading... (v{PLUGIN_VERSION})")
        self["debug_info"].setText("Starting download...")
        self["progress"].setRange((0, 100))
        self["progress"].setValue(0)
        self["menu"].setList(["Downloading server list..."])
        self["key_green"].setText("Working...")

        def download_task():
            try:
                # Use session for connection pooling
                session = requests.Session()
                adapter = requests.adapters.HTTPAdapter(
                    pool_connections=4,
                    pool_maxsize=4,
                    max_retries=2
                )
                session.mount('http://', adapter)
                session.mount('https://', adapter)

                total_sources = len(self.downloader.sources)
                servers = []
                
                for i, url in enumerate(self.downloader.sources):
                    if self.downloader.stop_flag:
                        break
                        
                    self["progress"].setValue(int((i/total_sources)*100))
                    self["debug_info"].setText(f"Downloading {i+1}/{total_sources}\n{url[:50]}...")
                    
                    try:
                        # Faster download without streaming
                        response = session.get(url, 
                                            headers=self.downloader.headers,
                                            timeout=5)
                        if response.status_code == 200:
                            found = self.downloader._parse_servers(response.text, url)
                            if found:
                                servers.extend(found)
                    except Exception as e:
                        continue
                        
                if servers and not self.downloader.stop_flag:
                    valid_servers = self.downloader._filter_valid_servers(servers)
                    self.server_lines = valid_servers
                    self.update_ui_with_servers()
                else:
                    self.show_error("No valid servers found or download stopped")
                    
            except Exception as e:
                self.show_error(f"Download error: {str(e)}")
            finally:
                self.download_cleanup()

        self.download_thread = threading.Thread(target=download_task, daemon=True)
        self.download_thread.start()

    def update_ui_with_servers(self):
        if not self.server_lines:
            self.show_error("No servers to display")
            return
            
        server_list = []
        max_display = 50  # Limit number of servers shown in menu
        for i, server in enumerate(self.server_lines[:max_display]):
            parts = server.split()
            if len(parts) >= 4:
                server_list.append(f"{i+1}. {parts[1]}:{parts[2]}")

        self["menu"].setList(server_list)
        self["status"].setText(f"Found {len(self.server_lines)} servers (v{PLUGIN_VERSION})")
        self["debug_info"].setText(
            f"First server: {self.server_lines[0][:50]}...\n"
            f"Last server: {self.server_lines[-1][:50]}..."
        )

    def download_cleanup(self):
        self.is_downloading = False
        self["progress"].setValue(0)
        self["key_green"].setText("Download")
        self.set_initial_focus()

    def show_error(self, message):
        self["status"].setText(message)
        self["menu"].setList(["Error - check debug info"])
        self["debug_info"].setText(f"{message}\nPress GREEN to retry")

    def convert_servers(self, server_type='oscam'):
        if not self.server_lines:
            self.show_error("No servers to convert")
            return
            
        try:
            if server_type == 'oscam':
                converter = FreeServerToOscamConverter()
                config_path = "/etc/tuxbox/config/oscam.server"
                section_header = "# BEGIN Levi45 Free Server Section"
                section_footer = "# END Levi45 Free Server Section"
            else:
                converter = FreeServerToNcamConverter()
                config_path = "/etc/tuxbox/config/ncam.server"
                section_header = "# BEGIN Levi45 Free Server Section"
                section_footer = "# END Levi45 Free Server Section"

            # Generate new config section
            new_section = (
                f"\n{section_header} v{PLUGIN_VERSION}\n"
                f"{converter.convert(self.server_lines)}\n"
                f"{section_footer}\n"
            )
            
            # Read existing config if it exists
            existing_content = ""
            if os.path.exists(config_path):
                with open(config_path, "r") as f:
                    existing_content = f.read()
            
            # Remove old section if it exists
            start_idx = existing_content.find(section_header)
            end_idx = existing_content.find(section_footer, start_idx) if start_idx != -1 else -1
            
            if start_idx != -1 and end_idx != -1:
                # Remove the old section including markers
                existing_content = (
                    existing_content[:start_idx].rstrip() + 
                    "\n" +
                    existing_content[end_idx + len(section_footer):].lstrip()
                )
            
            # Combine existing content with new section
            full_content = existing_content.strip() + new_section
            
            # Ensure directory exists
            os.makedirs(os.path.dirname(config_path), exist_ok=True)
            
            # Write config file
            with open(config_path, "w") as f:
                f.write(full_content)
                
            self.session.open(
                MessageBox,
                f"Successfully updated {len(self.server_lines)} servers in {server_type} config",
                MessageBox.TYPE_INFO
            )
        except Exception as e:
            self.show_error(f"Conversion failed: {str(e)}")

    def close(self):
        if self.is_downloading:
            self.downloader.stop_download()
            if self.download_thread and self.download_thread.is_alive():
                self.download_thread.join(1.0)
        Screen.close(self)