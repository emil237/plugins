import re
import requests
import threading
from queue import Queue

class FreeServerDownloader:
    def __init__(self):
        self.sources = [
            "https://raw.githubusercontent.com/levi-45/free-cccam/main/servers.txt",
            "https://cccam.net/freecccam",
            "https://cccamfree48h.yolasite.com/server-2.php",
            "https://cccam-premium.pro/free-cccam/"
        ]
        self.timeout = 15
        self.stop_flag = False
        self.headers = {
            'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
        }

    def download_sync(self):
        self.stop_flag = False
        result_queue = Queue()
        threads = []

        for url in self.sources:
            if self.stop_flag:
                break
            thread = threading.Thread(target=self._fetch_servers, args=(url, result_queue))
            thread.start()
            threads.append(thread)

        for thread in threads:
            thread.join(timeout=20)

        servers = []
        while not result_queue.empty():
            servers.extend(result_queue.get())

        return self._filter_valid_servers(servers)  # Return ALL valid servers

    def _fetch_servers(self, url, queue):
        try:
            response = requests.get(url, headers=self.headers, timeout=self.timeout)
            if response.status_code == 200:
                servers = self._parse_servers(response.text, url)
                if servers:
                    queue.put(servers)
        except Exception as e:
            print(f"Error fetching {url}: {str(e)}")

    def _parse_servers(self, text, url):
        text = text.replace('\r\n', '\n').replace('\r', '\n')
        
        if "github.com" in url:
            return self._parse_github_format(text)
        elif "cccamgate.com" in url:
            return self._parse_cccamgate_format(text)
        else:
            return self._parse_generic_format(text)

    def _parse_github_format(self, text):
        servers = []
        for line in text.split('\n'):
            line = line.strip()
            if not line or line.startswith('#'):
                continue
            for pattern in [
                r'^(?:C:|c:)?\s*([\w.-]+)[:\s]+(\d{2,5})\s+([^\s]+)\s+([^\s]+)',
                r'^([\w.-]+):(\d{2,5})\s+([^\s]+)\s+([^\s]+)'
            ]:
                match = re.match(pattern, line)
                if match:
                    host, port, user, pwd = match.groups()
                    if self._is_valid_server(host, port):
                        servers.append(f"C: {host} {port} {user} {pwd}")
                    break
        return servers  # Return ALL servers from this source

    def _parse_cccamgate_format(self, text):
        servers = []
        for match in re.finditer(
            r'<tr>.*?<td>([\w.-]+)</td>.*?<td>(\d+)</td>.*?<td>([^<]+)</td>.*?<td>([^<]+)</td>',
            text,
            re.DOTALL
        ):
            host, port, user, pwd = match.groups()
            if self._is_valid_server(host, port):
                servers.append(f"C: {host} {port} {user} {pwd}")
        return servers  # Return ALL servers from this source

    def _parse_generic_format(self, text):
        servers = []
        for match in re.finditer(
            r'(?:C:|c:)?\s*([\w.-]+)[:\s]+(\d{2,5})\s+([^\s]+)\s+([^\s]+)',
            text
        ):
            host, port, user, pwd = match.groups()
            if self._is_valid_server(host, port):
                servers.append(f"C: {host} {port} {user} {pwd}")
        return servers  # Return ALL servers from this source

    def _is_valid_server(self, host, port):
        if not host or not port:
            return False
        if not port.isdigit() or not 1000 <= int(port) <= 65535:
            return False
        invalid_terms = ['example', 'test', 'dummy', 'your']
        if any(term in host.lower() for term in invalid_terms):
            return False
        return True

    def _filter_valid_servers(self, servers):
        seen = set()
        unique = []
        for server in servers:
            if server not in seen:
                seen.add(server)
                unique.append(server)
        return unique  # Return ALL unique servers

    def stop_download(self):
        self.stop_flag = True
