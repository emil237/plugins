# __init__.py
from .converter import FreeServerToOscamConverter, FreeServerToNcamConverter
PLUGIN_VERSION = "1.2"
