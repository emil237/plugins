# __init__.py
PLUGIN_VERSION = "1.1"
