# -*- coding: utf-8 -*-
"""Manual CCcamIPTV trial request. No automatic retries or limit bypass."""
import json
import os
import re
import shutil
import tempfile
import time
try:
    from urllib.request import Request, build_opener, HTTPCookieProcessor
    from urllib.parse import urlencode
    from http.cookiejar import MozillaCookieJar
except ImportError:
    from urllib2 import Request, build_opener, HTTPCookieProcessor
    from urllib import urlencode
    from cookielib import MozillaCookieJar

PAGE = 'https://cccamiptv.tv/cccamfree-24h/'
ENDPOINT = 'https://cccamiptv.tv/wp-admin/admin-ajax.php'
BEGIN = '# >>> Levi45 CCcamIPTV manual trial >>>'
END = '# <<< Levi45 CCcamIPTV manual trial <<<'


def request_trial(cookie_path):
    jar = MozillaCookieJar(cookie_path)
    if os.path.exists(cookie_path):
        jar.load(ignore_discard=True)
    opener = build_opener(HTTPCookieProcessor(jar))
    opener.addheaders = [('User-Agent', 'Levi45FreeServer/3.2.1')]
    response = opener.open(PAGE, timeout=30)
    try:
        page = response.read(2 * 1024 * 1024).decode('utf-8')
    finally:
        response.close()
    button = re.search(r'<button\b[^>]*\bgen-start\b[^>]*>', page, re.I)
    token = re.search(r'data-nonce=[\"\']([A-Za-z0-9]+)[\"\']', button.group(0)) if button else None
    if not token:
        raise ValueError('Trial form unavailable. Open the provider website to check it.')
    body = urlencode({'action': 'cit_free_cline', 'nonce': token.group(1)}).encode('ascii')
    response = opener.open(Request(ENDPOINT, data=body, headers={
        'Content-Type': 'application/x-www-form-urlencoded', 'Referer': PAGE}), timeout=30)
    try:
        result = json.loads(response.read(65536).decode('utf-8'))
    finally:
        response.close()
    jar.save(ignore_discard=True)
    os.chmod(cookie_path, 0o600)
    data = result.get('data') or {}
    if not result.get('success'):
        message = data.get('message') if isinstance(data, dict) else None
        raise ValueError(message or 'Provider declined the trial request.')
    line = data.get('cccam', '').strip()
    if not re.match(r'^C:\s+[A-Za-z0-9._-]+\s+[0-9]{1,5}\s+[^\s]+\s+[^\s]+$', line):
        raise ValueError('Provider returned an invalid C-line.')
    if not 1 <= int(line.split()[2]) <= 65535:
        raise ValueError('Provider returned an invalid port.')
    return line


def save_trial(path, content, provider="cccamiptv"):
    """Replace only our trial block, retaining other readers and a backup."""
    names = {"cccamiptv": "CCcamIPTV", "fullpackage": "FullPackage", "dhoom": "Dhoom", "ninja": "CCcamNinja", "testcline": "Testcline"}
    name = names[provider]
    begin = "# >>> Levi45 {} manual trial >>>".format(name)
    end = "# <<< Levi45 {} manual trial <<<".format(name)
    old = ''
    if os.path.exists(path):
        with open(path, 'r') as handle:
            old = handle.read()
    if old.count(begin) != old.count(end) or old.count(begin) > 1:
        raise ValueError('Trial markers are damaged; configuration was not changed.')
    if begin in old:
        start, finish = old.index(begin), old.index(end)
        if finish < start:
            raise ValueError('Trial markers are damaged; configuration was not changed.')
        new = old[:start] + begin + '\n' + content.strip() + '\n' + end + old[finish + len(end):]
    else:
        new = old + '\n\n' + begin + '\n' + content.strip() + '\n' + end + '\n'
    directory = os.path.dirname(os.path.abspath(path))
    if not os.path.isdir(directory):
        os.makedirs(directory)
    descriptor, temporary = tempfile.mkstemp(prefix='.levi-trial-', dir=directory)
    try:
        with os.fdopen(descriptor, 'w') as handle:
            handle.write(new)
            handle.flush()
            os.fsync(handle.fileno())
        if os.path.exists(path):
            shutil.copy2(path, path + '.trial.bak')
            os.chmod(path + '.trial.bak', 0o600)
            os.chmod(temporary, os.stat(path).st_mode & 0o777)
        os.rename(temporary, path)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)


def request_fullpackage(cookie_path):
    """Follow the site's manual generator, including its 29-second wait."""
    jar = MozillaCookieJar(cookie_path)
    if os.path.exists(cookie_path):
        jar.load(ignore_discard=True)
    opener = build_opener(HTTPCookieProcessor(jar))
    opener.addheaders = [('User-Agent', 'Levi45FreeServer/3.2.2')]
    page = 'https://www.fullpackage.co.uk/free-cccam-oscam-trial/'
    response = opener.open(page, timeout=30)
    try:
        html = response.read(2 * 1024 * 1024).decode('utf-8')
    finally:
        response.close()
    endpoint = 'https://www.fullpackage.co.uk/wp-json/trialcccam/v1/generate'
    if endpoint not in html or 'generateBtn' not in html:
        raise ValueError('FullPackage trial form changed. Check the provider website.')
    time.sleep(29)
    response = opener.open(Request(endpoint, headers={'Referer': page}), timeout=30)
    try:
        result = json.loads(response.read(65536).decode('utf-8'))
    finally:
        response.close()
    jar.save(ignore_discard=True)
    os.chmod(cookie_path, 0o600)
    if not isinstance(result, dict):
        raise ValueError('Invalid FullPackage response.')
    data = result.get('data') if isinstance(result.get('data'), dict) else result
    fields = [str(data.get(key) or '') for key in ('host', 'port', 'user', 'pass')]
    line = 'C: ' + ' '.join(fields)
    if not re.match(r'^C: [A-Za-z0-9._-]+ [0-9]{1,5} [^\s]+ [^\s]+$', line):
        raise ValueError(result.get('message') or data.get('message') or
                         'FullPackage did not return valid trial credentials.')
    if not 1 <= int(fields[1]) <= 65535:
        raise ValueError('FullPackage returned an invalid port.')
    return line


try:
    from html.parser import HTMLParser
except ImportError:
    from HTMLParser import HTMLParser


class _DhoomForm(HTMLParser):
    def __init__(self):
        HTMLParser.__init__(self)
        self.active = False
        self.found = False
        self.done = False
        self.fields = []
        self.text = []

    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        if tag == 'form' and attrs.get('name') == 'trial-ok' and not self.found:
            if attrs.get('method', '').lower() != 'post' or attrs.get('action', '') not in ('', '/test/', 'https://dhoom.org/test/'):
                raise ValueError('Dhoom form changed; check the provider website.')
            self.active = self.found = True
        if not self.active or self.done:
            return
        if tag == 'input' and attrs.get('type', '').lower() == 'hidden' and attrs.get('name'):
            self.fields.append((attrs['name'], attrs.get('value', '')))
        if tag == 'button' and attrs.get('name') == 'trial-ok':
            self.fields.append(('trial-ok', attrs.get('value', '')))
            self.done = True

    def handle_data(self, data):
        if self.active and not self.done:
            self.text.append(data)


class DhoomTrial(object):
    """Keep the form and session while the user answers the CAPTCHA."""
    page = 'https://dhoom.org/test/'

    def __init__(self, cookie_path):
        self.cookie_path = cookie_path
        self.jar = MozillaCookieJar(cookie_path)
        if os.path.exists(cookie_path):
            self.jar.load(ignore_discard=True)
        self.opener = build_opener(HTTPCookieProcessor(self.jar))
        self.opener.addheaders = [('User-Agent', 'Levi45FreeServer/3.2.3')]
        self.form = None
        self.used = False

    def prepare(self):
        response = self.opener.open(self.page, timeout=30)
        try:
            page = response.read(2 * 1024 * 1024).decode('utf-8')
        finally:
            response.close()
        form = _DhoomForm()
        form.feed(page)
        question = re.search(r'What\s+is\s+\d+\s*\+\s*\d+\s*\?', ' '.join(form.text), re.I)
        if not form.done or not question or not any(k == '_token' and v for k, v in form.fields):
            raise ValueError('Dhoom CAPTCHA form unavailable or changed. Check the website.')
        self.form = form
        return question.group(0)

    def submit(self, answer):
        if self.form is None or self.used:
            raise ValueError('Please start a new Dhoom trial request.')
        if not re.match(r'^[0-9]{1,2}$', answer):
            raise ValueError('Enter your CAPTCHA answer as a number.')
        self.used = True
        fields = self.form.fields + [('captcha', answer)]
        request = Request(self.page, data=urlencode(fields).encode('ascii'), headers={
            'Referer': self.page, 'Content-Type': 'application/x-www-form-urlencoded'})
        response = self.opener.open(request, timeout=30)
        try:
            page = response.read(2 * 1024 * 1024).decode('utf-8')
        finally:
            response.close()
        self.jar.save(ignore_discard=True)
        os.chmod(self.cookie_path, 0o600)
        # Read only the displayed C-line, not arbitrary webpage/script text.
        match = re.search(r'<([a-z0-9]+)\b[^>]*\bid=[\"\']c-line[\"\'][^>]*>(.*?)</\1\s*>', page, re.I | re.S)
        if match:
            parser = _DhoomText()
            parser.feed(match.group(2))
            line = ''.join(parser.parts).strip()
            if re.match(r'^C:\s+[A-Za-z0-9._-]+\s+[0-9]{1,5}\s+[^\s]+\s+[^\s]+$', line) and 1 <= int(line.split()[2]) <= 65535:
                return line
        raise ValueError('Dhoom did not return a valid C-line. The CAPTCHA may be incorrect, the session expired, or the trial unavailable. Start again or check the website.')


class _DhoomText(HTMLParser):
    def __init__(self):
        HTMLParser.__init__(self)
        self.parts = []

    def handle_data(self, data):
        self.parts.append(data)


def request_ninja(cookie_path):
    """Use the public button's normal request; provider IP limits apply."""
    jar = MozillaCookieJar(cookie_path)
    if os.path.exists(cookie_path):
        jar.load(ignore_discard=True)
    opener = build_opener(HTTPCookieProcessor(jar))
    opener.addheaders = [('User-Agent', 'Levi45FreeServer/3.2.4')]
    page = 'https://cccamninja.com/free-cccam'
    response = opener.open(page, timeout=30)
    try:
        html = response.read(2 * 1024 * 1024).decode('utf-8')
    finally:
        response.close()
    if 'genCccamBtn' not in html:
        raise ValueError('CCcamNinja trial page changed. Check the website.')
    response = opener.open('https://cccamninja.com/scripts.js', timeout=30)
    try:
        script = response.read(2 * 1024 * 1024).decode('utf-8')
    finally:
        response.close()
    endpoint = 'https://clines.xunlckd.workers.dev/'
    if not re.search(r"var\s+lineApiUrl\s*=\s*['\"]" + re.escape(endpoint) + r"['\"]", script):
        raise ValueError('CCcamNinja generator changed. Check the website.')
    time.sleep(1)
    response = opener.open(Request(endpoint, headers={'Referer': page, 'Origin': 'https://cccamninja.com'}), timeout=30)
    try:
        result = json.loads(response.read(65536).decode('utf-8'))
    finally:
        response.close()
    jar.save(ignore_discard=True)
    os.chmod(cookie_path, 0o600)
    if not isinstance(result, dict):
        raise ValueError('Invalid CCcamNinja response.')
    if not result.get('success'):
        if result.get('error') == 'no_lines':
            raise ValueError('CCcamNinja has no free lines available right now.')
        raise ValueError('CCcamNinja declined the request or the trial is unavailable.')
    line = result.get('line')
    if not isinstance(line, type(u'')) and not isinstance(line, str):
        raise ValueError('CCcamNinja returned an invalid C-line.')
    line = line.strip()
    if not re.match(r'^C:\s+[A-Za-z0-9._-]+\s+[0-9]{1,5}\s+[^\s]+\s+[^\s]+$', line) or not 1 <= int(line.split()[2]) <= 65535:
        raise ValueError('CCcamNinja returned an invalid C-line.')
    return line


class TestclineTrial(DhoomTrial):
    page = 'https://testcline.com/cccam_reseller_panel_free.php'

    def __init__(self, cookie_path, server_index=0):
        DhoomTrial.__init__(self, cookie_path)
        self.server_index = server_index
        self.image_path = None

    def cleanup(self):
        if self.image_path and os.path.exists(self.image_path):
            os.unlink(self.image_path)
        self.image_path = None

    def prepare(self):
        response = self.opener.open(self.page, timeout=30)
        try:
            page = response.read(2 * 1024 * 1024).decode('utf-8')
        finally:
            response.close()
        servers = re.findall(r'<input\b[^>]*name=[\"\']server[\"\'][^>]*value=[\"\']([A-Za-z0-9.-]+)[\"\']', page, re.I)
        if len(servers) != 4 or '/test/cp.php' not in page or 'access_token' not in page:
            raise ValueError('Testcline form changed. Check the website.')
        self.server = servers[self.server_index]
        response = self.opener.open('https://testcline.com/test/cp.php', timeout=30)
        try:
            image = response.read(256 * 1024)
        finally:
            response.close()
        if not image.startswith(b'\x89PNG\r\n\x1a\n'):
            raise ValueError('Testcline CAPTCHA image unavailable.')
        fd, self.image_path = tempfile.mkstemp(prefix='levi45-captcha-', suffix='.png')
        with os.fdopen(fd, 'wb') as handle:
            handle.write(image)
        time.sleep(30)
        return self.image_path

    def submit(self, answer):
        if self.used or not self.image_path:
            raise ValueError('Start a fresh Testcline request.')
        if not re.match(r'^[0-9]{1,3}$', answer):
            raise ValueError('Enter your CAPTCHA answer as a number.')
        self.used = True
        fields = [('protocol', 'cccam'), ('server', self.server),
                  ('vehicle1', 'agree'), ('access_token', answer)]
        response = self.opener.open(Request(self.page, data=urlencode(fields).encode('ascii'),
            headers={'Referer': self.page, 'Content-Type': 'application/x-www-form-urlencoded'}), timeout=30)
        try:
            page = response.read(2 * 1024 * 1024).decode('utf-8')
        finally:
            response.close()
        self.jar.save(ignore_discard=True)
        os.chmod(self.cookie_path, 0o600)
        parser = _DhoomText()
        parser.feed(page)
        text = ' '.join(parser.parts)
        match = re.search(r'\bC:\s*([A-Za-z0-9._-]+)\s+([0-9]{1,5})\s+([A-Za-z0-9._-]+)\s+([A-Za-z0-9._-]+)', text)
        if match and 1 <= int(match.group(2)) <= 65535:
            return 'C: ' + ' '.join(match.groups())
        raise ValueError('Testcline returned no valid C-line. CAPTCHA may be incorrect, session expired or trial unavailable. Start again or check the website.')
