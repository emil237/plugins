# -*- coding: utf-8 -*-
from Plugins.Plugin import PluginDescriptor
from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
from Screens.ChoiceBox import ChoiceBox
from Components.ActionMap import ActionMap
from Components.Label import Label
from Components.MenuList import MenuList
from Components.config import config, ConfigSubsection, ConfigSelection, ConfigYesNo, ConfigClock, ConfigText, ConfigInteger, configfile
from Components.ConfigList import ConfigListScreen
from Components.Sources.StaticText import StaticText
from Components.config import getConfigListEntry
from enigma import eTimer, getDesktop
import re
import os
import datetime
import subprocess
import json
import xml.etree.ElementTree as ET

PLUGIN_PATH = "/usr/lib/enigma2/python/Plugins/Extensions/Levi45FreeServer"

SCRAPE_URLS = [
    ("https://cccam-premium.pro/free-cccam/", "parser_curl_regex"),
    ("https://cccamsate.com/free", "parser_curl_regex"),
    ("https://cccamiptv.tv/cccamfree/#page-content", "parser_curl_regex"),
    ("https://cccam.net/freecccam", "parser_curl_regex"),
    ("https://cccamia.com/cccam-free/", "parser_curl_regex"),
    ("https://cccamhub.com/cccamfree/", "parser_curl_regex"),
    ("https://cccamgalaxy.com/", "parser_curl_regex"),
    ("https://cccamfree48h.yolasite.com/server-2.php", "parser_curl_regex"),
    ("https://cccamx.com/free-cccam", "parser_curl_regex"),
    ("https://bosscccam.co/Test.php", "parser_curl_regex"),
    ("https://iptv-15days.blogspot.com/", "parser_curl_regex"),
    ("https://raw.githubusercontent.com/levi-45/free-cccam/main/servers.txt", "parser_curl_regex"),
    {"url_generator": lambda: "https://testious.com/old-free-cccam-servers/{}/".format(
        (datetime.date.today() - datetime.timedelta(days=1)).strftime('%Y-%m-%d')),
     "parser_name": "parser_testious_servers"},
    {"url_generator": lambda: "https://testious.com/old-free-cccam-servers/{}/".format(
        datetime.date.today().strftime('%Y-%m-%d')),
     "parser_name": "parser_testious_servers"}
]

LOG_FILE = "/tmp/downloader.log"

DEFAULT_OUTPUT_PATHS = {
    "cccam": "/etc/CCcam.cfg",
    "oscam": "/etc/tuxbox/config/oscam.server",
    "ncam":  "/etc/tuxbox/config/ncam.server",
}

config.plugins.Levi45FreeServer = ConfigSubsection()
config.plugins.Levi45FreeServer.downloadtime = ConfigClock(default=0)
config.plugins.Levi45FreeServer.softcam = ConfigSelection(
    choices=[("cccam", "CCam"), ("oscam", "OSCam"), ("ncam", "NCam")],
    default="oscam")
config.plugins.Levi45FreeServer.cccamfile = ConfigText(default=DEFAULT_OUTPUT_PATHS["cccam"], fixed_size=False)
config.plugins.Levi45FreeServer.oscamfile = ConfigText(default=DEFAULT_OUTPUT_PATHS["oscam"], fixed_size=False)
config.plugins.Levi45FreeServer.ncamfile  = ConfigText(default=DEFAULT_OUTPUT_PATHS["ncam"],  fixed_size=False)
config.plugins.Levi45FreeServer.outputfile = ConfigText(default=DEFAULT_OUTPUT_PATHS["oscam"], fixed_size=False)
config.plugins.Levi45FreeServer.downloadinterval = ConfigInteger(default=1, limits=(1, 168))
config.plugins.Levi45FreeServer.enablecron = ConfigSelection(choices=[("0", "Disabled"), ("1", "Enabled")], default="0")
config.plugins.Levi45FreeServer.showinmainmenu = ConfigSelection(
    choices=[("0", "Hidden"), ("1", "Visible")], default="1")
config.plugins.Levi45FreeServer.cleanupinactive = ConfigSelection(
    choices=[("0", "Disabled"), ("1", "Enabled")], default="1")
config.plugins.Levi45FreeServer.cleanupduplicates = ConfigSelection(
    choices=[("0", "Disabled"), ("1", "Enabled")], default="1")
config.plugins.Levi45FreeServer.cleanupstalehours = ConfigInteger(default=0, limits=(0, 720))

config.plugins.Levi45FreeServer.webifurl = ConfigText(default="http://127.0.0.1:8888", fixed_size=False)
config.plugins.Levi45FreeServer.webifuser = ConfigText(default="", fixed_size=False)
config.plugins.Levi45FreeServer.webifpass = ConfigText(default="", fixed_size=False)
config.plugins.Levi45FreeServer.prunedead = ConfigSelection(
    choices=[("0", "Disabled"), ("1", "Enabled")], default="0")
config.plugins.Levi45FreeServer.prunegracemin = ConfigInteger(default=3, limits=(1, 60))
config.plugins.Levi45FreeServer.pruneafterdownload = ConfigSelection(
    choices=[("0", "No"), ("1", "Yes")], default="0")


# ============================================================================
# Scaling helpers
# ============================================================================

def _get_scale_factor():
    try:
        desktop = getDesktop(0)
        w = desktop.size().width()
        if w >= 3800:
            return 3.0
        elif w >= 1900:
            return 1.5
        else:
            return 1.0
    except Exception:
        return 1.5


SCALE = _get_scale_factor()


def px(value):
    return int(value * SCALE)


def log(message):
    try:
        with open(LOG_FILE, "a") as f:
            f.write("[{}] {}\n".format(datetime.datetime.now(), message))
    except Exception as e:
        print("Failed to write to log file: {}".format(e))


# ============================================================================
# Parser Functions
# ============================================================================

def parse_servers_curl_regex(html_content):
    servers = []
    pattern = re.compile(r'C:\s*([\w\d\.-]+)\s*(\d+)\s*([\w\d\.-]+)\s*([\w\d\.-]+)', re.IGNORECASE)
    for match in pattern.finditer(html_content):
        host, port, user, password = match.groups()
        servers.append("C: {} {} {} {}".format(host, port, user, password))
    return servers


def parse_testious_servers(html_content):
    servers = []
    pattern_c = re.compile(r'C:\s*([\w\d\.-]+)\s*(\d+)\s*([\w\d\.-]+)\s*([\w\d\.-]+)', re.IGNORECASE)
    pattern_n = re.compile(
        r'N:\s*([\w\d\.-]+)\s*(\d+)\s*([\w\d\.-]+)\s*([\w\d\.-]+)\s*([0-9a-fA-F\s]+?)\s*(?:#.*)?$',
        re.MULTILINE | re.IGNORECASE)
    for match in pattern_n.finditer(html_content):
        host, port, user, password, key_str = match.groups()
        servers.append("N: {} {} {} {} {}".format(host, port, user, password,
                                                 key_str.strip().replace(" ", "")))
    for match in pattern_c.finditer(html_content):
        host, port, user, password = match.groups()
        servers.append("C: {} {} {} {}".format(host, port, user, password))
    return servers


PARSERS = {
    "parser_curl_regex": parse_servers_curl_regex,
    "parser_testious_servers": parse_testious_servers,
}


def convert_to_oscam_reader(server_line):
    parts = server_line.split()
    if not parts or len(parts) < 5:
        return ""
    protocol_type = parts[0].strip(':').lower()
    reader_config = ""
    if protocol_type == "c":
        host, port, user, password = parts[1], parts[2], parts[3], parts[4]
        reader_config = """
[reader]
label = {}_{}
protocol = cccam
device = {},{}
user = {}
password = {}
group = 1
cccversion = 2.1.2
inactivitytimeout = 1
reconnecttimeout = 30
disablelog = 1
""".format(host, port, host, port, user, password)
    elif protocol_type == "n" and len(parts) >= 6:
        host, port, user, password = parts[1], parts[2], parts[3], parts[4]
        key = "".join(parts[5:])
        reader_config = """
[reader]
label={}_{}
enable=1
protocol=newcamd
key={}
device={},{}
user={}
password={}
group=1
inactivitytimeout=1
reconnecttimeout=30
lb_weight=100
cccversion=2.1.2
cccmaxhops=10
cccwantemu=1
ccckeepalive=1
""".format(host, port, key, host, port, user, password)
    return reader_config.strip()


# ============================================================================
# Block / cleanup helpers (Option B - marker-scoped)
# ============================================================================

INACTIVE_PREFIXES = ("#", "//", ";")
START_MARKER = "# >>>>>> BEGIN AUTO-GENERATED BY Levi45FreeServer <<<<<<"
END_MARKER = "# >>>>>> END AUTO-GENERATED BY Levi45FreeServer <<<<<<"


def _split_file_into_sections(content):
    lines = content.splitlines()
    start_idx = end_idx = None
    for i, ln in enumerate(lines):
        if START_MARKER in ln:
            start_idx = i
            break
    if start_idx is not None:
        for j in range(start_idx, len(lines)):
            if END_MARKER in lines[j]:
                end_idx = j
                break
    if start_idx is None or end_idx is None:
        return lines, None, None
    return lines[:start_idx], lines[start_idx:end_idx + 1], lines[end_idx + 1:]


def _is_inactive_line(line):
    stripped = line.strip()
    if not stripped:
        return False
    for p in INACTIVE_PREFIXES:
        if stripped.startswith(p):
            if START_MARKER in stripped or END_MARKER in stripped:
                return False
            return True
    return False


def _is_inactive_reader_block(lines, idx):
    if lines[idx].strip().lower() != "[reader]":
        return None, None
    end = idx + 1
    while end < len(lines):
        nxt = lines[end].strip().lower()
        if nxt.startswith("[reader]"):
            break
        if nxt.startswith("[") and not nxt.startswith("[reader]"):
            break
        end += 1
    block = lines[idx:end]
    has_active = False
    for bl in block[1:]:
        bl_s = bl.strip()
        if not bl_s or bl_s.startswith("#"):
            continue
        if bl_s.lower().startswith("enable") and "=" in bl_s:
            val = bl_s.split("=", 1)[1].strip()
            if val in ("0", "false", "no"):
                return True, end
        if bl_s.lower().startswith(("protocol", "device", "user", "password")):
            has_active = True
    return (not has_active), end


def _parse_cccam_key(line):
    m = re.match(r'^([CN]):\s*(\S+)\s+(\d+)\s+(\S+)\s+(\S+)', line, re.IGNORECASE)
    if m:
        return "{}:{}:{}:{}".format(m.group(1).upper(), m.group(2).lower(),
                                    m.group(3), m.group(4).lower())
    return None


def _parse_oscam_reader_key(block_lines):
    device = user = None
    for bl in block_lines:
        s = bl.strip()
        if s.lower().startswith("device"):
            device = s.split("=", 1)[1].strip().lower() if "=" in s else None
        elif s.lower().startswith("user"):
            user = s.split("=", 1)[1].strip().lower() if "=" in s else None
    if device and user:
        return "{}|{}".format(device, user)
    return None


def _clean_block_lines(block_lines, softcam_type, remove_inactive=True, remove_duplicates=True):
    stats = {'inactive': 0, 'duplicates': 0}
    if not block_lines:
        return block_lines, stats
    start_marker_line = end_marker_line = None
    content_lines = []
    for ln in block_lines:
        if START_MARKER in ln:
            start_marker_line = ln
            continue
        if END_MARKER in ln:
            end_marker_line = ln
            continue
        content_lines.append(ln)

    if remove_inactive:
        new_content = []
        if softcam_type in ("oscam", "ncam"):
            i = 0
            while i < len(content_lines):
                inactive, end = _is_inactive_reader_block(content_lines, i)
                if inactive:
                    stats['inactive'] += 1
                    i = end
                    continue
                new_content.append(content_lines[i])
                i += 1
        else:
            for ln in content_lines:
                if "# Generated on" in ln or "# Total servers" in ln:
                    new_content.append(ln)
                    continue
                if _is_inactive_line(ln):
                    stats['inactive'] += 1
                    continue
                new_content.append(ln)
        content_lines = new_content

    if remove_duplicates:
        new_content = []
        seen = set()
        if softcam_type in ("oscam", "ncam"):
            i = 0
            while i < len(content_lines):
                if content_lines[i].strip().lower() == "[reader]":
                    end = i + 1
                    while end < len(content_lines):
                        nxt = content_lines[end].strip().lower()
                        if nxt.startswith("[reader]"):
                            break
                        if nxt.startswith("[") and not nxt.startswith("[reader]"):
                            break
                        end += 1
                    block = content_lines[i:end]
                    key = _parse_oscam_reader_key(block)
                    if key and key in seen:
                        stats['duplicates'] += 1
                        i = end
                        continue
                    if key:
                        seen.add(key)
                    new_content.extend(block)
                    i = end
                else:
                    new_content.append(content_lines[i])
                    i += 1
        else:
            for ln in content_lines:
                if "# Generated on" in ln or "# Total servers" in ln:
                    new_content.append(ln)
                    continue
                key = _parse_cccam_key(ln)
                if key:
                    if key in seen:
                        stats['duplicates'] += 1
                        continue
                    seen.add(key)
                new_content.append(ln)
        content_lines = new_content

    result = []
    if start_marker_line is not None:
        result.append(start_marker_line)
    result.extend(content_lines)
    if end_marker_line is not None:
        result.append(end_marker_line)
    return result, stats


def cleanup_output_file(file_path, softcam_type,
                       remove_inactive=True, remove_duplicates=True, remove_stale_hours=0):
    stats = {'inactive': 0, 'duplicates': 0, 'stale': 0,
             'file_existed': False, 'had_block': False}
    if not os.path.exists(file_path):
        log("cleanup: file {} does not exist".format(file_path))
        return stats
    stats['file_existed'] = True
    try:
        with open(file_path, "r") as f:
            content = f.read()
    except Exception as e:
        log("cleanup: cannot read {}: {}".format(file_path, e))
        return stats
    before, block, after = _split_file_into_sections(content)
    if block is None:
        log("cleanup: no plugin markers in {} - nothing to clean".format(file_path))
        return stats
    stats['had_block'] = True

    if remove_stale_hours > 0:
        cutoff = datetime.datetime.now() - datetime.timedelta(hours=remove_stale_hours)
        gen_time = None
        for ln in block:
            if "Generated on" in ln:
                try:
                    ts = ln.split("Generated on", 1)[1].strip()
                    gen_time = datetime.datetime.strptime(ts, "%Y-%m-%d %H:%M:%S")
                except Exception:
                    pass
                break
        if gen_time and gen_time < cutoff:
            stats['stale'] = 1
            log("cleanup: removing STALE auto-block from {} ({})".format(file_path, gen_time))
            new_content = "\n".join(before + after).rstrip() + "\n"
            try:
                import shutil
                shutil.copy2(file_path, file_path + ".cleanup.bak")
                with open(file_path, "w") as f:
                    f.write(new_content)
            except Exception as e:
                log("cleanup: failed to write {}: {}".format(file_path, e))
            return stats

    new_block, line_stats = _clean_block_lines(block, softcam_type,
                                              remove_inactive=remove_inactive,
                                              remove_duplicates=remove_duplicates)
    stats['inactive'] = line_stats['inactive']
    stats['duplicates'] = line_stats['duplicates']

    if new_block != block:
        try:
            import shutil
            shutil.copy2(file_path, file_path + ".cleanup.bak")
            new_content = "\n".join(before + new_block + after)
            if new_content and not new_content.endswith("\n"):
                new_content += "\n"
            with open(file_path, "w") as f:
                f.write(new_content)
            log("cleanup: block cleaned in {} (inactive={}, duplicates={})".format(
                file_path, stats['inactive'], stats['duplicates']))
        except Exception as e:
            log("cleanup: failed to write {}: {}".format(file_path, e))
    return stats


# ============================================================================
# WebIf / Prune Dead Readers (XML oscamapi.html?part=status)
# ============================================================================

def _webif_curl(url, user="", password="", timeout=10):
    cmd = ["curl", "-s", "-k", "--max-time", str(timeout), "-L"]
    if user:
        cmd.extend(["-u", "{}:{}".format(user, password)])
    cmd.extend(["-H", "Cache-Control: no-cache"])
    cmd.append(url)
    try:
        p = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        out, err = p.communicate()
        if p.returncode != 0:
            return None, err.decode('utf-8', 'ignore')
        return out.decode('utf-8', 'ignore'), None
    except Exception as e:
        return None, str(e)


BUILTIN_READERS = {
    "emulator",
    "internal_softcam",
    "internet_softcam",
    "constant.cw",
    "constant.cw ",
    "emu",
}


def _connection_is_dead(conn_text, caid_text):
    if conn_text is None:
        conn_text = ""
    ct = conn_text.upper().strip()
    caid = (caid_text or "").strip().upper()

    caid_is_zero = (caid == "" or caid == "0000" or caid.startswith("0000:") or
                    caid == "0000:0000" or caid.startswith("00000000"))

    for marker in ("ERROR", "OFF", "UNKNOWN", "TIMEOUT",
                   "NO DATA", "DISCONNECTED", "NOT CONNECTED",
                   "NOT FOUND", "STOPPED"):
        if marker in ct:
            return True

    if "READER DEVICE ERROR" in ct:
        return True

    if ct == "CARDOK" and caid_is_zero:
        return True

    if ct == "" and caid_is_zero:
        return True

    return False


def _parse_oscam_xml_status(xml_text):
    dead = set()
    try:
        start = xml_text.find("<oscam")
        if start == -1:
            start = xml_text.find("<?xml")
        if start > 0:
            xml_text = xml_text[start:]
        root = ET.fromstring(xml_text)
    except Exception as e:
        log("Prune: XML parse failed: {}".format(e))
        return dead

    total_clients = 0
    total_readers = 0
    total_proxies = 0

    for client in root.iter("client"):
        ctype = (client.get("type") or "").lower()
        total_clients += 1
        if ctype not in ("r", "p"):
            continue
        if ctype == "r":
            total_readers += 1
        else:
            total_proxies += 1
        name = client.get("name") or ""
        if not name:
            continue
        lname = name.lower()
        if lname in BUILTIN_READERS:
            continue
        req = client.find("request")
        caid_text = req.get("caid", "") if req is not None else ""
        conn = client.find("connection")
        conn_text = (conn.text or "").strip() if conn is not None else ""
        if _connection_is_dead(conn_text, caid_text):
            dead.add(lname)

    log("Prune: XML contained {} clients ({} real readers, {} proxy readers)".format(
        total_clients, total_readers, total_proxies))
    return dead


def fetch_oscam_dead_readers():
    base = (config.plugins.Levi45FreeServer.webifurl.value or "").rstrip("/")
    user = config.plugins.Levi45FreeServer.webifuser.value or ""
    passwd = config.plugins.Levi45FreeServer.webifpass.value or ""

    if not base:
        return set(), "WebIf URL not configured"

    url = base + "/oscamapi.html?part=status"
    log("Prune: fetching {}".format(url))

    body, err = _webif_curl(url, user, passwd, timeout=15)
    if not body:
        return set(), "WebIf not reachable at {} ({})".format(url, err or "no response")

    if "<oscam" not in body.lower() and "<status" not in body.lower() and "<client" not in body.lower():
        return set(), ("WebIf responded but not with OSCam XML status. "
                       "First bytes: {}".format(body[:80].replace("\n", " ")))

    dead = _parse_oscam_xml_status(body)
    log("Prune: XML status parsed - {} dead reader(s) found".format(len(dead)))
    if dead:
        sample = sorted(list(dead))[:8]
        log("Prune: dead examples: {}".format(", ".join(sample)))
    return dead, None


def prune_dead_readers_from_block(file_path, dead_labels):
    stats = {'removed': 0, 'file_existed': False, 'had_block': False}
    if not os.path.exists(file_path):
        return stats
    stats['file_existed'] = True
    try:
        with open(file_path, "r") as f:
            content = f.read()
    except Exception as e:
        log("prune: cannot read {}: {}".format(file_path, e))
        return stats

    before, block, after = _split_file_into_sections(content)
    if block is None:
        log("prune: no plugin markers in {} - nothing to prune".format(file_path))
        return stats
    stats['had_block'] = True

    start_marker_line = end_marker_line = None
    content_lines = []
    for ln in block:
        if START_MARKER in ln:
            start_marker_line = ln
            continue
        if END_MARKER in ln:
            end_marker_line = ln
            continue
        content_lines.append(ln)

    new_content = []
    i = 0
    while i < len(content_lines):
        line = content_lines[i]
        if line.strip().lower() == "[reader]":
            end = i + 1
            while end < len(content_lines):
                nxt = content_lines[end].strip().lower()
                if nxt.startswith("[reader]"):
                    break
                if nxt.startswith("[") and not nxt.startswith("[reader]"):
                    break
                end += 1
            reader_block = content_lines[i:end]
            label = None
            for bl in reader_block:
                s = bl.strip()
                if s.lower().startswith("label"):
                    if "=" in s:
                        label = s.split("=", 1)[1].strip().lower()
                    break
            if label and label in dead_labels:
                stats['removed'] += 1
                log("prune: removing dead reader '{}'".format(label))
                i = end
                continue
            else:
                new_content.extend(reader_block)
                i = end
        else:
            new_content.append(line)
            i += 1

    if stats['removed'] > 0:
        try:
            import shutil
            shutil.copy2(file_path, file_path + ".prune.bak")
            result = []
            if start_marker_line is not None:
                result.append(start_marker_line)
            result.extend(new_content)
            if end_marker_line is not None:
                result.append(end_marker_line)
            new_full = "\n".join(before + result + after)
            if new_full and not new_full.endswith("\n"):
                new_full += "\n"
            with open(file_path, "w") as f:
                f.write(new_full)
            log("prune: removed {} dead reader(s) from {} (backup: .prune.bak)".format(
                stats['removed'], file_path))
        except Exception as e:
            log("prune: failed to write {}: {}".format(file_path, e))
    return stats


def should_prune_after_download():
    return (config.plugins.Levi45FreeServer.prunedead.value == "1" and
            config.plugins.Levi45FreeServer.pruneafterdownload.value == "1")


# ============================================================================
# Path helpers
# ============================================================================

def get_path_for_softcam(softcam):
    if softcam == "cccam":
        return config.plugins.Levi45FreeServer.cccamfile.value or DEFAULT_OUTPUT_PATHS["cccam"]
    elif softcam == "ncam":
        return config.plugins.Levi45FreeServer.ncamfile.value or DEFAULT_OUTPUT_PATHS["ncam"]
    else:
        return config.plugins.Levi45FreeServer.oscamfile.value or DEFAULT_OUTPUT_PATHS["oscam"]


def set_path_for_softcam(softcam, path):
    if softcam == "cccam":
        config.plugins.Levi45FreeServer.cccamfile.value = path
    elif softcam == "ncam":
        config.plugins.Levi45FreeServer.ncamfile.value = path
    else:
        config.plugins.Levi45FreeServer.oscamfile.value = path
    if config.plugins.Levi45FreeServer.softcam.value == softcam:
        config.plugins.Levi45FreeServer.outputfile.value = path


def sync_active_outputfile():
    active = config.plugins.Levi45FreeServer.softcam.value
    config.plugins.Levi45FreeServer.outputfile.value = get_path_for_softcam(active)


# ============================================================================
# State file helpers
# ============================================================================

AUTODOWNLOAD_FILE = "/etc/levi45_autodownload.txt"
SOFTCAM_STATE_FILE = "/etc/levi45_softcam.txt"
OUTPUTFILE_STATE_FILE = "/etc/levi45_outputfile.txt"
ALL_PATHS_STATE_FILE = "/etc/levi45_paths.txt"

last_download_time = None


def is_autodownload_enabled():
    try:
        if os.path.exists(AUTODOWNLOAD_FILE):
            with open(AUTODOWNLOAD_FILE, "r") as f:
                return f.read().strip() == "True"
        return False
    except:
        return False


def set_autodownload_enabled(enabled):
    try:
        with open(AUTODOWNLOAD_FILE, "w") as f:
            f.write("True" if enabled else "False")
        return True
    except:
        return False


def write_softcam_state():
    try:
        with open(SOFTCAM_STATE_FILE, "w") as f:
            f.write(config.plugins.Levi45FreeServer.softcam.value)
        return True
    except Exception as e:
        log("Failed to write softcam state: {}".format(e))
        return False


def write_all_paths_state():
    try:
        with open(ALL_PATHS_STATE_FILE, "w") as f:
            f.write("SOFTCAM={}\n".format(config.plugins.Levi45FreeServer.softcam.value))
            f.write("CCcam={}\n".format(config.plugins.Levi45FreeServer.cccamfile.value))
            f.write("OSCam={}\n".format(config.plugins.Levi45FreeServer.oscamfile.value))
            f.write("NCam={}\n".format(config.plugins.Levi45FreeServer.ncamfile.value))
            f.write("CLEANUP_INACTIVE={}\n".format(config.plugins.Levi45FreeServer.cleanupinactive.value))
            f.write("CLEANUP_DUPES={}\n".format(config.plugins.Levi45FreeServer.cleanupduplicates.value))
            f.write("CLEANUP_STALE={}\n".format(config.plugins.Levi45FreeServer.cleanupstalehours.value))
        return True
    except Exception as e:
        log("Failed to write all-paths state: {}".format(e))
        return False


def write_outputfile_state():
    try:
        active = config.plugins.Levi45FreeServer.softcam.value
        path = get_path_for_softcam(active)
        with open(OUTPUTFILE_STATE_FILE, "w") as f:
            f.write(path)
        write_all_paths_state()
        return True
    except Exception as e:
        log("Failed to write outputfile state: {}".format(e))
        return False


def get_last_download_time():
    global last_download_time
    try:
        time_file = "/tmp/levi45_last_download.txt"
        if os.path.exists(time_file):
            with open(time_file, "r") as f:
                timestamp = float(f.read().strip())
                last_download_time = datetime.datetime.fromtimestamp(timestamp)
                log("Loaded last download time: {}".format(last_download_time))
    except:
        last_download_time = None


def save_last_download_time():
    global last_download_time
    try:
        time_file = "/tmp/levi45_last_download.txt"
        with open(time_file, "w") as f:
            f.write(str(last_download_time.timestamp()))
    except:
        pass


# ============================================================================
# Cron script generator
# ============================================================================

def create_cron_script():
    cron_script = r'''#!/bin/sh
PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin
export PATH

LOG_FILE="/tmp/downloader.log"
AUTODOWNLOAD_FILE="/etc/levi45_autodownload.txt"
PATHS_FILE="/etc/levi45_paths.txt"

log() {
    echo "$(date '+[%Y-%m-%d %H:%M:%S]') $1" >> "$LOG_FILE"
}

if [ ! -f "$AUTODOWNLOAD_FILE" ] || [ "$(cat "$AUTODOWNLOAD_FILE" | tr -d '\r\n ')" != "True" ]; then
    log "Auto-download disabled, skipping"
    exit 0
fi

log "Cron job started"

ACTIVE_SOFTCAM=""
CCcam_PATH="/etc/CCcam.cfg"
OSCam_PATH="/etc/tuxbox/config/oscam.server"
NCam_PATH="/etc/tuxbox/config/ncam.server"
CLEANUP_INACTIVE="1"
CLEANUP_DUPES="1"
CLEANUP_STALE="0"

if [ -f "$PATHS_FILE" ]; then
    while IFS='=' read -r key val; do
        key=$(echo "$key" | tr -d '\r\n ')
        val=$(echo "$val" | tr -d '\r\n')
        case "$key" in
            SOFTCAM) ACTIVE_SOFTCAM="$val" ;;
            CCcam)   CCcam_PATH="$val" ;;
            OSCam)   OSCam_PATH="$val" ;;
            NCam)    NCam_PATH="$val" ;;
            CLEANUP_INACTIVE) CLEANUP_INACTIVE="$val" ;;
            CLEANUP_DUPES)    CLEANUP_DUPES="$val" ;;
            CLEANUP_STALE)    CLEANUP_STALE="$val" ;;
        esac
    done < "$PATHS_FILE"
fi

get_setting() {
    key="$1"
    if [ -f /etc/enigma2/settings ]; then
        val=$(grep "^${key}=" /etc/enigma2/settings | head -n1 | cut -d= -f2-)
        val=$(echo "$val" | sed 's/^"//; s/"$//; s/[[:space:]]*$//' | tr -d '\r')
        echo "$val"
    fi
}

[ -z "$ACTIVE_SOFTCAM" ] && ACTIVE_SOFTCAM=$(get_setting "config.plugins.Levi45FreeServer.softcam")
[ -z "$ACTIVE_SOFTCAM" ] && ACTIVE_SOFTCAM="cccam"

if [ ! -f "$PATHS_FILE" ]; then
    v=$(get_setting "config.plugins.Levi45FreeServer.cccamfile")
    [ -n "$v" ] && CCcam_PATH="$v"
    v=$(get_setting "config.plugins.Levi45FreeServer.oscamfile")
    [ -n "$v" ] && OSCam_PATH="$v"
    v=$(get_setting "config.plugins.Levi45FreeServer.ncamfile")
    [ -n "$v" ] && NCam_PATH="$v"
fi

case "$ACTIVE_SOFTCAM" in
    cccam) OUTPUT_FILE="$CCcam_PATH" ;;
    oscam) OUTPUT_FILE="$OSCam_PATH" ;;
    ncam)  OUTPUT_FILE="$NCam_PATH" ;;
    *)     OUTPUT_FILE="$CCcam_PATH" ;;
esac

log "Active softcam: $ACTIVE_SOFTCAM"
log "Output file: $OUTPUT_FILE"

START_MARKER="# >>>>>> BEGIN AUTO-GENERATED BY Levi45FreeServer <<<<<<"
END_MARKER="# >>>>>> END AUTO-GENERATED BY Levi45FreeServer <<<<<<"

cleanup_scoped() {
    f="$1"
    soft="$2"
    [ -f "$f" ] || return 0
    if ! grep -qF "$START_MARKER" "$f" || ! grep -qF "$END_MARKER" "$f"; then
        log "cleanup: no plugin markers in $f - nothing to clean"
        return 0
    fi
    cp "$f" "$f.cronbak" 2>/dev/null
    before_file="/tmp/levi45_before.$$"
    block_file="/tmp/levi45_block.$$"
    after_file="/tmp/levi45_after.$$"
    awk -v s="$START_MARKER" -v e="$END_MARKER" '
        BEGIN { inblock=0; done=0 }
        !done && index($0,s) > 0 { print > "'"$block_file"'"; inblock=1; next }
        inblock && index($0,e) > 0   { print > "'"$block_file"'"; inblock=0; done=1; next }
        inblock                       { print > "'"$block_file"'"; next }
        !done                         { print > "'"$before_file"'"; next }
        done                          { print > "'"$after_file"'" }
    ' "$f"
    cleaned_block="/tmp/levi45_block_clean.$$"
    if [ "$soft" = "cccam" ]; then
        if [ "$CLEANUP_INACTIVE" = "1" ]; then
            grep -vE '^[[:space:]]*(#|//|;)[^#]*[CN]:' "$block_file" > "$block_file.1" 2>/dev/null
            mv "$block_file.1" "$block_file"
        fi
        if [ "$CLEANUP_DUPES" = "1" ]; then
            awk '
                /^[[:space:]]*[CN]:/ {
                    k=$0; gsub(/[[:space:]]+/," ",k); gsub(/^[[:space:]]+|[[:space:]]+$/,"",k);
                    if (!seen[k]++) print
                    next
                }
                { print }
            ' "$block_file" > "$cleaned_block" && mv "$cleaned_block" "$block_file"
        fi
    else
        if [ "$CLEANUP_INACTIVE" = "1" ]; then
            awk '
                BEGIN { inblock=0; buf=""; disable=0 }
                /^\[reader\]/ {
                    if (inblock && !disable) printf "%s", buf;
                    inblock=1; buf=$0"\n"; disable=0; next
                }
                inblock && /^\[/ {
                    if (!disable) printf "%s", buf;
                    inblock=0; buf=""; disable=0
                }
                inblock {
                    buf=buf $0"\n"
                    if ($0 ~ /^[[:space:]]*enable[[:space:]]*=[[:space:]]*0/) disable=1
                    next
                }
                { print }
                END { if (inblock && !disable) printf "%s", buf }
            ' "$block_file" > "$block_file.1" && mv "$block_file.1" "$block_file"
        fi
        if [ "$CLEANUP_DUPES" = "1" ]; then
            awk '
                BEGIN { inblock=0; buf=""; key=""; d=""; u="" }
                /^\[reader\]/ {
                    if (inblock) {
                        if (key == "" || !seen[key]++) printf "%s", buf;
                    }
                    inblock=1; buf=$0"\n"; key=""; d=""; u=""; next
                }
                inblock && /^\[/ {
                    if (key == "" || !seen[key]++) printf "%s", buf;
                    inblock=0; buf=""; key=""; d=""; u=""
                }
                inblock {
                    buf=buf $0"\n"
                    if ($0 ~ /^[[:space:]]*device/) { d=$0; sub(/^[^=]*=[[:space:]]*/,"",d); gsub(/[[:space:]]/,"",d) }
                    if ($0 ~ /^[[:space:]]*user/)   { u=$0; sub(/^[^=]*=[[:space:]]*/,"",u); gsub(/[[:space:]]/,"",u) }
                    if (d != "" && u != "") key=d"|"u
                    next
                }
                { print }
                END { if (inblock && (key == "" || !seen[key]++)) printf "%s", buf }
            ' "$block_file" > "$block_file.1" && mv "$block_file.1" "$block_file"
        fi
    fi
    : > "$f"
    [ -s "$before_file" ] && cat "$before_file" >> "$f"
    cat "$block_file" >> "$f"
    [ -s "$after_file" ]  && cat "$after_file"  >> "$f"
    rm -f "$before_file" "$block_file" "$after_file" "$cleaned_block" 2>/dev/null
    log "Scoped cleanup done on $f"
}

cleanup_scoped "$CCcam_PATH" "cccam"
cleanup_scoped "$OSCam_PATH" "oscam"
cleanup_scoped "$NCam_PATH"  "ncam"

URLS="
https://cccam-premium.pro/free-cccam/
https://cccamsate.com/free
https://cccamiptv.tv/cccamfree/#page-content
https://cccam.net/freecccam
https://cccamia.com/cccam-free/
https://cccamhub.com/cccamfree/
https://cccamgalaxy.com/
https://cccamfree48h.yolasite.com/server-2.php
https://cccamx.com/free-cccam
https://bosscccam.co/Test.php
https://iptv-15days.blogspot.com/
https://raw.githubusercontent.com/levi-45/free-cccam/main/servers.txt
"

if command -v python3 >/dev/null 2>&1; then
    PY=python3
elif command -v python >/dev/null 2>&1; then
    PY=python
else
    PY=""
fi

if [ -n "$PY" ]; then
    YESTERDAY=$($PY -c "from datetime import datetime, timedelta; print((datetime.now() - timedelta(days=1)).strftime('%Y-%m-%d'))" 2>/dev/null)
    TODAY=$($PY -c "from datetime import datetime; print(datetime.now().strftime('%Y-%m-%d'))" 2>/dev/null)
fi

if [ -z "$YESTERDAY" ]; then
    YESTERDAY=$(date -d "yesterday" +%Y-%m-%d 2>/dev/null || date +%Y-%m-%d)
fi
if [ -z "$TODAY" ]; then
    TODAY=$(date +%Y-%m-%d)
fi

URLS="$URLS
https://testious.com/old-free-cccam-servers/$YESTERDAY/
https://testious.com/old-free-cccam-servers/$TODAY/
"

TEMP_FILE="/tmp/servers_temp.txt"
FINAL_FILE="/tmp/servers_final.txt"
CONVERTED_FILE="/tmp/servers_converted.txt"
DOWNLOAD_FILE="/tmp/servers_dl.tmp"

: > "$FINAL_FILE"
: > "$TEMP_FILE"
: > "$CONVERTED_FILE"

convert_to_oscam() {
    line="$1"
    set -- $line
    proto=$(echo "$1" | tr -d ':')
    host="$2"
    port="$3"
    user="$4"
    password="$5"
    shift 5
    key=""
    for part in "$@"; do
        key="${key}${part}"
    done
    [ -z "$host" ] || [ -z "$port" ] || [ -z "$user" ] || [ -z "$password" ] && return
    if [ "$proto" = "C" ]; then
        echo "[reader]"
        echo "label = ${host}_${port}"
        echo "protocol = cccam"
        echo "device = ${host},${port}"
        echo "user = ${user}"
        echo "password = ${password}"
        echo "group = 1"
        echo "cccversion = 2.1.2"
        echo "inactivitytimeout = 1"
        echo "reconnecttimeout = 30"
        echo "disablelog = 1"
        echo ""
    elif [ "$proto" = "N" ] && [ -n "$key" ]; then
        echo "[reader]"
        echo "label=${host}_${port}"
        echo "enable=1"
        echo "protocol=newcamd"
        echo "key=${key}"
        echo "device=${host},${port}"
        echo "user=${user}"
        echo "password=${password}"
        echo "group=1"
        echo "inactivitytimeout=1"
        echo "reconnecttimeout=30"
        echo "lb_weight=100"
        echo "cccversion=2.1.2"
        echo "cccmaxhops=10"
        echo "cccwantemu=1"
        echo "ccckeepalive=1"
        echo ""
    fi
}

parse_servers() {
    content="$1"
    url="$2"
    clean=$(echo "$content" | sed 's/<[^>]*>//g' | tr -d '\r' | sed 's/&nbsp;/ /g; s/&amp;/\&/g; s/&#58;/:/g')
    echo "$clean" | grep -oE 'C:[[:space:]]*[A-Za-z0-9._-]+[[:space:]]+[0-9]+[[:space:]]+[A-Za-z0-9._-]+[[:space:]]+[A-Za-z0-9._-]+' >> "$TEMP_FILE"
    echo "$clean" | grep -oE 'N:[[:space:]]*[A-Za-z0-9._-]+[[:space:]]+[0-9]+[[:space:]]+[A-Za-z0-9._-]+[[:space:]]+[A-Za-z0-9._-]+[[:space:]]+[0-9a-fA-F ]+' | sed 's/[[:space:]]*$//' >> "$TEMP_FILE"
}

echo "$URLS" | while IFS= read -r URL; do
    [ -z "$URL" ] && continue
    case "$URL" in
        http*) ;;
        *) continue ;;
    esac
    if curl -k -s -L --max-time 30 -A "Mozilla/5.0" "$URL" -o "$DOWNLOAD_FILE"; then
        if [ -s "$DOWNLOAD_FILE" ]; then
            CONTENT=$(cat "$DOWNLOAD_FILE")
            parse_servers "$CONTENT" "$URL"
        fi
    fi
    rm -f "$DOWNLOAD_FILE"
done

if [ -s "$TEMP_FILE" ]; then
    grep -E '^[CN]:' "$TEMP_FILE" | sed 's/#.*//' | sed 's/[[:space:]]*$//' | sort -u > "$FINAL_FILE"
    FINAL_COUNT=$(wc -l < "$FINAL_FILE")
    if [ "$FINAL_COUNT" -gt 0 ]; then
        if [ -f "$OUTPUT_FILE" ]; then
            cp "$OUTPUT_FILE" "$OUTPUT_FILE.backup"
            sed -i "/$START_MARKER/,/$END_MARKER/d" "$OUTPUT_FILE"
        else
            mkdir -p "$(dirname "$OUTPUT_FILE")" 2>/dev/null
            touch "$OUTPUT_FILE"
        fi
        {
            echo ""
            echo "$START_MARKER"
            echo "# Generated on $(date '+%Y-%m-%d %H:%M:%S')"
            echo "# Total servers: $FINAL_COUNT"
            if [ "$ACTIVE_SOFTCAM" = "oscam" ] || [ "$ACTIVE_SOFTCAM" = "ncam" ]; then
                : > "$CONVERTED_FILE"
                while IFS= read -r line; do
                    convert_to_oscam "$line" >> "$CONVERTED_FILE"
                done < "$FINAL_FILE"
                cat "$CONVERTED_FILE"
            else
                cat "$FINAL_FILE"
            fi
            echo "$END_MARKER"
        } >> "$OUTPUT_FILE"
        log "Success! Added $FINAL_COUNT servers to $OUTPUT_FILE"
    fi
fi

rm -f "$TEMP_FILE" "$FINAL_FILE" "$CONVERTED_FILE" "$DOWNLOAD_FILE" 2>/dev/null
log "Cron job completed"
'''
    try:
        script_path = os.path.join(PLUGIN_PATH, "cron_download.sh")
        with open(script_path, "w") as f:
            f.write(cron_script)
        os.chmod(script_path, 0o755)
        log("Cron download script created at {}".format(script_path))
        return True
    except Exception as e:
        log("Error creating cron script: {}".format(e))
        return False


# ============================================================================
# Cron job installer - FIXED VERSION
# ============================================================================

def _find_crontab_binary():
    for candidate in ("/usr/bin/crontab", "/bin/crontab",
                      "/usr/sbin/crontab", "/sbin/crontab"):
        if os.path.exists(candidate):
            return candidate
    try:
        which = subprocess.Popen(["which", "crontab"],
                                 stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        out, _ = which.communicate()
        path = out.decode('utf-8', 'ignore').strip()
        if path and os.path.exists(path):
            return path
    except Exception:
        pass
    return None


def _read_crontab(crontab_bin):
    try:
        p = subprocess.Popen([crontab_bin, "-l"],
                             stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        out, err = p.communicate()
        if p.returncode == 0:
            return out.decode('utf-8', 'ignore')
        return ""
    except Exception as e:
        log("Could not read crontab: {}".format(e))
        return ""


def _write_crontab(crontab_bin, content):
    """Write crontab via stdin - safest on BusyBox and Dreambox images."""
    try:
        p = subprocess.Popen([crontab_bin, "-"],
                             stdin=subprocess.PIPE,
                             stdout=subprocess.PIPE,
                             stderr=subprocess.PIPE)
        if not isinstance(content, bytes):
            content = content.encode('utf-8')
        _, err = p.communicate(content)
        if p.returncode != 0:
            log("crontab write failed: {}".format(err.decode('utf-8', 'ignore')))
            return False
        return True
    except Exception as e:
        log("Could not write crontab: {}".format(e))
        return False


def _cron_daemon_running():
    try:
        p = subprocess.Popen(["ps"], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        out, _ = p.communicate()
        text = out.decode('utf-8', 'ignore').lower()
        for name in ("crond", "busybox cron", "cron -f", "/usr/sbin/cron", "cronie"):
            if name in text:
                return True
        for line in text.splitlines():
            if "cron" in line and "levi45" not in line and "cron_download" not in line:
                return True
        return False
    except Exception as e:
        log("Could not check cron daemon: {}".format(e))
        return False


def setup_cron_job():
    """
    Install / remove the Levi45FreeServer cron entry.

    Builds the crontab as a multi-line string (no embedded \\n in the
    command itself) and passes it to 'crontab -' via stdin.

    Also writes a mirror copy to /etc/crontabs/root and
    /var/spool/cron/crontabs/root when those directories exist, so the
    entry survives on images where the crontab binary is a no-op.
    """
    cron_script_path = os.path.join(PLUGIN_PATH, "cron_download.sh")
    desired_line = None

    if (is_autodownload_enabled() and
            config.plugins.Levi45FreeServer.enablecron.value == "1"):
        try:
            download_time = config.plugins.Levi45FreeServer.downloadtime.value
            hour = download_time[0]
            minute = download_time[1]
        except Exception:
            hour, minute = 0, 0

        # NOTE: no trailing \n here. We'll add it when building the file.
        desired_line = "{} {} * * * /bin/sh {}".format(minute, hour, cron_script_path)
        log("Desired cron entry: {}".format(desired_line))
    else:
        log("Cron job disabled or removal requested")

    crontab_bin = _find_crontab_binary()
    if not crontab_bin:
        log("ERROR: crontab binary not found. Writing fallback files only.")
        try:
            with open("/etc/levi45_cronline.txt", "w") as f:
                f.write((desired_line or "") + "\n")
        except Exception as e:
            log("Could not write /etc/levi45_cronline.txt: {}".format(e))
        # Still sync to crontabs dirs as best effort
        _sync_crontab_dirs(desired_line)
        return

    existing = _read_crontab(crontab_bin)
    kept = [ln for ln in existing.splitlines()
            if "Levi45FreeServer" not in ln and "cron_download.sh" not in ln]

    # Rebuild the file with proper header + our line if desired
    header = [
        "MAILTO=\"\"",
        "PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin",
        "SHELL=/bin/sh",
    ]
    body = [ln for ln in kept if ln.strip() and not ln.startswith("PATH=")
            and not ln.startswith("MAILTO=") and not ln.startswith("SHELL=")]
    new_lines = header + body
    if desired_line:
        new_lines.append(desired_line)
    # Ensure file ends with exactly one newline
    new_content = "\n".join(new_lines).rstrip("\n") + "\n"

    if _write_crontab(crontab_bin, new_content):
        log("Crontab updated via {}".format(crontab_bin))
    else:
        log("Failed to update crontab via {}".format(crontab_bin))

    _sync_crontab_dirs(desired_line)

    # Final sanity check + daemon warning
    verify = _read_crontab(crontab_bin)
    if desired_line and desired_line not in verify:
        log("WARNING: desired cron line not found in crontab after write")
    if desired_line and not _cron_daemon_running():
        log("WARNING: cron entry present but no cron daemon detected. "
            "Start it with '/etc/init.d/cron start' or install busybox-cron.")


def _sync_crontab_dirs(desired_line):
    """Best-effort mirror of the crontab to common BusyBox cron dirs."""
    for path in ("/etc/crontabs/root", "/var/spool/cron/crontabs/root"):
        d = os.path.dirname(path)
        if not os.path.isdir(d):
            continue
        try:
            existing = ""
            if os.path.exists(path):
                try:
                    with open(path, "r") as f:
                        existing = f.read()
                except Exception:
                    existing = ""
            kept = [ln for ln in existing.splitlines()
                    if "Levi45FreeServer" not in ln and "cron_download.sh" not in ln]
            header = [
                "MAILTO=\"\"",
                "PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin",
                "SHELL=/bin/sh",
            ]
            body = [ln for ln in kept if ln.strip()
                    and not ln.startswith("PATH=")
                    and not ln.startswith("MAILTO=")
                    and not ln.startswith("SHELL=")]
            new_lines = header + body
            if desired_line:
                new_lines.append(desired_line)
            content = "\n".join(new_lines).rstrip("\n") + "\n"
            with open(path, "w") as f:
                f.write(content)
            log("Synced cron to {}".format(path))
        except Exception as e:
            log("Could not sync {}: {}".format(path, e))


get_last_download_time()


# ============================================================================
# File Browser Screen
# ============================================================================

class FileBrowserScreen(Screen):
    def __init__(self, session, start_dir="/etc"):
        Screen.__init__(self, session)
        self.session = session
        self.current_dir = start_dir if os.path.isdir(start_dir) else "/"
        self.entries = []

        self.skin = """
            <screen name="Levi45FileBrowser" position="center,center" size="{w},{h}" title="Select Output File">
                <widget name="path_label" position="{x},{y}" size="{cw},{ph}" font="Regular;{f1}" foregroundColor="#ffcc00" />
                <widget name="list" position="{x},{ly}" size="{cw},{lh}" scrollbarMode="showOnDemand" />
                <eLabel text="OK=Open/Select   Green=Use this directory   Red=Cancel" position="{x},{fy}" size="{cw},{fh}" font="Regular;{f2}" />
            </screen>
        """.format(
            w=px(820), h=px(620), x=px(15), y=px(15), cw=px(790), ph=px(40),
            ly=px(65), lh=px(480), fy=px(560), fh=px(40), f1=px(26), f2=px(24))

        self["path_label"] = Label("")
        self["list"] = MenuList([])
        self["actions"] = ActionMap(
            ["OkCancelActions", "ColorActions", "DirectionActions"],
            {"ok": self.enter, "cancel": self.cancel,
             "green": self.select_current_dir, "red": self.cancel}, -1)
        self.populate()

    def populate(self):
        items = []
        try:
            names = sorted(os.listdir(self.current_dir), key=lambda s: s.lower())
        except Exception as e:
            log("FileBrowser: cannot list {}: {}".format(self.current_dir, e))
            names = []
        parent = os.path.dirname(self.current_dir.rstrip("/"))
        if not parent:
            parent = "/"
        if self.current_dir != "/":
            items.append(("..", parent, True))
        for name in names:
            full = os.path.join(self.current_dir, name)
            try:
                is_dir = os.path.isdir(full)
            except Exception:
                is_dir = False
            items.append((name, full, is_dir))
        self.entries = items
        display = ["[DIR]  " + e[0] if e[2] else "       " + e[0] for e in items]
        self["list"].setList(display)
        self["path_label"].setText("Path: " + self.current_dir)

    def enter(self):
        idx = self["list"].getSelectionIndex()
        if idx is None or idx < 0 or idx >= len(self.entries):
            return
        name, full, is_dir = self.entries[idx]
        if is_dir:
            self.current_dir = full
            self.populate()
        else:
            self.close(full)

    def select_current_dir(self):
        softcam = config.plugins.Levi45FreeServer.softcam.value
        default_file = {"cccam": "CCcam.cfg", "oscam": "oscam.server",
                        "ncam": "ncam.server"}.get(softcam, "servers.txt")
        full = os.path.join(self.current_dir, default_file)

        def confirm(result):
            if result:
                self.close(full)

        self.session.openWithCallback(confirm, MessageBox,
            _("Use this directory?\n\n{}").format(full), MessageBox.TYPE_YESNO)

    def cancel(self):
        self.close(None)


# ============================================================================
# Settings Screen
# ============================================================================

class Levi45FreeServerSettings(ConfigListScreen, Screen):
    def __init__(self, session):
        Screen.__init__(self, session)
        self.setup_title = "Levi45FreeServer Settings"

        self.skin = """
            <screen name="Levi45FreeServerSettings" position="center,center" size="{w},{h}" title="Settings">
                <eLabel position="{x},{hdr_y}" size="{cw},{hdr_h}" backgroundColor="#0b2545" zPosition="1" />
                <eLabel position="{x},{hdr_y2}" size="{cw},{hdr_h2}" backgroundColor="#134074" zPosition="1" />
                <eLabel text="SETTINGS" position="{x},{hdr_t_y}" size="{cw},{hdr_t_h}"
                        font="Regular;{f_title}" halign="center" valign="center"
                        foregroundColor="#ffffff" transparent="1" zPosition="2" />
                <eLabel text="Levi45 Free Server  -  Configuration" position="{x},{hdr_s_y}" size="{cw},{hdr_s_h}"
                        font="Regular;{f_sub}" halign="center" valign="center"
                        foregroundColor="#a8dadc" transparent="1" zPosition="2" />
                <widget name="config" position="{x},{cfg_y}" size="{cw},{cfg_h}"
                        scrollbarMode="showOnDemand" zPosition="4" />
                <eLabel position="{x},{fo_y}" size="{cw},{fo_h}" backgroundColor="#0b2545" zPosition="1" />
                <eLabel position="{x},{fo_y}" size="{accent_w},{fo_h}" backgroundColor="#e63946" zPosition="2" />
                <eLabel text="OK = Edit / Browse    GREEN = Save    RED / EXIT = Cancel"
                        position="{x},{fo_y}" size="{cw},{fo_h}"
                        font="Regular;{f_fo}" halign="center" valign="center"
                        foregroundColor="#f1faee" transparent="1" zPosition="3" />
            </screen>
        """.format(
            w=px(720), h=px(680), x=px(20), cw=px(680), accent_w=px(6),
            hdr_y=px(10), hdr_h=px(55), hdr_y2=px(65), hdr_h2=px(45),
            hdr_t_y=px(12), hdr_t_h=px(50), hdr_s_y=px(68), hdr_s_h=px(38),
            f_title=px(30), f_sub=px(18),
            cfg_y=px(130), cfg_h=px(510),
            fo_y=px(640), fo_h=px(35), f_fo=px(18))

        self.list = []
        ConfigListScreen.__init__(self, self.list, session=session)

        self.current_softcam = config.plugins.Levi45FreeServer.softcam.value
        self.autodownload_enabled = is_autodownload_enabled()
        self.autodownload_value = 1 if self.autodownload_enabled else 0

        self.autodownload = getConfigListEntry("Auto Download", ConfigSelection(choices=[("0", "Disabled"), ("1", "Enabled")], default=str(self.autodownload_value)))
        self.downloadtime = getConfigListEntry("Download Time", config.plugins.Levi45FreeServer.downloadtime)
        self.softcam = getConfigListEntry("Softcam Type", config.plugins.Levi45FreeServer.softcam)
        self.cccamfile = getConfigListEntry("CCam File (OK to browse)", config.plugins.Levi45FreeServer.cccamfile)
        self.oscamfile = getConfigListEntry("OSCam File (OK to browse)", config.plugins.Levi45FreeServer.oscamfile)
        self.ncamfile  = getConfigListEntry("NCam File (OK to browse)", config.plugins.Levi45FreeServer.ncamfile)
        self.downloadinterval = getConfigListEntry("Download Interval (hours)", config.plugins.Levi45FreeServer.downloadinterval)
        self.enablecron = getConfigListEntry("Enable Background Cron", config.plugins.Levi45FreeServer.enablecron)
        self.showinmainmenu = getConfigListEntry("Show in Main Menu", config.plugins.Levi45FreeServer.showinmainmenu)
        self.cleanupinactive = getConfigListEntry("Remove Inactive Lines", config.plugins.Levi45FreeServer.cleanupinactive)
        self.cleanupduplicates = getConfigListEntry("Remove Duplicate Servers", config.plugins.Levi45FreeServer.cleanupduplicates)
        self.cleanupstalehours = getConfigListEntry("Remove Auto-Entries Older Than (h, 0=off)", config.plugins.Levi45FreeServer.cleanupstalehours)
        self.webifurl = getConfigListEntry("OSCam WebIf URL", config.plugins.Levi45FreeServer.webifurl)
        self.webifuser = getConfigListEntry("OSCam WebIf Username", config.plugins.Levi45FreeServer.webifuser)
        self.webifpass = getConfigListEntry("OSCam WebIf Password", config.plugins.Levi45FreeServer.webifpass)
        self.prunedead = getConfigListEntry("Prune Dead Readers (WebIf)", config.plugins.Levi45FreeServer.prunedead)
        self.prunegracemin = getConfigListEntry("Dead Reader Grace Period (min)", config.plugins.Levi45FreeServer.prunegracemin)
        self.pruneafterdownload = getConfigListEntry("Prune After Every Download", config.plugins.Levi45FreeServer.pruneafterdownload)

        for e in (self.autodownload, self.downloadtime, self.softcam,
                  self.cccamfile, self.oscamfile, self.ncamfile,
                  self.downloadinterval, self.enablecron, self.showinmainmenu,
                  self.cleanupinactive, self.cleanupduplicates, self.cleanupstalehours,
                  self.webifurl, self.webifuser, self.webifpass,
                  self.prunedead, self.prunegracemin, self.pruneafterdownload):
            self.list.append(e)

        self["config"].list = self.list
        self["config"].l.setList(self.list)

        self["actions"] = ActionMap(["SetupActions", "ColorActions"],
            {"ok": self.keyOK, "cancel": self.cancel,
             "green": self.save, "red": self.cancel}, -2)

    def keyOK(self):
        current = self["config"].getCurrent()
        if current and ("File (OK to browse)" in current[0]):
            self.openFileBrowser(current[0])
        else:
            self.save()

    def openFileBrowser(self, entry_label):
        if "CCam File" in entry_label:
            current_path = config.plugins.Levi45FreeServer.cccamfile.value
            softcam_key = "cccam"
        elif "NCam File" in entry_label:
            current_path = config.plugins.Levi45FreeServer.ncamfile.value
            softcam_key = "ncam"
        else:
            current_path = config.plugins.Levi45FreeServer.oscamfile.value
            softcam_key = "oscam"

        if current_path and os.path.isdir(os.path.dirname(current_path)):
            start_dir = os.path.dirname(current_path)
        elif current_path and os.path.isdir(current_path):
            start_dir = current_path
        else:
            start_dir = "/etc"

        self.session.openWithCallback(lambda p: self.fileBrowserCallback(p, softcam_key),
                                      FileBrowserScreen, start_dir)

    def fileBrowserCallback(self, path, softcam_key):
        if not path:
            return
        if os.path.isdir(path):
            default_file = {"cccam": "CCcam.cfg", "oscam": "oscam.server",
                            "ncam": "ncam.server"}.get(softcam_key, "servers.txt")
            path = os.path.join(path, default_file)
        self.setOutputPath(softcam_key, path)

    def setOutputPath(self, softcam_key, path):
        set_path_for_softcam(softcam_key, path)
        sync_active_outputfile()
        entry_label = {"cccam": "CCam File (OK to browse)",
                       "oscam": "OSCam File (OK to browse)",
                       "ncam": "NCam File (OK to browse)"}[softcam_key]
        config_obj = {"cccam": config.plugins.Levi45FreeServer.cccamfile,
                      "oscam": config.plugins.Levi45FreeServer.oscamfile,
                      "ncam": config.plugins.Levi45FreeServer.ncamfile}[softcam_key]
        new_entry = getConfigListEntry(entry_label, config_obj)
        try:
            new_entry[1].value = path
        except Exception as e:
            log("Could not set new_entry[1].value: {}".format(e))
        prefix = entry_label.split(" (")[0]
        for i, entry in enumerate(self.list):
            if prefix in entry[0]:
                self.list[i] = new_entry
                break
        self["config"].setList(self.list)

    def keyLeft(self):
        ConfigListScreen.keyLeft(self)
        self.update_autodownload_value()
        self.sync_on_softcam_change()

    def keyRight(self):
        ConfigListScreen.keyRight(self)
        self.update_autodownload_value()
        self.sync_on_softcam_change()

    def update_autodownload_value(self):
        current = self["config"].getCurrent()
        if current and current[0] == "Auto Download":
            self.autodownload_value = int(current[1].value)

    def sync_on_softcam_change(self):
        new_softcam = config.plugins.Levi45FreeServer.softcam.value
        if self.current_softcam != new_softcam:
            sync_active_outputfile()
            self.current_softcam = new_softcam

    def save(self):
        sync_active_outputfile()
        for x in self["config"].list:
            try:
                x[1].save()
            except Exception as e:
                log("Error saving entry {}: {}".format(x[0], e))
        try:
            for attr in ("cccamfile", "oscamfile", "ncamfile", "outputfile",
                         "showinmainmenu", "cleanupinactive", "cleanupduplicates",
                         "cleanupstalehours", "webifurl", "webifuser", "webifpass",
                         "prunedead", "prunegracemin", "pruneafterdownload"):
                getattr(config.plugins.Levi45FreeServer, attr).save()
        except Exception as e:
            log("Error saving extra paths: {}".format(e))
        enabled = (self.autodownload_value == 1)
        set_autodownload_enabled(enabled)
        write_softcam_state()
        write_outputfile_state()
        create_cron_script()
        setup_cron_job()
        configfile.save()
        self.close(True)

    def cancel(self):
        for x in self["config"].list:
            x[1].cancel()
        self.close(False)


# ============================================================================
# Main Plugin Screen
# ============================================================================

class Levi45FreeServerScreen(Screen):
    def __init__(self, session, args=None):
        Screen.__init__(self, session)

        self.skin = """
            <screen name="Levi45FreeServerScreen" position="center,center" size="{w},{h}" title="Satellite-Forum.Com">
                <eLabel position="{x},{hdr_y}" size="{cw},{hdr_h}" backgroundColor="#0b2545" zPosition="1" />
                <eLabel position="{x},{hdr_y2}" size="{cw},{hdr_h2}" backgroundColor="#134074" zPosition="1" />
                <eLabel text="LEVI45 FREE SERVER" position="{x},{hdr_t_y}" size="{cw},{hdr_t_h}"
                        font="Regular;{f_title}" halign="center" valign="center"
                        foregroundColor="#ffffff" transparent="1" zPosition="2" />
                <eLabel text="Satellite-Forum.Com  -  Version 3.0" position="{x},{hdr_s_y}" size="{cw},{hdr_s_h}"
                        font="Regular;{f_sub}" halign="center" valign="center"
                        foregroundColor="#a8dadc" transparent="1" zPosition="2" />
                <eLabel position="{x},{st_y}" size="{cw},{st_h}" backgroundColor="#1d3557" zPosition="1" />
                <eLabel position="{x},{st_y}" size="{accent_w},{st_h}" backgroundColor="#e63946" zPosition="2" />
                <widget name="status_label" position="{x},{st_y}" size="{cw},{st_h}"
                        font="Regular;{f_status}" halign="center" valign="center"
                        foregroundColor="#f1faee" transparent="1" zPosition="3" />
                <widget name="info_label" position="{x},{info_y}" size="{cw},{info_h}"
                        font="Regular;{f_info}" halign="center" valign="center"
                        foregroundColor="#B6DBF2" />

                <eLabel position="{c1x},{r1y}" size="{card_w},{card_h}" backgroundColor="#1d3557" zPosition="1" />
                <eLabel position="{c1x},{r1y}" size="{card_w},{accent_h}" backgroundColor="#457b9d" zPosition="2" />
                <eLabel text="[ BLUE ]" position="{c1x},{r1y_badge}" size="{card_w},{badge_h}"
                        font="Regular;{f_badge}" halign="center" foregroundColor="#a8dadc" transparent="1" zPosition="3" />
                <eLabel text="Save as CCam" position="{c1x},{r1y_title}" size="{card_w},{card_title_h}"
                        font="Regular;{f_card}" halign="center" foregroundColor="#ffffff" transparent="1" zPosition="3" />

                <eLabel position="{c2x},{r1y}" size="{card_w},{card_h}" backgroundColor="#1b4332" zPosition="1" />
                <eLabel position="{c2x},{r1y}" size="{card_w},{accent_h}" backgroundColor="#2d6a4f" zPosition="2" />
                <eLabel text="[ GREEN ]" position="{c2x},{r1y_badge}" size="{card_w},{badge_h}"
                        font="Regular;{f_badge}" halign="center" foregroundColor="#95d5b2" transparent="1" zPosition="3" />
                <eLabel text="Save as OSCam" position="{c2x},{r1y_title}" size="{card_w},{card_title_h}"
                        font="Regular;{f_card}" halign="center" foregroundColor="#ffffff" transparent="1" zPosition="3" />

                <eLabel position="{c1x},{r2y}" size="{card_w},{card_h}" backgroundColor="#5c4d0a" zPosition="1" />
                <eLabel position="{c1x},{r2y}" size="{card_w},{accent_h}" backgroundColor="#a68a00" zPosition="2" />
                <eLabel text="[ YELLOW ]" position="{c1x},{r2y_badge}" size="{card_w},{badge_h}"
                        font="Regular;{f_badge}" halign="center" foregroundColor="#ffe066" transparent="1" zPosition="3" />
                <eLabel text="Save as NCam" position="{c1x},{r2y_title}" size="{card_w},{card_title_h}"
                        font="Regular;{f_card}" halign="center" foregroundColor="#ffffff" transparent="1" zPosition="3" />

                <eLabel position="{c2x},{r2y}" size="{card_w},{card_h}" backgroundColor="#6a040f" zPosition="1" />
                <eLabel position="{c2x},{r2y}" size="{card_w},{accent_h}" backgroundColor="#9d0208" zPosition="2" />
                <eLabel text="[ RED ]" position="{c2x},{r2y_badge}" size="{card_w},{badge_h}"
                        font="Regular;{f_badge}" halign="center" foregroundColor="#ffb3b3" transparent="1" zPosition="3" />
                <eLabel text="Force Download" position="{c2x},{r2y_title}" size="{card_w},{card_title_h}"
                        font="Regular;{f_card}" halign="center" foregroundColor="#ffffff" transparent="1" zPosition="3" />

                <eLabel position="{c1x},{clean_y}" size="{clean_w},{clean_h}" backgroundColor="#2a3e5c" zPosition="1" />
                <eLabel position="{c1x},{clean_y}" size="{accent_w},{clean_h}" backgroundColor="#e0a458" zPosition="2" />
                <eLabel text="[ MENU ]   Clean / Prune  -  Open Menu"
                        position="{c1x},{clean_y}" size="{clean_w},{clean_h}"
                        font="Regular;{f_clean}" halign="center" valign="center"
                        foregroundColor="#f1faee" transparent="1" zPosition="3" />

                <eLabel position="{sx},{sep_y}" size="{cw2},{sep_h}" backgroundColor="#457b9d" zPosition="1" />
                <widget name="support" position="{sx},{sup_y}" size="{cw2},{sup_h}"
                        font="Regular;{f_sup}" halign="center" valign="center"
                        transparent="1" foregroundColor="#f1faee" />

                <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/Levi45FreeServer/images/kofi.png"
                         position="{p1x},{py}" size="{pw},{ph}" zPosition="5" />
                <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/Levi45FreeServer/images/paypal.png"
                         position="{p2x},{py}" size="{pw},{ph}" zPosition="5" />

                <eLabel text="MENU = Settings / Clean / Prune  -  EXIT = close"
                        position="{x},{ft_y}" size="{cw},{ft_h}"
                        font="Regular;{f_ft}" halign="center" foregroundColor="#a8dadc" transparent="1" />
            </screen>
        """.format(
            w=px(620), h=px(760), x=px(20), cw=px(580), cw2=px(520), sx=px(50),
            accent_w=px(6),
            hdr_y=px(10), hdr_h=px(55), hdr_y2=px(65), hdr_h2=px(45),
            hdr_t_y=px(12), hdr_t_h=px(50), hdr_s_y=px(68), hdr_s_h=px(38),
            f_title=px(30), f_sub=px(18),
            st_y=px(122), st_h=px(62), f_status=px(20),
            info_y=px(200), info_h=px(45), f_info=px(18),
            card_w=px(280), card_h=px(115),
            c1x=px(20), c2x=px(320), r1y=px(260), r2y=px(390),
            accent_h=px(6), badge_h=px(26), card_title_h=px(45),
            r1y_badge=px(278), r1y_title=px(312),
            r2y_badge=px(408), r2y_title=px(442),
            f_badge=px(16), f_card=px(23),
            clean_y=px(520), clean_h=px(48), clean_w=px(580), f_clean=px(19),
            sep_y=px(590), sep_h=px(3), sup_y=px(600), sup_h=px(26), f_sup=px(17),
            p1x=px(170), p2x=px(360), py=px(630), pw=px(80), ph=px(80),
            ft_y=px(725), ft_h=px(24), f_ft=px(15))

        self["status_label"] = Label("Ready  -  Choose a format to download free servers")
        self["info_label"] = Label("Auto Download  -  Settings  -  Clean  -  Prune")
        self["support"] = Label("Please support the project if you enjoy it")

        self["actions"] = ActionMap(
            ["ColorActions", "OkCancelActions", "MenuActions",
             "InfobarActions", "InfoActions", "TextActions", "SetupActions"],
            {
                "blue":    self.start_download_cccam,
                "green":   self.start_download_oscam,
                "yellow":  self.start_download_ncam,
                "red":     self.force_immediate_download,
                "cancel":  self.close,
                "menu":    self.open_main_menu,
                "info":    self.clean_now_prompt,
                "text":    self.clean_now_prompt,
                "ok":      self.clean_now_prompt,
            }, -1)

        self.servers_to_save = []
        self.scrape_index = 0
        self.format_choice = "cccam"

        self._spinner_frames = ["|", "/", "-", "\\"]
        self._spinner_idx = 0
        self._spinner_active = False
        self._spinner_base_text = ""

        self.check_timer = eTimer()
        self._timer_bound = False
        try:
            self.check_timer.timeout.connect(self.check_auto_download)
            self._timer_bound = True
        except Exception as e:
            log("timeout.connect() failed: {}".format(e))
        if not self._timer_bound:
            try:
                self.check_timer.callback.append(self.check_auto_download)
                self._timer_bound = True
            except Exception as e:
                log("callback.append() failed: {}".format(e))
        if not self._timer_bound:
            try:
                self.check_timer.timeout.get().append(self.check_auto_download)
                self._timer_bound = True
            except Exception as e:
                log("timeout.get().append() failed: {}".format(e))
        if self._timer_bound:
            self.check_timer.start(60000, False)

        self.spinner_timer = eTimer()
        try:
            self.spinner_timer.timeout.connect(self._tick_spinner)
        except Exception:
            try:
                self.spinner_timer.callback.append(self._tick_spinner)
            except Exception:
                pass

        try:
            with open(LOG_FILE, "a") as f:
                f.write("[{}] Plugin started (scale={}, prune=enabled XML+P)\n".format(
                    datetime.datetime.now(), SCALE))
        except Exception as e:
            print("Failed to write to log file: {}".format(e))

    def set_status(self, text, spinning=False):
        self._spinner_base_text = text
        if spinning:
            self._spinner_active = True
            self._spinner_idx = 0
            self._update_spinner_label()
            try:
                self.spinner_timer.stop()
                self.spinner_timer.start(500, False)
            except Exception:
                pass
        else:
            self._spinner_active = False
            try:
                self.spinner_timer.stop()
            except Exception:
                pass
            if "status_label" in self:
                self["status_label"].setText(text)

    def _tick_spinner(self):
        if not self._spinner_active:
            try:
                self.spinner_timer.stop()
            except Exception:
                pass
            return
        self._spinner_idx = (self._spinner_idx + 1) % len(self._spinner_frames)
        self._update_spinner_label()

    def _update_spinner_label(self):
        try:
            frame = self._spinner_frames[self._spinner_idx]
            if "status_label" in self:
                self["status_label"].setText("{}  {}".format(frame, self._spinner_base_text))
        except Exception as e:
            log("spinner update failed: {}".format(e))

    def open_main_menu(self):
        menu_items = [
            ("Settings",  "settings"),
            ("Clean Now  (Remove Inactive / Duplicate Lines)", "clean"),
            ("Prune Dead Readers  (Query OSCam WebIf)", "prune"),
            ("Cancel",    "cancel"),
        ]
        self.session.openWithCallback(self._main_menu_chosen, ChoiceBox,
                                      _("Levi45 Free Server"), menu_items)

    def _main_menu_chosen(self, choice):
        if not choice:
            return
        key = choice[1]
        if key == "settings":
            self.open_settings()
        elif key == "clean":
            self.clean_now_prompt()
        elif key == "prune":
            self.prune_now_prompt()

    def clean_now_prompt(self):
        msg = ("Run cleanup now?\n\nThis will only touch lines inside the plugin's own "
               "BEGIN / END block.\n\nYour own manual readers are safe.\n\n"
               "A backup will be created as *.cleanup.bak")
        self.session.openWithCallback(self._clean_now_confirm, MessageBox,
                                      msg, MessageBox.TYPE_YESNO)

    def _clean_now_confirm(self, result):
        if not result:
            return
        self.run_clean_now()

    def run_clean_now(self):
        self.set_status("Cleaning plugin's own block on all softcam files...", spinning=True)
        remove_inactive = (config.plugins.Levi45FreeServer.cleanupinactive.value == "1")
        remove_dupes    = (config.plugins.Levi45FreeServer.cleanupduplicates.value == "1")
        stale_hours     = config.plugins.Levi45FreeServer.cleanupstalehours.value
        total_inactive = total_dupes = total_stale = files_checked = files_touched = 0
        for key in ("cccam", "oscam", "ncam"):
            path = get_path_for_softcam(key)
            files_checked += 1
            stats = cleanup_output_file(path, key,
                remove_inactive=remove_inactive,
                remove_duplicates=remove_dupes,
                remove_stale_hours=stale_hours)
            total_inactive += stats.get('inactive', 0)
            total_dupes    += stats.get('duplicates', 0)
            total_stale    += stats.get('stale', 0)
            if stats.get('inactive', 0) or stats.get('duplicates', 0) or stats.get('stale', 0):
                files_touched += 1
        summary = ("Clean Now finished.\n\nFiles checked: {}\nFiles changed: {}\n\n"
                   "Inactive lines removed: {}\nDuplicate servers removed: {}\n"
                   "Stale auto-blocks removed: {}").format(
            files_checked, files_touched, total_inactive, total_dupes, total_stale)
        if files_touched == 0:
            self.set_status("Clean Now: nothing to remove  -  files already tidy", spinning=False)
        else:
            self.set_status("Clean Now OK  -  removed {} inactive, {} duplicates, {} stale".format(
                total_inactive, total_dupes, total_stale), spinning=False)
        self.session.open(MessageBox, summary, MessageBox.TYPE_INFO, timeout=8)

    def prune_now_prompt(self):
        if config.plugins.Levi45FreeServer.prunedead.value != "1":
            self.session.open(MessageBox,
                "Prune Dead Readers is Disabled.\n\nEnable it in Settings first.",
                MessageBox.TYPE_INFO, timeout=6)
            return
        url = config.plugins.Levi45FreeServer.webifurl.value
        msg = ("Query OSCam WebIf and remove dead readers?\n\n"
               "WebIf URL: {}\n\n"
               "This will ONLY remove readers inside the plugin's BEGIN / END block "
               "whose status is OFF / ERROR / UNKNOWN AND whose CAID has never "
               "delivered a key.\n\nYour own manual readers are 100% safe.\n\n"
               "A backup will be created as *.prune.bak.\n\n"
               "Note: OSCam must be running and reachable.").format(url)
        self.session.openWithCallback(self._prune_now_confirm, MessageBox,
                                      msg, MessageBox.TYPE_YESNO)

    def _prune_now_confirm(self, result):
        if not result:
            return
        self.run_prune()

    def run_prune(self):
        self.set_status("Querying OSCam WebIf for dead readers...", spinning=True)
        dead, err = fetch_oscam_dead_readers()
        if err:
            self.set_status("Prune failed: {}".format(err), spinning=False)
            self.session.open(MessageBox,
                "Could not read OSCam WebIf.\n\n{}\n\n"
                "Check URL/credentials in Settings.".format(err),
                MessageBox.TYPE_ERROR, timeout=12)
            return
        if not dead:
            self.set_status("Prune: no dead readers found in WebIf", spinning=False)
            self.session.open(MessageBox,
                "WebIf reported no dead readers.\n\n"
                "OSCam may need a few minutes to try all readers "
                "before they show as ERROR/OFF.",
                MessageBox.TYPE_INFO, timeout=8)
            return

        target = get_path_for_softcam("oscam")
        log("Prune: dead labels from WebIf: {}".format(sorted(list(dead))[:25]))
        stats = prune_dead_readers_from_block(target, dead)
        log("Prune: block at {} - removed {} reader(s)".format(
            target, stats.get('removed', 0)))
        if stats.get('removed', 0) == 0:
            log("Prune: no plugin-owned reader matched the dead list "
                "(all dead readers are outside the plugin block)")

        summary = ("Prune finished.\n\n"
                   "Dead readers in WebIf: {}\n"
                   "Removed from plugin block: {}\n\n"
                   "Target file: {}\n"
                   "Backup: {}.prune.bak\n\n"
                   "Note: readers outside the plugin's BEGIN/END markers "
                   "(e.g. your own readers) are never removed.").format(
            len(dead), stats.get('removed', 0), target, target)

        if stats.get('removed', 0) == 0:
            self.set_status("Prune: no plugin readers matched dead list", spinning=False)
        else:
            self.set_status("Prune OK  -  removed {} dead readers".format(stats['removed']),
                            spinning=False)

        self.session.open(MessageBox, summary, MessageBox.TYPE_INFO, timeout=10)

    def check_auto_download(self):
        if not is_autodownload_enabled():
            return
        now = datetime.datetime.now()
        download_time = config.plugins.Levi45FreeServer.downloadtime.value
        scheduled_time_today = datetime.datetime(now.year, now.month, now.day,
                                                 download_time[0], download_time[1])
        if last_download_time is None or last_download_time.date() != now.date():
            if now >= scheduled_time_today:
                self.auto_download()
                return
        interval_hours = config.plugins.Levi45FreeServer.downloadinterval.value
        if last_download_time:
            time_diff = (now - last_download_time).total_seconds()
            if time_diff >= interval_hours * 3600:
                self.auto_download()

    def force_immediate_download(self):
        global last_download_time
        last_download_time = None
        self.auto_download()

    def open_settings(self):
        self.session.openWithCallback(self.settingsClosed, Levi45FreeServerSettings)

    def settingsClosed(self, result):
        if result:
            enabled = is_autodownload_enabled()
            active = config.plugins.Levi45FreeServer.softcam.value
            self.set_status("Settings saved  -  Auto-download {}  -  Active: {}".format(
                "ENABLED" if enabled else "DISABLED", active.upper()), spinning=False)

    def auto_download(self):
        global last_download_time
        self.set_status("Auto-download in progress...", spinning=True)
        softcam_type = config.plugins.Levi45FreeServer.softcam.value
        last_download_time = datetime.datetime.now()
        save_last_download_time()
        self.start_download(softcam_type)

    def start_download_cccam(self):
        self.start_download("cccam")

    def start_download_oscam(self):
        self.start_download("oscam")

    def start_download_ncam(self):
        self.start_download("ncam")

    def start_download(self, format_choice):
        config.plugins.Levi45FreeServer.softcam.value = format_choice
        sync_active_outputfile()
        write_softcam_state()
        write_outputfile_state()
        self.set_status("Starting download for {}...".format(format_choice.upper()), spinning=True)
        self.servers_to_save = []
        self.scrape_index = 0
        self.format_choice = format_choice
        self.scrape_next_url()

    def scrape_next_url(self):
        if self.scrape_index < len(SCRAPE_URLS):
            url_entry = SCRAPE_URLS[self.scrape_index]
            if isinstance(url_entry, dict) and "url_generator" in url_entry:
                url = url_entry["url_generator"]()
                parser_name = url_entry["parser_name"]
            else:
                url = url_entry[0]
                parser_name = url_entry[1]
            display_url = url if len(url) <= 55 else url[:52] + "..."
            self.set_status("Scraping {}  ({}/{})".format(
                display_url, self.scrape_index + 1, len(SCRAPE_URLS)), spinning=True)
            try:
                cmd = ["curl", "-k", "-s", "-L", "--max-time", "30",
                       "-A", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
                       url]
                process = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
                stdout, stderr = process.communicate()
                if process.returncode == 0:
                    html_content_decoded = stdout.decode('utf-8', 'ignore')
                    parser_func = PARSERS.get(parser_name)
                    if parser_func:
                        new_servers = parser_func(html_content_decoded)
                        self.servers_to_save.extend(new_servers)
                        log("Found {} servers from {}".format(len(new_servers), url))
            except Exception as e:
                log("Error executing curl: {}".format(e))
            self.scrape_index += 1
            self.scrape_next_url()
        else:
            self.save_servers_to_file()

    def save_servers_to_file(self):
        if not self.servers_to_save:
            self.set_status("No servers were found  -  Check /tmp/downloader.log", spinning=False)
            return
        start_marker = "# >>>>>> BEGIN AUTO-GENERATED BY Levi45FreeServer <<<<<<\n"
        end_marker = "# >>>>>> END AUTO-GENERATED BY Levi45FreeServer <<<<<<\n"
        file_path = get_path_for_softcam(self.format_choice)
        remove_inactive = (config.plugins.Levi45FreeServer.cleanupinactive.value == "1")
        remove_dupes    = (config.plugins.Levi45FreeServer.cleanupduplicates.value == "1")
        stale_hours     = config.plugins.Levi45FreeServer.cleanupstalehours.value
        if remove_inactive or remove_dupes or stale_hours > 0:
            self.set_status("Cleaning up plugin's own block only...", spinning=True)
            cleanup_output_file(file_path, self.format_choice,
                remove_inactive=remove_inactive,
                remove_duplicates=remove_dupes,
                remove_stale_hours=stale_hours)
        try:
            existing_content = ""
            if os.path.exists(file_path):
                with open(file_path, "r") as f:
                    existing_content = f.read()
            start_index = existing_content.find(start_marker)
            end_index = existing_content.find(end_marker)
            if start_index != -1 and end_index != -1:
                before = existing_content[:start_index]
                after = existing_content[end_index + len(end_marker):]
                cleaned_content = before.rstrip() + "\n" + after.lstrip()
            else:
                cleaned_content = existing_content
            parent = os.path.dirname(file_path)
            if parent and not os.path.exists(parent):
                try:
                    os.makedirs(parent)
                except:
                    pass
            with open(file_path, "w") as f:
                f.write(cleaned_content.strip())
                if self.format_choice in ["oscam", "ncam"]:
                    oscam_servers = [convert_to_oscam_reader(s) for s in self.servers_to_save]
                    oscam_servers = [s for s in oscam_servers if s]
                    if oscam_servers:
                        f.write("\n\n" + start_marker)
                        for server_line in oscam_servers:
                            f.write(server_line + "\n\n")
                        f.write(end_marker)
                elif self.format_choice == "cccam":
                    if self.servers_to_save:
                        f.write("\n\n" + start_marker)
                        for server_line in self.servers_to_save:
                            f.write(server_line + "\n")
                        f.write(end_marker)
            self.set_status("Success!  Appended {} servers to {}".format(
                len(self.servers_to_save), file_path), spinning=False)
            if should_prune_after_download():
                self.run_prune()
        except Exception as e:
            self.set_status("Failed to write to {}: {}".format(file_path, e), spinning=False)


# ============================================================================
# Plugin initialization
# ============================================================================

try:
    create_cron_script()
    write_softcam_state()
    write_outputfile_state()
    setup_cron_job()
except Exception as e:
    log("Error during plugin initialization: {}".format(e))


# ============================================================================
# Plugin Descriptor
# ============================================================================

def main(session, **kwargs):
    session.open(Levi45FreeServerScreen)


def menu(menuid, **kwargs):
    if menuid == 'mainmenu':
        if config.plugins.Levi45FreeServer.showinmainmenu.value == "1":
            return [(('Levi45 Free Server'), main, 'Levi45 Free Server', 45)]
    return []


def Plugins(**kwargs):
    plugin_list = []
    plugin_list.append(PluginDescriptor(
        icon='plugin.png', name='Levi45FreeServer',
        description='satellite-forum.com V 3.0',
        where=PluginDescriptor.WHERE_PLUGINMENU, fnc=main))
    plugin_list.append(PluginDescriptor(
        icon='plugin.png', name='Levi45FreeServer',
        description='satellite-forum.com V 3.0',
        where=PluginDescriptor.WHERE_MENU, fnc=menu))
    plugin_list.append(PluginDescriptor(
        icon='plugin.png', name='Levi45FreeServer',
        description='satellite-forum.com V 3.0',
        where=PluginDescriptor.WHERE_EXTENSIONSMENU, fnc=main))
    return plugin_list