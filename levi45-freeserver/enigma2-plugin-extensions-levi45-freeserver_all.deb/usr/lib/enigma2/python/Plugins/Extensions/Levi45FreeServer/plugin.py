# -*- coding: utf-8 -*-
from Plugins.Plugin import PluginDescriptor
from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
from Screens.ChoiceBox import ChoiceBox
from Screens.InputBox import InputBox
from Components.Input import Input
from Components.ActionMap import ActionMap, NumberActionMap
from Components.Label import Label
from Components.Pixmap import Pixmap
from Components.MenuList import MenuList
from Components.config import config, ConfigSubsection, ConfigSelection, ConfigYesNo, ConfigClock, ConfigText, ConfigInteger, configfile
from Components.ConfigList import ConfigListScreen
from Components.Sources.StaticText import StaticText
from Components.config import getConfigListEntry
from enigma import eTimer, getDesktop

import sys
import re
import os
import datetime
import subprocess
import socket
import threading
import json
import base64
import time
import shutil

if sys.version_info[0] >= 3:
    import queue as queue_module
    import html as html_module
    import urllib.request as urllib_request
    import xml.etree.ElementTree as ET
else:
    import Queue as queue_module
    try:
        import html as html_module
    except ImportError:
        import HTMLParser as _HTMLParser
        class _HtmlShim(object):
            @staticmethod
            def unescape(s):
                return _HTMLParser.HTMLParser().unescape(s)
        html_module = _HtmlShim()
    import urllib2 as urllib_request
    import xml.etree.ElementTree as ET


# ============================================================================
# Resolution-aware scaling
# ============================================================================
def _detect_scale():
    """
    Return a scale factor that maps the design (based on 1920x1080) to the
    actual screen. On 1920x1080 -> 1.0, on 1280x720 -> ~0.667, on 4K -> ~2.0.
    """
    try:
        desktop = getDesktop(0)
        w = desktop.size().width()
        if w <= 0:
            return 1.0
        if w >= 3800:
            return 2.0
        if w >= 2500:
            return 1.5
        if w >= 1900:
            return 1.0
        if w >= 1200:
            return float(w) / 1920.0    # e.g. 1280 -> 0.6667
        if w >= 1000:
            return 0.75
        return 0.6
    except Exception:
        return 1.0


SCALE = _detect_scale()


def S(value):
    """Scale an integer or tuple/list of values by SCALE."""
    if isinstance(value, (list, tuple)):
        return type(value)(S(v) for v in value)
    return max(1, int(round(value * SCALE)))


PLUGIN_PATH = os.path.dirname(os.path.realpath(__file__))
PLUGIN_VERSION = "3.4"
PLUGIN_TITLE = "Levi45 Free Server"

SCRAPE_URLS = [
    ("https://cccam-premium.pro/free-cccam/", "parser_curl_regex"),
    ("https://cccamsate.com/free", "parser_curl_regex"),
    ("https://cccamiptv.tv/cccamfree/#page-content", "parser_curl_regex"),
    ("https://cccam.net/freecccam", "parser_curl_regex"),
    ("https://cccamia.com/cccam-free/", "parser_curl_regex"),
    ("https://cccamhub.com/cccamfree/", "parser_curl_regex"),
    ("https://cccamgalaxy.com/", "parser_curl_regex"),
    ("https://cccamfree48h.yolasite.com/server-2.php", "parser_curl_regex"),
    ("https://cccamx.com/free-cccam", "parser_curl_regex"),
    ("https://bosscccam.co/Test.php", "parser_curl_regex"),
    ("https://iptv-15days.blogspot.com/", "parser_curl_regex"),
    ("https://raw.githubusercontent.com/levi-45/free-cccam/main/servers.txt", "parser_curl_regex"),
    {"url_generator": lambda: "https://testious.com/old-free-cccam-servers/{}/".format((datetime.date.today() - datetime.timedelta(days=1)).strftime('%Y-%m-%d')),
     "parser_name": "parser_testious_servers"},
    {"url_generator": lambda: "https://testious.com/old-free-cccam-servers/{}/".format(datetime.date.today().strftime('%Y-%m-%d')),
     "parser_name": "parser_testious_servers"}
]

LOG_FILE = "/tmp/downloader.log"

def is_dreamos():
    """Detect Dream Property firmware without requiring optional DreamOS modules."""
    for marker in ("/etc/image-version", "/etc/issue"):
        try:
            with open(marker, "r") as handle:
                content = handle.read(4096).lower()
            if "dreambox" in content or "dreamos" in content or "dream property" in content:
                return True
        except (IOError, OSError):
            pass
    return os.path.exists("/usr/lib/enigma2/python/Components/Harddisk.py") and os.path.exists("/etc/dreambox")


def preferred_cam_path(name, fallback):
    """Keep standard defaults, but honor existing DreamOS cam layouts."""
    if is_dreamos():
        candidates = {
            "oscam": ("/etc/tuxbox/config/oscam/oscam.server", "/etc/tuxbox/config/oscam.server"),
            "ncam": ("/etc/tuxbox/config/ncam/ncam.server", "/etc/tuxbox/config/ncam.server"),
            "cccam": ("/etc/CCcam.cfg",),
        }.get(name, ())
        for candidate in candidates:
            if os.path.isfile(candidate):
                return candidate
    return fallback


DEFAULT_PATHS = {
    "cccam": preferred_cam_path("cccam", "/etc/CCcam.cfg"),
    "oscam": preferred_cam_path("oscam", "/etc/tuxbox/config/oscam.server"),
    "ncam": preferred_cam_path("ncam", "/etc/tuxbox/config/ncam.server"),
}

START_MARKER = "# >>>>>> BEGIN AUTO-GENERATED BY Levi45FreeServer <<<<<<"
END_MARKER = "# >>>>>> END AUTO-GENERATED BY Levi45FreeServer <<<<<<"

BUILTIN_READERS = set([
    "emulator",
    "internal_softcam",
    "internet_softcam",
    "constant.cw",
    "constant.cw ",
    "emu",
])


config.plugins.Levi45FreeServer = ConfigSubsection()
config.plugins.Levi45FreeServer.downloadtime = ConfigClock(default=0)

# FIX: Added permanent config variable for Auto Download
config.plugins.Levi45FreeServer.autodownload = ConfigSelection(
    choices=[("0", "Disabled"), ("1", "Enabled")], 
    default="0"
)

config.plugins.Levi45FreeServer.softcam = ConfigSelection(
    choices=[("cccam", "CCcam"), ("oscam", "OSCam"), ("ncam", "NCam")],
    default="oscam")
config.plugins.Levi45FreeServer.cccamfile = ConfigText(default=DEFAULT_PATHS["cccam"], fixed_size=False)
config.plugins.Levi45FreeServer.oscamfile = ConfigText(default=DEFAULT_PATHS["oscam"], fixed_size=False)
config.plugins.Levi45FreeServer.ncamfile = ConfigText(default=DEFAULT_PATHS["ncam"], fixed_size=False)
config.plugins.Levi45FreeServer.outputfile = ConfigText(default=DEFAULT_PATHS["oscam"], fixed_size=False)
config.plugins.Levi45FreeServer.downloadinterval = ConfigInteger(default=1, limits=(1, 168))
config.plugins.Levi45FreeServer.enablecron = ConfigSelection(choices=[("0", "Disabled"), ("1", "Enabled")], default="0")
config.plugins.Levi45FreeServer.showinmainmenu = ConfigSelection(
    choices=[("0", "Hidden"), ("1", "Visible")], default="1")
config.plugins.Levi45FreeServer.checkinactive = ConfigSelection(
    choices=[
        ("0", "Disabled"),
        ("1", "Check Before Writing"),
        ("2", "Check on Plugin Start"),
        ("3", "Both"),
    ],
    default="0")
config.plugins.Levi45FreeServer.checktimeout = ConfigInteger(default=5, limits=(1, 30))
config.plugins.Levi45FreeServer.checkthreads = ConfigInteger(default=10, limits=(1, 50))
config.plugins.Levi45FreeServer.prunemode = ConfigSelection(
    choices=[("auto", "Auto: WebIf for OSCam/NCam, TCP for CCcam"),
             ("webif", "WebIf status (OSCam/NCam)"),
             ("tcp", "TCP only (no login)")], default="auto")
config.plugins.Levi45FreeServer.oscamwebif = ConfigText(default="http://127.0.0.1:8888", fixed_size=False)
config.plugins.Levi45FreeServer.ncamwebif = ConfigText(default="http://127.0.0.1:8181", fixed_size=False)
config.plugins.Levi45FreeServer.oscamuser = ConfigText(default="", fixed_size=False)
config.plugins.Levi45FreeServer.oscampass = ConfigText(default="", fixed_size=False)


def get_path_for_softcam(softcam):
    if softcam == "cccam":
        return config.plugins.Levi45FreeServer.cccamfile.value or DEFAULT_PATHS["cccam"]
    elif softcam == "ncam":
        return config.plugins.Levi45FreeServer.ncamfile.value or DEFAULT_PATHS["ncam"]
    else:
        return config.plugins.Levi45FreeServer.oscamfile.value or DEFAULT_PATHS["oscam"]


def set_path_for_softcam(softcam, path):
    if softcam == "cccam":
        config.plugins.Levi45FreeServer.cccamfile.value = path
    elif softcam == "ncam":
        config.plugins.Levi45FreeServer.ncamfile.value = path
    else:
        config.plugins.Levi45FreeServer.oscamfile.value = path
    if config.plugins.Levi45FreeServer.softcam.value == softcam:
        config.plugins.Levi45FreeServer.outputfile.value = path


def sync_active_outputfile():
    active = config.plugins.Levi45FreeServer.softcam.value
    config.plugins.Levi45FreeServer.outputfile.value = get_path_for_softcam(active)


def log(message):
    try:
        with open(LOG_FILE, "a") as f:
            f.write("[{}] {}\n".format(datetime.datetime.now(), message))
    except Exception as e:
        print("Failed to write to log file: {}".format(e))


# ============================================================================
# Parsers
# ============================================================================
def parse_servers_curl_regex(html_content):
    servers = []
    pattern = re.compile(r'C:\s*([\w\d\.-]+)\s*(\d+)\s*([\w\d\.-]+)\s*([\w\d\.-]+)', re.IGNORECASE)
    for match in pattern.finditer(html_content):
        host, port, user, password = match.groups()
        servers.append("C: {} {} {} {}".format(host, port, user, password))
    return servers


def parse_testious_servers(html_content):
    servers = []
    pattern_c = re.compile(r'C:\s*([\w\d\.-]+)\s*(\d+)\s*([\w\d\.-]+)\s*([\w\d\.-]+)', re.IGNORECASE)
    pattern_n = re.compile(
        r'N:\s*([\w\d\.-]+)\s*(\d+)\s*([\w\d\.-]+)\s*([\w\d\.-]+)\s*([0-9a-fA-F\s]+?)\s*(?:#.*)?$',
        re.MULTILINE | re.IGNORECASE)
    for match in pattern_n.finditer(html_content):
        host, port, user, password, key_str = match.groups()
        servers.append("N: {} {} {} {} {}".format(host, port, user, password,
                                                 key_str.strip().replace(" ", "")))
    for match in pattern_c.finditer(html_content):
        host, port, user, password = match.groups()
        servers.append("C: {} {} {} {}".format(host, port, user, password))
    return servers


PARSERS = {
    "parser_curl_regex": parse_servers_curl_regex,
    "parser_testious_servers": parse_testious_servers,
}


def convert_to_oscam_reader(server_line):
    parts = server_line.split()
    if not parts or len(parts) < 5:
        return ""
    protocol_type = parts[0].strip(':').lower()
    reader_config = ""
    if protocol_type == "c":
        host, port, user, password = parts[1], parts[2], parts[3], parts[4]
        reader_config = """
[reader]
label = {}_{}
protocol = cccam
device = {},{}
user = {}
password = {}
group = 1
cccversion = 2.1.2
inactivitytimeout = 1
reconnecttimeout = 30
disablelog = 1
""".format(host, port, host, port, user, password)
    elif protocol_type == "n" and len(parts) >= 6:
        host, port, user, password = parts[1], parts[2], parts[3], parts[4]
        key = "".join(parts[5:])
        reader_config = """
[reader]
label={}_{}
enable=1
protocol=newcamd
key={}
device={},{}
user={}
password={}
group=1
inactivitytimeout=1
reconnecttimeout=30
lb_weight=100
cccversion=2.1.2
cccmaxhops=10
cccwantemu=1
ccckeepalive=1
""".format(host, port, key, host, port, user, password)
    return reader_config.strip()


def _split_file_into_sections(content):
    lines = content.splitlines()
    start_idx = end_idx = None
    for i, ln in enumerate(lines):
        if START_MARKER in ln:
            start_idx = i
            break
    if start_idx is not None:
        for j in range(start_idx, len(lines)):
            if END_MARKER in lines[j]:
                end_idx = j
                break
    if start_idx is None or end_idx is None:
        return lines, None, None
    return lines[:start_idx], lines[start_idx:end_idx + 1], lines[end_idx + 1:]


def _has_markers(content):
    return (START_MARKER in content) and (END_MARKER in content)


def _parse_oscam_device(block):
    m = re.search(r'^\s*device\s*=\s*([\w\d\.\-]+)\s*,\s*(\d+)', block, re.MULTILINE | re.IGNORECASE)
    return (m.group(1), m.group(2)) if m else None


def _parse_oscam_label(block):
    m = re.search(r'^\s*label\s*=\s*(.+?)\s*$', block, re.MULTILINE | re.IGNORECASE)
    return m.group(1).strip() if m else None


def _parse_cccam_line(line):
    m = re.match(r'^\s*C:\s*([\w\d\.\-]+)\s+(\d+)\s+', line, re.IGNORECASE)
    return (m.group(1), m.group(2)) if m else None


def _parse_newcamd_line(line):
    m = re.match(r'^\s*N:\s*([\w\d\.\-]+)\s+(\d+)\s+', line, re.IGNORECASE)
    return (m.group(1), m.group(2)) if m else None


def _tcp_check(host, port, timeout=3):
    try:
        port = int(port)
    except (TypeError, ValueError):
        return False
    if not host or not port:
        return False
    s = None
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.settimeout(timeout)
        s.connect((host, port))
        return True
    except Exception:
        return False
    finally:
        if s is not None:
            try:
                s.close()
            except Exception:
                pass


def _probe_batch_parallel(targets, timeout, max_workers, progress_cb=None, cancel_event=None):
    results = {}
    results_lock = threading.Lock()
    q = queue_module.Queue()
    for t in targets:
        q.put(t)
    total = len(targets)
    if total == 0:
        return results
    done_counter = [0]
    counter_lock = threading.Lock()

    def worker():
        while True:
            if cancel_event is not None and cancel_event.is_set():
                return
            try:
                idx, host, port = q.get_nowait()
            except queue_module.Empty:
                return
            try:
                ok = _tcp_check(host, port, timeout)
            except Exception:
                ok = False
            with results_lock:
                results[idx] = ok
            with counter_lock:
                done_counter[0] += 1
                done_now = done_counter[0]
            if progress_cb:
                try:
                    progress_cb(done_now, total, host, port, ok)
                except Exception:
                    pass
            try:
                q.task_done()
            except Exception:
                pass

    workers = []
    for _ in range(max(1, min(max_workers, total))):
        t = threading.Thread(target=worker)
        t.daemon = True
        workers.append(t)
    for w in workers:
        w.start()
    for w in workers:
        w.join()
    return results


def find_executable(name):
    """Portable executable discovery for older DreamOS/Python installations."""
    if hasattr(shutil, "which"):
        return shutil.which(name)
    for directory in os.environ.get("PATH", "/usr/bin:/bin:/usr/sbin:/sbin").split(os.pathsep):
        candidate = os.path.join(directory, name)
        if os.path.isfile(candidate) and os.access(candidate, os.X_OK):
            return candidate
    return None


def _http_get(url, user="", password="", timeout=5):
    try:
        req = urllib_request.Request(url, headers={
            "User-Agent": "Levi45FreeServer",
            "Accept": "text/xml,text/html,application/json,*/*"
        })
        if user:
            manager = urllib_request.HTTPPasswordMgrWithDefaultRealm()
            manager.add_password(None, url, user, password)
            opener = urllib_request.build_opener(
                urllib_request.HTTPDigestAuthHandler(manager),
                urllib_request.HTTPBasicAuthHandler(manager))
            resp = opener.open(req, timeout=timeout)
        else:
            resp = urllib_request.urlopen(req, timeout=timeout)
        try:
            data = resp.read()
        finally:
            try:
                resp.close()
            except Exception:
                pass
        if isinstance(data, bytes):
            return data.decode("utf-8", "ignore")
        return data
    except Exception as e:
        log("_http_get failed for {}: {}".format(url, e))
        return None


def _status_xml_root(body):
    """Accept parsed OSCam/NCam status XML, never HTML or a login page."""
    if not body:
        return None
    try:
        root = ET.fromstring(body.strip())
    except Exception:
        return None
    if root.tag.lower() not in ("oscam", "ncam"):
        return None
    if root.find("status") is None:
        return None
    return root


def _fetch_cam_status(base_url, softcam, user="", password="", timeout=5):
    endpoints = (["ncamapi.html", "oscamapi.html"] if softcam == "ncam"
                 else ["oscamapi.html"])
    for endpoint in endpoints:
        body = _http_get(base_url.rstrip("/") + "/" + endpoint + "?part=status",
                         user, password, timeout=timeout)
        if _status_xml_root(body) is not None:
            return body
    raise RuntimeError(
        "WebIf status unavailable at {}. Check port, WebIf username/password "
        "and plugin log (authentication/HTTP errors). No changes made.".format(base_url))


def _connection_is_dead(conn_text, caid_text):
    if conn_text is None:
        conn_text = ""
    ct = conn_text.upper().strip()
    caid = (caid_text or "").strip().upper()
    caid_is_zero = (caid == "" or caid == "0000" or caid.startswith("0000:") or
                    caid == "0000:0000" or caid.startswith("00000000"))
    for marker in ("ERROR", "OFF", "UNKNOWN", "TIMEOUT",
                   "NO DATA", "DISCONNECTED", "NOT CONNECTED",
                   "NOT FOUND", "STOPPED"):
        if marker in ct:
            return True
    if "READER DEVICE ERROR" in ct:
        return True
    if ct == "CARDOK" and caid_is_zero:
        return True
    if ct == "" and caid_is_zero:
        return True
    return False


def _parse_oscam_xml_status(xml_text):
    dead = set()
    try:
        start = xml_text.find("<oscam")
        if start == -1:
            start = xml_text.find("<?xml")
        if start > 0:
            xml_text = xml_text[start:]
        root = ET.fromstring(xml_text)
    except Exception as e:
        log("_parse_oscam_xml_status: parse failed: {}".format(e))
        return dead

    total_clients = total_readers = total_proxies = 0
    for client in root.iter("client"):
        ctype = (client.get("type") or "").lower()
        total_clients += 1
        if ctype not in ("r", "p"):
            continue
        if ctype == "r":
            total_readers += 1
        else:
            total_proxies += 1
        name = client.get("name") or ""
        if not name:
            continue
        lname = name.lower()
        if lname in BUILTIN_READERS:
            continue
        req = client.find("request")
        caid_text = req.get("caid", "") if req is not None else ""
        conn = client.find("connection")
        conn_text = (conn.text or "").strip() if conn is not None else ""
        if _connection_is_dead(conn_text, caid_text):
            dead.add(lname)

    log("XML status parsed: {} clients ({} real readers, {} proxy readers), {} dead".format(
        total_clients, total_readers, total_proxies, len(dead)))
    return dead


def fetch_oscam_dead_readers(base_url, user="", password="", timeout=10):
    if not base_url:
        return set()
    url = base_url.rstrip("/") + "/oscamapi.html?part=status"
    log("Prune: fetching {}".format(url))
    body = _http_get(url, user, password, timeout=timeout)
    if not body:
        return set()
    if "<oscam" not in body.lower() and "<client" not in body.lower():
        log("Prune: response does not look like OSCam XML")
        return set()
    return _parse_oscam_xml_status(body)


def _parse_oscam_reader_states(xml_text):
    """Return label -> WebIf snapshot, retaining duplicate-entry diagnostics.

    Duplicate labels are never classified from matching status text alone:
    their connection endpoints must also match the configured reader.
    """
    states = {}
    groups = {}
    try:
        root = _status_xml_root(xml_text)
        if root is None:
            log("Reader state XML: invalid OSCam/NCam status document")
            return states
    except Exception as exc:
        log("Reader state XML parse failed: {}".format(exc))
        return states
    for client in root.iter("client"):
        ctype = (client.get("type") or "").strip().lower()
        if ctype not in ("p", "r"):
            continue
        name = (client.get("name") or "").strip().lower()
        if not name or name in BUILTIN_READERS:
            continue
        connection = client.find("connection")
        raw = ((connection.text or "") if connection is not None else "").strip()
        normalized = raw.upper()
        if normalized in ("OK", "CONNECTED", "CARDOK"):
            state, reason = "Online (WebIf)", "OSCam reports a connected reader."
        elif normalized in ("OFF", "OFFLINE", "DISCONNECTED", "NOT CONNECTED",
                            "CONNECTION REFUSED", "CONNECT FAILED", "CONNECTION FAILED"):
            state, reason = "Offline (WebIf)", "OSCam reports disconnected at scan time."
        elif normalized == "ERROR":
            state, reason = "Offline (WebIf)", "OSCam reports a connection error at scan time."
        else:
            state = "Unknown"
            reason = ("No connection state in WebIf." if not raw else
                      "Unrecognised OSCam connection state.")
        ip = (connection.get("ip") or "").strip().lower() if connection is not None else ""
        port = (connection.get("port") or "").strip() if connection is not None else ""
        groups.setdefault(name, []).append({
            "status": state, "raw": raw or "(missing)", "reason": reason,
            "ip": ip, "port": port
        })
    for name, entries in groups.items():
        if len(entries) == 1:
            entry = entries[0]
            states[name] = {"status": entry["status"], "raw": entry["raw"],
                            "reason": entry["reason"], "matched": True,
                            "count": 1, "entries": entries}
        else:
            states[name] = {
                "status": "Unknown", "raw": "(ambiguous)",
                "reason": "Duplicate WebIf reader label; endpoint verification required.",
                "matched": False, "count": len(entries), "entries": entries
            }
    log("Reader state XML: {} unique labels, {} duplicate labels".format(
        len(states), sum(1 for value in states.values() if value["count"] > 1)))
    return states


def _resolve_duplicate_reader(detail, endpoint):
    """Resolve only exact IP:port matches; never DNS-guess or merge conflicts."""
    if detail.get("count", 1) < 2:
        return detail
    entries = detail.get("entries", [])
    result = dict(detail)
    if not entries:
        return result
    if any(entry.get("status", "").startswith("Online") for entry in entries):
        result.update({"status": "Online (WebIf)", "raw": "CONNECTED",
                       "matched": False,
                       "reason": "Duplicate label group includes an Online reader; whole group protected."})
    elif all(entry.get("status") in ("Offline (WebIf)", "Unknown") for entry in entries):
        result.update({"status": "Unknown", "raw": "(non-online group)",
                       "matched": True, "group_cleanup": True,
                       "reason": "All WebIf entries for this duplicate label are Offline/Error/Unknown; cleanup removes the managed group."})
    return result


def _prune_oscam_block(block_lines, dead_labels):
    if not block_lines:
        return block_lines, 0
    start_marker_line = None
    end_marker_line = None
    content_lines = []
    for ln in block_lines:
        if START_MARKER in ln:
            start_marker_line = ln
            continue
        if END_MARKER in ln:
            end_marker_line = ln
            continue
        content_lines.append(ln)

    new_content = []
    removed = 0
    i = 0
    while i < len(content_lines):
        line = content_lines[i]
        if line.strip().lower() == "[reader]":
            end = i + 1
            while end < len(content_lines):
                nxt = content_lines[end].strip().lower()
                if nxt.startswith("[reader]"):
                    break
                if nxt.startswith("[") and not nxt.startswith("[reader]"):
                    break
                end += 1
            reader_block = content_lines[i:end]
            label = None
            for bl in reader_block:
                s = bl.strip()
                if s.lower().startswith("label"):
                    if "=" in s:
                        label = s.split("=", 1)[1].strip().lower()
                    break
            if label and label in dead_labels:
                removed += 1
                i = end
                continue
            else:
                new_content.extend(reader_block)
                i = end
        else:
            new_content.append(line)
            i += 1

    result = []
    if start_marker_line is not None:
        result.append(start_marker_line)
    result.extend(new_content)
    if end_marker_line is not None:
        result.append(end_marker_line)
    return result, removed


def _prune_cccam_block(block_lines, dead_endpoints):
    if not block_lines:
        return block_lines, 0
    start_marker_line = None
    end_marker_line = None
    content_lines = []
    for ln in block_lines:
        if START_MARKER in ln:
            start_marker_line = ln
            continue
        if END_MARKER in ln:
            end_marker_line = ln
            continue
        content_lines.append(ln)

    new_content = []
    removed = 0
    for ln in content_lines:
        stripped = ln.strip()
        if not stripped or stripped.startswith("#"):
            new_content.append(ln)
            continue
        parsed = _parse_cccam_line(ln) or _parse_newcamd_line(ln)
        if parsed:
            h_lower = parsed[0].lower()
            p_str = parsed[1]
            if (h_lower, p_str) in dead_endpoints:
                removed += 1
                continue
        new_content.append(ln)

    result = []
    if start_marker_line is not None:
        result.append(start_marker_line)
    result.extend(new_content)
    if end_marker_line is not None:
        result.append(end_marker_line)
    return result, removed


def _generated_reader_records(block_lines):
    """Return (label, endpoint) for each generated OSCam/NCam reader."""
    records = []
    current = []
    def add_reader(lines):
        if not lines:
            return
        label = _parse_oscam_label("\n".join(lines))
        endpoint = _parse_oscam_device("\n".join(lines))
        if label and endpoint:
            records.append((label.lower(), (endpoint[0].lower(), endpoint[1])))
    for line in block_lines:
        if line.strip().lower() == "[reader]":
            add_reader(current)
            current = [line]
        elif current:
            current.append(line)
    add_reader(current)
    return records


def prune_inactive_servers_threaded(softcam=None,
                                    timeout=None,
                                    status_cb=None,
                                    finished_cb=None,
                                    progress_every=5):
    if softcam is None:
        softcam = config.plugins.Levi45FreeServer.softcam.value
    if timeout is None:
        try:
            timeout = config.plugins.Levi45FreeServer.checktimeout.value
        except Exception:
            timeout = 5
    try:
        max_workers = config.plugins.Levi45FreeServer.checkthreads.value
    except Exception:
        max_workers = 10
    try:
        prune_mode = config.plugins.Levi45FreeServer.prunemode.value
    except Exception:
        prune_mode = "tcp"
    if prune_mode not in ("auto", "webif", "tcp"):
        prune_mode = "auto"
    if prune_mode == "auto":
        prune_mode = "tcp" if softcam == "cccam" else "webif"
    if softcam == "cccam" and prune_mode == "webif":
        prune_mode = "tcp"  # CCcam WebIf status has a different format.
    try:
        if softcam == "ncam":
            webif_base = config.plugins.Levi45FreeServer.ncamwebif.value or "http://127.0.0.1:8181"
        else:
            webif_base = config.plugins.Levi45FreeServer.oscamwebif.value or "http://127.0.0.1:8888"
        webif_user = config.plugins.Levi45FreeServer.oscamuser.value
        webif_pass = config.plugins.Levi45FreeServer.oscampass.value
    except Exception:
        webif_base = "http://127.0.0.1:8181" if softcam == "ncam" else "http://127.0.0.1:8888"
        webif_user, webif_pass = "", ""

    file_path = get_path_for_softcam(softcam)

    def runner():
        checked = 0
        removed = 0
        error = None
        try:
            if not file_path or not os.path.exists(file_path):
                raise RuntimeError("File does not exist: {}".format(file_path))

            with open(file_path, "r") as f:
                content = f.read()

            log("Prune started: file={} softcam={} mode={} timeout={}s workers={}".format(
                file_path, softcam, prune_mode, timeout, max_workers))

            lines = content.splitlines()
            ranges = _managed_ranges(lines)
            if not ranges:
                if finished_cb:
                    finished_cb(0, 0, None)
                return
            block_lines = [line for a, b in ranges for line in lines[a + 1:b]]

            dead_labels = set()
            reader_states = {}
            review_details = {}
            if prune_mode == "webif":
                if status_cb:
                    status_cb("Checking {} WebIf at {}...".format(softcam.upper(), webif_base))
                body = _fetch_cam_status(webif_base, softcam, webif_user,
                                         webif_pass, timeout=max(3, timeout))
                if _status_xml_root(body) is None:
                    raise RuntimeError("Invalid WebIf status response; cleanup cancelled")
                # Status is informative, not proof of permanent failure.
                reader_states = _parse_oscam_reader_states(body)
                if status_cb:
                    status_cb("WebIf: reader connection states received (review only)")
            # No WebIf credentials required in TCP mode.
            dead_endpoints = set()
            endpoints = []
            if softcam in ("oscam", "ncam"):
                for label, endpoint in _generated_reader_records(block_lines):
                    endpoints.append(endpoint)
            else:
                for line in block_lines:
                    endpoint = _parse_cccam_line(line) or _parse_newcamd_line(line)
                    if endpoint:
                        endpoints.append((endpoint[0].lower(), endpoint[1]))
            if softcam in ("oscam", "ncam"):
                reader_count = sum(1 for line in block_lines if line.strip().lower() == "[reader]")
                parsed_count = len(_generated_reader_records(block_lines))
                if parsed_count != reader_count:
                    raise RuntimeError("Safety stop: parsed {} of {} readers; no changes made".format(parsed_count, reader_count))
            endpoints = sorted(set(endpoints))
            checked = (reader_count if softcam in ("oscam", "ncam") else len([line for line in block_lines if _parse_cccam_line(line) or _parse_newcamd_line(line)]))
            unique_endpoints = len(endpoints)
            if prune_mode in ("tcp", "both") and endpoints:
                if status_cb:
                    status_cb("TCP checking {} servers (no login required)...".format(checked))
                targets = [(i, host, port) for i, (host, port) in enumerate(endpoints)]
                first = _probe_batch_parallel(targets, timeout, max_workers)
                failed = [(i, host, port) for i, (host, port) in enumerate(endpoints)
                          if not first.get(i, False)]
                if status_cb:
                    status_cb("Retrying {} unreachable servers...".format(len(failed)))
                second = _probe_batch_parallel(failed, timeout, max_workers) if failed else {}
                dead_endpoints = set((host, port) for i, host, port in failed
                                     if not second.get(i, False))
                if status_cb:
                    status_cb("TCP checked {}; unreachable twice: {}".format(checked, len(dead_endpoints)))
            # Preview-only: report confirmed connection state, never infer a
            # permanent failure from an absent CAID or a failed TCP probe.
            review_items = []
            online = offline = unknown = 0
            if softcam in ("oscam", "ncam"):
                for label, endpoint in _generated_reader_records(block_lines):
                    if prune_mode == "webif":
                        detail = reader_states.get(label.lower())
                        if detail is not None:
                            detail = _resolve_duplicate_reader(detail, endpoint)
                        if detail is None:
                            detail = {"status": "Unknown", "raw": "(not present)",
                                      "matched": False,
                                      "reason": "Reader label not found in OSCam WebIf snapshot."}
                        state = detail["status"]
                        review_details[label] = detail
                    elif endpoint in dead_endpoints:
                        state = "TCP unreachable (unverified)"
                    else:
                        state = "TCP reachable (not authenticated)"
                    if prune_mode != "webif":
                        review_details[label] = {"status": state, "raw": "(not available)",
                                                 "matched": False,
                                                 "reason": "TCP test does not verify OSCam login."}
                    review_items.append((label, state))
                    if state.startswith("Online"):
                        online += 1
                    elif state.startswith("Offline"):
                        offline += 1
                    else:
                        unknown += 1
            else:
                for line in block_lines:
                    endpoint = _parse_cccam_line(line) or _parse_newcamd_line(line)
                    if endpoint:
                        state = ("TCP unreachable (unverified)" if
                                 (endpoint[0].lower(), endpoint[1]) in dead_endpoints
                                 else "TCP reachable (not authenticated)")
                        review_items.append((endpoint[0] + ":" + endpoint[1], state))
                        unknown += 1
            suspect = offline  # Explicit WebIf disconnects only; not deletion candidates.
            summary = ("Scan preview (BLUE offers cleanup)\n\nReaders: {}  |  Endpoints: {}\nOnline: {}  Offline: {}\nUnknown / unverified: {}\nRemoved: 0").format(
                checked, unique_endpoints, online, offline, unknown)
            log("Prune preview: readers={} unique_endpoints={} suspect={} softcam={} mode={} (no file modified)".format(checked, unique_endpoints, suspect, softcam, prune_mode))
            if status_cb:
                status_cb("PREVIEW_REPORT:" + json.dumps({"summary": summary, "items": review_items, "details": review_details}))
            if finished_cb:
                finished_cb(checked, 0, None)
            return

            if checked and removed > checked // 2:
                raise RuntimeError("Safety stop: {} of {} entries would be removed. No changes made; check network and retry.".format(removed, checked))

            new_content = "\n".join(before_lines + new_block + after_lines)
            if new_content and not new_content.endswith("\n"):
                new_content += "\n"

            backup = file_path + ".prune_backup"
            try:
                with open(backup, "w") as f:
                    f.write(content)
            except Exception as e:
                log("Prune: could not write backup {}: {}".format(backup, e))

            with open(file_path, "w") as f:
                f.write(new_content)

            log("Prune complete: checked={}, removed={} (backup: {})".format(
                checked, removed, backup))
            if status_cb:
                status_cb("Prune complete: {} checked, {} removed.".format(checked, removed))

        except Exception as e:
            error = str(e)
            log("Prune failed: {}".format(e))
            if status_cb:
                status_cb("Prune failed: {}".format(e))

        if finished_cb:
            try:
                finished_cb(checked, removed, error)
            except Exception as e:
                log("finished_cb error: {}".format(e))

    t = threading.Thread(target=runner)
    t.daemon = True
    t.start()
    return t


AUTODOWNLOAD_FILE = "/etc/levi45_autodownload.txt"
SOFTCAM_STATE_FILE = "/etc/levi45_softcam.txt"
OUTPUTFILE_STATE_FILE = "/etc/levi45_outputfile.txt"
ALL_PATHS_STATE_FILE = "/etc/levi45_paths.txt"

last_download_time = None


def is_autodownload_enabled():
    # FIX: Now reads directly from the permanent Enigma2 config
    try:
        return config.plugins.Levi45FreeServer.autodownload.value == "1"
    except:
        return False


def set_autodownload_enabled(enabled):
    try:
        val = "1" if enabled else "0"
        config.plugins.Levi45FreeServer.autodownload.value = val
        with open(AUTODOWNLOAD_FILE, "w") as f:
            f.write("True" if enabled else "False")
        return True
    except:
        return False


def write_softcam_state():
    try:
        with open(SOFTCAM_STATE_FILE, "w") as f:
            f.write(config.plugins.Levi45FreeServer.softcam.value)
        return True
    except Exception as e:
        log("Failed to write softcam state: {}".format(e))
        return False


def write_all_paths_state():
    try:
        with open(ALL_PATHS_STATE_FILE, "w") as f:
            f.write("SOFTCAM={}\n".format(config.plugins.Levi45FreeServer.softcam.value))
            f.write("CCcam={}\n".format(config.plugins.Levi45FreeServer.cccamfile.value))
            f.write("OSCam={}\n".format(config.plugins.Levi45FreeServer.oscamfile.value))
            f.write("NCam={}\n".format(config.plugins.Levi45FreeServer.ncamfile.value))
        return True
    except Exception as e:
        log("Failed to write all-paths state: {}".format(e))
        return False


def write_outputfile_state():
    try:
        active = config.plugins.Levi45FreeServer.softcam.value
        path = get_path_for_softcam(active)
        with open(OUTPUTFILE_STATE_FILE, "w") as f:
            f.write(path)
        write_all_paths_state()
        return True
    except Exception as e:
        log("Failed to write outputfile state: {}".format(e))
        return False


def get_last_download_time():
    global last_download_time
    try:
        time_file = "/tmp/levi45_last_download.txt"
        if os.path.exists(time_file):
            with open(time_file, "r") as f:
                timestamp = float(f.read().strip())
                last_download_time = datetime.datetime.fromtimestamp(timestamp)
                log("Loaded last download time: {}".format(last_download_time))
    except:
        last_download_time = None


def save_last_download_time():
    global last_download_time
    try:
        time_file = "/tmp/levi45_last_download.txt"
        with open(time_file, "w") as f:
            f.write(str(time.mktime(last_download_time.timetuple())))
    except:
        pass


def create_cron_script():
    cron_script = r'''#!/bin/sh
PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin
export PATH

LOG_FILE="/tmp/downloader.log"
AUTODOWNLOAD_FILE="/etc/levi45_autodownload.txt"
PATHS_FILE="/etc/levi45_paths.txt"

log() {
    echo "$(date '+[%Y-%m-%d %H:%M:%S]') $1" >> "$LOG_FILE"
}

if [ ! -f "$AUTODOWNLOAD_FILE" ] || [ "$(cat "$AUTODOWNLOAD_FILE" | tr -d '\r\n ')" != "True" ]; then
    log "Auto-download disabled, skipping"
    exit 0
fi

log "Cron job started"

ACTIVE_SOFTCAM=""
CCcam_PATH="/etc/CCcam.cfg"
OSCam_PATH="/etc/tuxbox/config/oscam.server"
NCam_PATH="/etc/tuxbox/config/ncam.server"

if [ -f "$PATHS_FILE" ]; then
    while IFS='=' read -r key val; do
        key=$(echo "$key" | tr -d '\r\n ')
        val=$(echo "$val" | tr -d '\r\n')
        case "$key" in
            SOFTCAM) ACTIVE_SOFTCAM="$val" ;;
            CCcam)   CCcam_PATH="$val" ;;
            OSCam)   OSCam_PATH="$val" ;;
            NCam)    NCam_PATH="$val" ;;
        esac
    done < "$PATHS_FILE"
fi

get_setting() {
    key="$1"
    if [ -f /etc/enigma2/settings ]; then
        val=$(grep "^${key}=" /etc/enigma2/settings | head -n1 | cut -d= -f2-)
        val=$(echo "$val" | sed 's/^"//; s/"$//; s/[[:space:]]*$//' | tr -d '\r')
        echo "$val"
    fi
}

[ -z "$ACTIVE_SOFTCAM" ] && ACTIVE_SOFTCAM=$(get_setting "config.plugins.Levi45FreeServer.softcam")
[ -z "$ACTIVE_SOFTCAM" ] && ACTIVE_SOFTCAM="cccam"

if [ ! -f "$PATHS_FILE" ]; then
    v=$(get_setting "config.plugins.Levi45FreeServer.cccamfile")
    [ -n "$v" ] && CCcam_PATH="$v"
    v=$(get_setting "config.plugins.Levi45FreeServer.oscamfile")
    [ -n "$v" ] && OSCam_PATH="$v"
    v=$(get_setting "config.plugins.Levi45FreeServer.ncamfile")
    [ -n "$v" ] && NCam_PATH="$v"
fi

case "$ACTIVE_SOFTCAM" in
    cccam) OUTPUT_FILE="$CCcam_PATH" ;;
    oscam) OUTPUT_FILE="$OSCam_PATH" ;;
    ncam)  OUTPUT_FILE="$NCam_PATH" ;;
    *)     OUTPUT_FILE="$CCcam_PATH" ;;
esac

log "Active softcam: $ACTIVE_SOFTCAM"
log "Output file: $OUTPUT_FILE"

URLS="
https://cccam-premium.pro/free-cccam/
https://cccamsate.com/free
https://cccamiptv.tv/cccamfree/#page-content
https://cccam.net/freecccam
https://cccamia.com/cccam-free/
https://cccamhub.com/cccamfree/
https://cccamgalaxy.com/
https://cccamfree48h.yolasite.com/server-2.php
https://cccamx.com/free-cccam
https://bosscccam.co/Test.php
https://iptv-15days.blogspot.com/
https://raw.githubusercontent.com/levi-45/free-cccam/main/servers.txt
"

if command -v python3 >/dev/null 2>&1; then
    PY=python3
elif command -v python >/dev/null 2>&1; then
    PY=python
else
    PY=""
fi

if [ -n "$PY" ]; then
    YESTERDAY=$($PY -c "from datetime import datetime, timedelta; print((datetime.now() - timedelta(days=1)).strftime('%Y-%m-%d'))" 2>/dev/null)
    TODAY=$($PY -c "from datetime import datetime; print(datetime.now().strftime('%Y-%m-%d'))" 2>/dev/null)
fi

if [ -z "$YESTERDAY" ]; then
    YESTERDAY=$(date -d "yesterday" +%Y-%m-%d 2>/dev/null || date -D "%s" -d "@$(( $(date +%s) - 86400 ))" +%Y-%m-%d 2>/dev/null)
fi
if [ -z "$TODAY" ]; then
    TODAY=$(date +%Y-%m-%d)
fi

URLS="$URLS
https://testious.com/old-free-cccam-servers/$YESTERDAY/
https://testious.com/old-free-cccam-servers/$TODAY/
"

TEMP_FILE="/tmp/servers_temp.txt"
FINAL_FILE="/tmp/servers_final.txt"
CONVERTED_FILE="/tmp/servers_converted.txt"
DOWNLOAD_FILE="/tmp/servers_dl.tmp"

: > "$FINAL_FILE"
: > "$TEMP_FILE"
: > "$CONVERTED_FILE"

convert_to_oscam() {
    line="$1"
    set -- $line

    proto=$(echo "$1" | tr -d ':')
    host="$2"
    port="$3"
    user="$4"
    password="$5"

    shift 5
    key=""
    for part in "$@"; do
        key="${key}${part}"
    done

    [ -z "$host" ] || [ -z "$port" ] || [ -z "$user" ] || [ -z "$password" ] && return

    if [ "$proto" = "C" ]; then
        echo "[reader]"
        echo "label = ${host}_${port}"
        echo "protocol = cccam"
        echo "device = ${host},${port}"
        echo "user = ${user}"
        echo "password = ${password}"
        echo "group = 1"
        echo "cccversion = 2.1.2"
        echo "inactivitytimeout = 1"
        echo "reconnecttimeout = 30"
        echo "disablelog = 1"
        echo ""
    elif [ "$proto" = "N" ] && [ -n "$key" ]; then
        echo "[reader]"
        echo "label=${host}_${port}"
        echo "enable=1"
        echo "protocol=newcamd"
        echo "key=${key}"
        echo "device=${host},${port}"
        echo "user=${user}"
        echo "password=${password}"
        echo "group=1"
        echo "inactivitytimeout=1"
        echo "reconnecttimeout=30"
        echo "lb_weight=100"
        echo "cccversion=2.1.2"
        echo "cccmaxhops=10"
        echo "cccwantemu=1"
        echo "ccckeepalive=1"
        echo ""
    fi
}

parse_servers() {
    content="$1"
    url="$2"

    clean=$(echo "$content" \
        | sed 's/<[^>]*>//g' \
        | tr -d '\r' \
        | sed 's/&nbsp;/ /g; s/&amp;/\&/g; s/&#58;/:/g')

    echo "$clean" | grep -oE 'C:[[:space:]]*[A-Za-z0-9._-]+[[:space:]]+[0-9]+[[:space:]]+[A-Za-z0-9._-]+[[:space:]]+[A-Za-z0-9._-]+' >> "$TEMP_FILE"

    echo "$clean" | grep -oE 'N:[[:space:]]*[A-Za-z0-9._-]+[[:space:]]+[0-9]+[[:space:]]+[A-Za-z0-9._-]+[[:space:]]+[A-Za-z0-9._-]+[[:space:]]+[0-9a-fA-F ]+' \
        | sed 's/[[:space:]]*$//' >> "$TEMP_FILE"

    before=$(wc -l < "$TEMP_FILE" 2>/dev/null || echo 0)
    log "Parsed $url (temp lines now: $before)"
}

echo "$URLS" | while IFS= read -r URL; do
    [ -z "$URL" ] && continue
    case "$URL" in
        http*) ;;
        *) continue ;;
    esac

    log "Downloading from $URL"

    if curl -k -s -L --max-time 30 -A "Mozilla/5.0" "$URL" -o "$DOWNLOAD_FILE"; then
        if [ -s "$DOWNLOAD_FILE" ]; then
            CONTENT=$(cat "$DOWNLOAD_FILE")
            parse_servers "$CONTENT" "$URL"
        else
            log "Empty response from $URL"
        fi
    else
        log "Failed to download from $URL"
    fi
    rm -f "$DOWNLOAD_FILE"
done

if [ -s "$TEMP_FILE" ]; then
    grep -E '^[CN]:' "$TEMP_FILE" \
        | sed 's/#.*//' \
        | sed 's/[[:space:]]*$//' \
        | sort -u > "$FINAL_FILE"

    FINAL_COUNT=$(wc -l < "$FINAL_FILE")
    log "Found $FINAL_COUNT unique servers after processing"

    if [ "$FINAL_COUNT" -gt 0 ]; then
        START_MARKER="# >>>>>> BEGIN AUTO-GENERATED BY Levi45FreeServer <<<<<<"
        END_MARKER="# >>>>>> END AUTO-GENERATED BY Levi45FreeServer <<<<<<"

        if [ -f "$OUTPUT_FILE" ]; then
            cp "$OUTPUT_FILE" "$OUTPUT_FILE.backup"
            sed -i "/$START_MARKER/,/$END_MARKER/d" "$OUTPUT_FILE"
        else
            mkdir -p "$(dirname "$OUTPUT_FILE")" 2>/dev/null
            touch "$OUTPUT_FILE"
        fi

        {
            echo ""
            echo "$START_MARKER"
            echo "# Generated on $(date '+%Y-%m-%d %H:%M:%S')"
            echo "# Total servers: $FINAL_COUNT"

            if [ "$ACTIVE_SOFTCAM" = "oscam" ] || [ "$ACTIVE_SOFTCAM" = "ncam" ]; then
                log "Converting servers to OSCam/NCam format"
                : > "$CONVERTED_FILE"
                while IFS= read -r line; do
                    convert_to_oscam "$line" >> "$CONVERTED_FILE"
                done < "$FINAL_FILE"
                cat "$CONVERTED_FILE"
            else
                cat "$FINAL_FILE"
            fi

            echo "$END_MARKER"
        } >> "$OUTPUT_FILE"

        log "Success! Added $FINAL_COUNT servers to $OUTPUT_FILE"
    else
        log "No valid servers found after processing"
    fi
else
    log "No servers found from any source"
fi

rm -f "$TEMP_FILE" "$FINAL_FILE" "$CONVERTED_FILE" "$DOWNLOAD_FILE" 2>/dev/null

log "Cron job completed"
'''
    try:
        script_path = os.path.join(PLUGIN_PATH, "cron_download.sh")
        with open(script_path, "w") as f:
            f.write(cron_script)
        os.chmod(script_path, 0o755)
        log("Cron download script created at {}".format(script_path))
        return True
    except Exception as e:
        log("Error creating cron script: {}".format(e))
        return False


def setup_cron_job():
    if not find_executable("crontab"):
        log("crontab unavailable; background cron scheduling skipped")
        return
    try:
        os.system("crontab -l 2>/dev/null | grep -v 'Levi45FreeServer' | crontab -")
        if (is_autodownload_enabled() and
            config.plugins.Levi45FreeServer.enablecron.value == "1"):
            download_time = config.plugins.Levi45FreeServer.downloadtime.value
            hour = download_time[0]
            minute = download_time[1]
            cron_cmd = "{} {} * * * /bin/sh {}/cron_download.sh\n".format(
                minute, hour, PLUGIN_PATH)
            os.system("(crontab -l 2>/dev/null; echo \"{}\") | crontab -".format(cron_cmd))
            log("Cron job setup for {}:{} daily".format(hour, minute))
        else:
            log("Cron job disabled or removed")
    except Exception as e:
        log("Error setting up cron job: {}".format(e))


get_last_download_time()


def connect_e2_timer(timer, callback):
    """Attach a callback on standard Enigma2 and DreamOS (retain connection)."""
    errors = []
    for method in ("callback", "timeout"):
        try:
            if method == "callback":
                timer.callback.append(callback)
                return None
            signal = timer.timeout
            try:
                connection = signal.connect(callback)
                return connection
            except (AttributeError, TypeError):
                signal.get().append(callback)
                return None
        except Exception as exc:
            errors.append(str(exc))
    raise RuntimeError("No supported eTimer signal: " + "; ".join(errors))


class ThreadedProgressPoller(object):
    def __init__(self, screen, interval_ms=400):
        self.screen = screen
        self.q = queue_module.Queue()
        self.timer = eTimer()
        self._on_status = None
        self._on_finished = None
        self._connection = connect_e2_timer(self.timer, self._drain)
        self._interval = interval_ms
        self._running = False

    def set_status_handler(self, fn):
        self._on_status = fn

    def set_finished_handler(self, fn):
        self._on_finished = fn

    def post_status(self, text):
        self.q.put(("status", text))

    def post_finished(self, payload):
        self.q.put(("finished", payload))

    def start(self):
        if not self._running:
            self._running = True
            self.timer.start(self._interval, False)

    def stop(self):
        self._running = False
        try:
            self.timer.stop()
        except Exception:
            pass

    def _drain(self):
        if not self._running:
            return
        last_status = None
        finished_payload = None
        try:
            while True:
                kind, payload = self.q.get_nowait()
                if kind == "status":
                    last_status = payload
                elif kind == "finished":
                    finished_payload = payload
        except queue_module.Empty:
            pass

        if last_status is not None and self._on_status:
            try:
                self._on_status(last_status)
            except Exception as e:
                log("status handler error: {}".format(e))

        if finished_payload is not None:
            self.stop()
            if self._on_finished:
                try:
                    self._on_finished(*finished_payload)
                except Exception as e:
                    log("finished handler error: {}".format(e))


# ============================================================================
# Section headers
# ============================================================================
HEADER_PREFIX = "-------- "


def make_header_label(title):
    return HEADER_PREFIX + title + " --------"


def _make_header_config(text):
    return ConfigSelection(choices=[("h", text)], default="h")


# ============================================================================
# Settings screen (scaled for both HD and Full HD)
# ============================================================================
class Levi45FreeServerSettings(ConfigListScreen, Screen):
    def __init__(self, session):
        # Leave room for the Enigma2 window title and TV overscan.
        S = lambda value: max(1, int(round(globals()["S"](value) * 0.90)))
        # Design coordinates are based on 1920x1080, then scaled to the
        # actual screen. On HD (1280x720) the whole layout shrinks to ~67%.
        W  = S(1000)
        H  = S(900)
        TITLE_H = S(70)

        PAD   = S(20)
        X     = S(35)
        CW    = W - 2 * X
        Y_CFG = S(100)
        CFG_H = H - Y_CFG - S(130)

        DESC_Y = H - S(105)
        DESC_H = S(50)

        HINT_Y = H - S(45)
        HINT_H = S(45)

        FONT_TITLE = S(32)
        FONT_VER   = S(24)
        FONT_DESC  = S(20)
        FONT_HINT  = S(22)

        # Smaller QR codes, positioned above the description strip so they
        # no longer overlap the config list rows.
        IMG_W = S(90)
        IMG_H = S(90)
        IMG_Y = DESC_Y - S(100)
        IMG1_X = S(360)
        IMG2_X = S(540)

        self.skin = (
            '<screen name="Levi45FreeServerSettings" position="center,center" '
            'size="{w},{h}" title="Levi45 Free Server - Settings">'
            '<eLabel position="0,0" size="{w},{th}" backgroundColor="#0b3d5c" zPosition="-1" />'
            '<widget name="title_label" position="{x0},{y_t}" size="{tw},{th_t}" '
            'font="Regular;{f_t}" foregroundColor="#ffffff" transparent="1" />'
            '<widget name="version_label" position="{vx},{y_t}" size="{vw},{th_t}" '
            'font="Regular;{f_v}" foregroundColor="#a7d8ff" transparent="1" halign="right" />'

            '<eLabel position="{p},{y_cfg_box}" size="{cw_box},{h_cfg_box}" backgroundColor="#101820" zPosition="-1" />'
            '<widget name="config" position="{x},{y_cfg}" size="{cw_cfg},{h_cfg}" scrollbarMode="showOnDemand" />'

            '<eLabel position="{p},{y_desc_box}" size="{cw_box},{h_desc_box}" backgroundColor="#182830" zPosition="-1" />'
            '<widget name="description" position="{x},{y_desc}" size="{cw_desc},{h_desc}" '
            'font="Regular;{f_d}" foregroundColor="#a7d8ff" transparent="1" />'

            '<eLabel position="0,{y_hint_box}" size="{w},{h_hint_box}" backgroundColor="#0b3d5c" zPosition="-1" />'
            '<widget name="hint_label" position="{x},{y_hint}" size="{cw_hint},{h_hint}" '
            'font="Regular;{f_h}" foregroundColor="#ffd766" transparent="1" halign="center" />'

            '</screen>'
        ).format(
            w=W, h=H,
            th=TITLE_H,
            x0=S(30), y_t=S(18), tw=S(600), th_t=S(40),
            vx=S(710), vw=S(270),
            f_t=FONT_TITLE, f_v=FONT_VER,

            p=PAD,
            y_cfg_box=S(85), cw_box=W - 2 * PAD, h_cfg_box=H - S(185),
            x=X, y_cfg=Y_CFG, cw_cfg=CW, h_cfg=CFG_H,

            y_desc_box=DESC_Y, h_desc_box=DESC_H,
            y_desc=DESC_Y + S(10), cw_desc=CW, h_desc=S(32),
            f_d=FONT_DESC,

            y_hint_box=HINT_Y, h_hint_box=HINT_H,
            y_hint=HINT_Y + S(8), cw_hint=W - S(60), h_hint=S(34),
            f_h=FONT_HINT,

            i1x=IMG1_X, i2x=IMG2_X, iy=IMG_Y, iw=IMG_W, ih=IMG_H)

        Screen.__init__(self, session)
        self.setup_title = "Levi45 Free Server Settings"

        self.list = []
        ConfigListScreen.__init__(self, self.list, session=session)

        self["title_label"]   = Label("Levi45 Free Server - Settings")
        self["version_label"] = Label("v" + PLUGIN_VERSION)
        self["hint_label"]    = Label("Green = Save   |   Red / Exit = Cancel   |   OK = Edit / Browse")
        self["description"]   = Label("Use Up/Down to move, Left/Right to change values.")

        self.current_softcam = config.plugins.Levi45FreeServer.softcam.value
        self.autodownload_enabled = is_autodownload_enabled()
        self.autodownload_value = 1 if self.autodownload_enabled else 0

        # FIX: Tied directly to the permanent config variable
        self.autodownload = getConfigListEntry("- Auto Download", config.plugins.Levi45FreeServer.autodownload)
        self.downloadtime = getConfigListEntry("- Download Time", config.plugins.Levi45FreeServer.downloadtime)
        self.softcam = getConfigListEntry("- Softcam Type", config.plugins.Levi45FreeServer.softcam)
        self.cccamfile = getConfigListEntry("- CCcam File (OK to browse)", config.plugins.Levi45FreeServer.cccamfile)
        self.oscamfile = getConfigListEntry("- OSCam File (OK to browse)", config.plugins.Levi45FreeServer.oscamfile)
        self.ncamfile = getConfigListEntry("- NCam File (OK to browse)", config.plugins.Levi45FreeServer.ncamfile)
        self.downloadinterval = getConfigListEntry("- Download Interval (hours)", config.plugins.Levi45FreeServer.downloadinterval)
        self.enablecron = getConfigListEntry("- Enable Background Cron", config.plugins.Levi45FreeServer.enablecron)
        self.checkinactive = getConfigListEntry("- Check & Remove Inactive", config.plugins.Levi45FreeServer.checkinactive)
        self.checktimeout = getConfigListEntry("- Check Timeout (seconds)", config.plugins.Levi45FreeServer.checktimeout)
        self.checkthreads = getConfigListEntry("- Check Parallel Threads", config.plugins.Levi45FreeServer.checkthreads)
        self.prunemode = getConfigListEntry("- Prune Mode", config.plugins.Levi45FreeServer.prunemode)
        self.oscamwebif = getConfigListEntry("- OSCam Webif URL", config.plugins.Levi45FreeServer.oscamwebif)
        self.ncamwebif = getConfigListEntry("- NCam Webif URL", config.plugins.Levi45FreeServer.ncamwebif)
        self.oscamuser = getConfigListEntry("- OSCam Webif User", config.plugins.Levi45FreeServer.oscamuser)
        self.oscampass = getConfigListEntry("- OSCam Webif Password", config.plugins.Levi45FreeServer.oscampass)
        self.showinmainmenu = getConfigListEntry("- Show in Main Menu", config.plugins.Levi45FreeServer.showinmainmenu)

        self.header_download = getConfigListEntry(make_header_label("Download"), _make_header_config(make_header_label("Download")))
        self.header_files    = getConfigListEntry(make_header_label("Softcam Files"), _make_header_config(make_header_label("Softcam Files")))
        self.header_sched    = getConfigListEntry(make_header_label("Scheduler"), _make_header_config(make_header_label("Scheduler")))
        self.header_check    = getConfigListEntry(make_header_label("Inactive Checking"), _make_header_config(make_header_label("Inactive Checking")))
        self.header_webif    = getConfigListEntry(make_header_label("OSCam Webif"), _make_header_config(make_header_label("OSCam Webif")))
        self.header_ui       = getConfigListEntry(make_header_label("Interface"), _make_header_config(make_header_label("Interface")))

        self.list.append(self.header_download)
        self.list.append(self.autodownload)
        self.list.append(self.downloadtime)
        self.list.append(self.softcam)
        self.list.append(self.header_files)
        self.list.append(self.cccamfile)
        self.list.append(self.oscamfile)
        self.list.append(self.ncamfile)
        self.list.append(self.header_sched)
        self.list.append(self.downloadinterval)
        self.list.append(self.enablecron)
        self.list.append(self.header_check)
        self.list.append(self.checkinactive)
        self.list.append(self.checktimeout)
        self.list.append(self.checkthreads)
        self.list.append(self.prunemode)
        self.list.append(self.header_webif)
        self.list.append(self.oscamwebif)
        self.list.append(self.ncamwebif)
        self.list.append(self.oscamuser)
        self.list.append(self.oscampass)
        self.list.append(self.header_ui)
        self.list.append(self.showinmainmenu)

        self["config"].list = self.list
        self["config"].l.setList(self.list)

        self["actions"] = ActionMap(["SetupActions", "ColorActions"],
        {
            "ok": self.keyOK,
            "cancel": self.cancel,
            "green": self.save,
            "red": self.cancel,
        }, -2)

        try:
            self.onLayoutFinish.append(self.update_description)
        except Exception:
            pass
        self.update_description()

        log("Settings screen opened (scale={:.2f})".format(SCALE))

    DESCRIPTIONS = {
        "Auto Download":       "Enable/disable automatic downloads while the plugin is open.",
        "Download Time":       "Time of day for the daily scheduled download.",
        "Softcam Type":        "Which softcam the plugin writes servers for.",
        "CCcam File":          "Output file for CCcam. Press OK to open the file browser.",
        "OSCam File":          "Output file for OSCam. Press OK to open the file browser.",
        "NCam File":           "Output file for NCam. Press OK to open the file browser.",
        "Download Interval":   "Minimum hours between automatic downloads.",
        "Enable Background":   "Install a crontab entry so downloads run even if plugin is closed.",
        "Check & Remove":      "How often to test servers: before writing, at plugin start, both, or never.",
        "Check Timeout":       "TCP connect timeout per server (1-30 seconds).",
        "Check Parallel":      "How many servers to test simultaneously (1-50).",
        "Prune Mode":          "TCP only, OSCam Webif status (best), or both.",
        "NCam Webif URL": "NCam WebIf address, normally http://127.0.0.1:8181",
        "OSCam Webif URL":     "URL of the OSCam webif, e.g. http://127.0.0.1:8888",
        "OSCam Webif User":    "Username for OSCam webif (leave blank if none).",
        "OSCam Webif Password":"Password for OSCam webif (leave blank if none).",
        "Show in Main Menu":   "Show the plugin in the main menu as well as the plugins menu.",
    }

    def _is_header(self, entry):
        try:
            if not entry or not entry[0]:
                return False
            return entry[0].startswith(HEADER_PREFIX)
        except Exception:
            return False

    def update_description(self):
        try:
            cur = self["config"].getCurrent()
            if not cur:
                self["description"].setText("Use Up/Down to move, Left/Right to change values.")
                return
            label = cur[0] or ""
            if self._is_header(cur):
                self["description"].setText(label.replace("-", "").strip())
                return
            for key, txt in self.DESCRIPTIONS.items():
                if key in label:
                    self["description"].setText(txt)
                    return
            self["description"].setText("Use Up/Down to move, Left/Right to change values.")
        except Exception as e:
            log("update_description error: {}".format(e))

    def keyOK(self):
        current = self["config"].getCurrent()
        if not current:
            return
        label = current[0] or ""
        if self._is_header(current):
            return
        if "File (OK to browse)" in label:
            self.openFileBrowser(label)
        else:
            self.save()

    def openFileBrowser(self, entry_label):
        if "CCcam File" in entry_label:
            current_path = config.plugins.Levi45FreeServer.cccamfile.value
            softcam_key = "cccam"
        elif "NCam File" in entry_label:
            current_path = config.plugins.Levi45FreeServer.ncamfile.value
            softcam_key = "ncam"
        else:
            current_path = config.plugins.Levi45FreeServer.oscamfile.value
            softcam_key = "oscam"

        if current_path and os.path.isdir(os.path.dirname(current_path)):
            start_dir = os.path.dirname(current_path)
        elif current_path and os.path.isdir(current_path):
            start_dir = current_path
        else:
            start_dir = "/etc"

        self.session.openWithCallback(
            lambda p: self.fileBrowserCallback(p, softcam_key),
            FileBrowserScreen,
            start_dir
        )

    def fileBrowserCallback(self, path, softcam_key):
        if not path:
            log("File browser cancelled")
            return

        if os.path.isdir(path):
            default_file = {
                "cccam": "CCcam.cfg",
                "oscam": "oscam.server",
                "ncam": "ncam.server"
            }.get(softcam_key, "servers.txt")
            path = os.path.join(path, default_file)

        log("File browser selected for {}: {}".format(softcam_key, path))
        self.setOutputPath(softcam_key, path)

    def setOutputPath(self, softcam_key, path):
        set_path_for_softcam(softcam_key, path)
        sync_active_outputfile()

        entry_label = {
            "cccam": "- CCcam File (OK to browse)",
            "oscam": "- OSCam File (OK to browse)",
            "ncam": "- NCam File (OK to browse)",
        }[softcam_key]

        config_obj = {
            "cccam": config.plugins.Levi45FreeServer.cccamfile,
            "oscam": config.plugins.Levi45FreeServer.oscamfile,
            "ncam": config.plugins.Levi45FreeServer.ncamfile,
        }[softcam_key]

        new_entry = getConfigListEntry(entry_label, config_obj)
        try:
            new_entry[1].value = path
        except Exception as e:
            log("Could not set new_entry[1].value: {}".format(e))

        match_token = entry_label.split(" (")[0].replace("- ", "")
        for i, entry in enumerate(self.list):
            if entry[0] and match_token in entry[0]:
                self.list[i] = new_entry
                break
        for i, entry in enumerate(self["config"].list):
            if entry[0] and match_token in entry[0]:
                self["config"].list[i] = new_entry
                break

        self["config"].setList(self.list)
        self.update_description()

    def save(self):
        sync_active_outputfile()

        for x in self["config"].list:
            try:
                if x[1] is None:
                    continue
                if x[0] and x[0].startswith(HEADER_PREFIX):
                    continue
                x[1].save()
            except Exception as e:
                log("Error saving entry {}: {}".format(x[0], e))

        try:
            for attr in ("cccamfile", "oscamfile", "ncamfile", "outputfile",
                         "showinmainmenu", "checkinactive", "checktimeout",
                         "checkthreads", "prunemode", "oscamwebif", "ncamwebif",
                         "oscamuser", "oscampass", "autodownload"):
                getattr(config.plugins.Levi45FreeServer, attr).save()
        except Exception as e:
            log("Error saving output paths: {}".format(e))

        enabled = (config.plugins.Levi45FreeServer.autodownload.value == "1")
        set_autodownload_enabled(enabled)

        write_softcam_state()
        write_outputfile_state()
        create_cron_script()
        setup_cron_job()
        configfile.save()

        log("All settings saved")
        self.close(True)

    def cancel(self):
        for x in self["config"].list:
            try:
                if x[1] is None:
                    continue
                if x[0] and x[0].startswith(HEADER_PREFIX):
                    continue
                x[1].cancel()
            except Exception:
                pass
        self.close(False)


# ============================================================================
# File browser (scaled)
# ============================================================================
class FileBrowserScreen(Screen):
    def __init__(self, session, start_dir="/etc"):
        W = S(900)
        H = S(700)
        X = S(25)
        CW = W - 2 * X

        self.skin = (
            '<screen name="Levi45FileBrowser" position="center,center" '
            'size="{w},{h}" title="Select Output File">'
            '<widget name="path_label" position="{x},{y1}" size="{cw},{h1}" '
            'font="Regular;{f1}" foregroundColor="#ffd766" transparent="1" />'
            '<widget name="list" position="{x},{y2}" size="{cw},{h2}" scrollbarMode="showOnDemand" />'
            '<eLabel text="OK = Select    Green = Use this directory    Red / Exit = Cancel" '
            'position="{x},{y3}" size="{cw},{h3}" font="Regular;{f2}" foregroundColor="#a7d8ff" />'
            '</screen>'
        ).format(
            w=W, h=H, x=X, cw=CW,
            y1=S(20), h1=S(40), f1=S(24),
            y2=S(70), h2=S(540),
            y3=S(630), h3=S(40), f2=S(22))

        Screen.__init__(self, session)
        self.session = session
        self.current_dir = start_dir if os.path.isdir(start_dir) else "/"
        self.entries = []

        self["path_label"] = Label("")
        self["list"] = MenuList([])
        self["actions"] = ActionMap(
            ["OkCancelActions", "ColorActions", "DirectionActions"],
            {
                "ok": self.enter,
                "cancel": self.cancel,
                "green": self.select_current_dir,
                "red": self.cancel,
            }, -1)
        self.populate()

    def populate(self):
        items = []
        try:
            names = sorted(os.listdir(self.current_dir), key=lambda s: s.lower())
        except Exception as e:
            log("FileBrowser: cannot list {}: {}".format(self.current_dir, e))
            names = []

        parent = os.path.dirname(self.current_dir.rstrip("/"))
        if not parent:
            parent = "/"
        if self.current_dir != "/":
            items.append(("..", parent, True))

        for name in names:
            full = os.path.join(self.current_dir, name)
            try:
                is_dir = os.path.isdir(full)
            except Exception:
                is_dir = False
            items.append((name, full, is_dir))

        self.entries = items
        display = ["[DIR]  " + e[0] if e[2] else "       " + e[0] for e in items]
        self["list"].setList(display)
        self["path_label"].setText("Path: " + self.current_dir)

    def enter(self):
        idx = self["list"].getSelectionIndex()
        if idx is None or idx < 0 or idx >= len(self.entries):
            return
        name, full, is_dir = self.entries[idx]
        if is_dir:
            self.current_dir = full
            self.populate()
        else:
            self.close(full)

    def select_current_dir(self):
        softcam = config.plugins.Levi45FreeServer.softcam.value
        default_file = {"cccam": "CCcam.cfg", "oscam": "oscam.server",
                        "ncam": "ncam.server"}.get(softcam, "servers.txt")
        full = os.path.join(self.current_dir, default_file)

        def confirm(result):
            if result:
                self.close(full)

        self.session.openWithCallback(
            confirm, MessageBox,
            _("Use this directory?\n\n{}").format(full),
            MessageBox.TYPE_YESNO)

    def cancel(self):
        self.close(None)


# ============================================================================
# Main plugin screen (scaled)
# ============================================================================
def e2_native_text(value):
    """Enigma2 Python 2 SWIG labels require UTF-8 str, not unicode."""
    if value is None:
        value = ""
    if sys.version_info[0] < 3:
        if isinstance(value, unicode):
            return value.encode("utf-8", "replace")
        if isinstance(value, str):
            return value
        return str(value)
    if isinstance(value, bytes):
        return value.decode("utf-8", "replace")
    return value if isinstance(value, str) else str(value)


def _managed_ranges(lines):
    """Validate every managed marker pair; never include unmarked readers."""
    pairs = [(START_MARKER, END_MARKER)]
    for name in ("CCcamIPTV", "FullPackage", "Dhoom", "CCcamNinja", "Testcline"):
        pairs.append(("# >>> Levi45 {} manual trial >>>".format(name),
                      "# <<< Levi45 {} manual trial <<<".format(name)))
    starts = dict((a, b) for a, b in pairs)
    ends = set(b for a, b in pairs)
    active = None
    seen = set()
    ranges = []
    for i, line in enumerate(lines):
        marker = line.strip()
        if marker in starts:
            if active is not None or marker in seen:
                raise ValueError("Overlapping or duplicate Levi45 markers; no changes made")
            seen.add(marker)
            active = (i, starts[marker])
        elif marker in ends:
            if active is None or marker != active[1]:
                raise ValueError("Mismatched Levi45 markers; no changes made")
            ranges.append((active[0], i))
            active = None
    if active is not None:
        raise ValueError("Unclosed Levi45 markers; no changes made")
    return ranges


def _managed_reader_blocks(lines):
    blocks = []
    for a, b in _managed_ranges(lines):
        boundaries = []
        for i in range(a + 1, b):
            text = lines[i].strip()
            if text.lower() == "[reader]":
                boundaries.append(i)
            elif text.startswith("["):
                raise ValueError("Unexpected section inside managed readers")
        for index, start in enumerate(boundaries):
            end = boundaries[index + 1] if index + 1 < len(boundaries) else b
            blocks.append((start, end))
    return blocks


def _disable_selected_generated_readers(path, selected, expected_signature):
    """Conservative, reversible edit of uniquely labelled generated OSCam readers."""
    import hashlib
    import tempfile
    if not path or not os.path.isfile(path) or os.path.islink(path):
        raise ValueError("OSCam configuration file is missing or unsafe")
    with open(path, "rb") as fh:
        original = fh.read()
    if hashlib.sha256(original).hexdigest() != expected_signature:
        raise ValueError("Configuration changed since scan; rescan before editing")
    lines = original.decode("latin1").splitlines(True)
    blocks = _managed_reader_blocks(lines)
    selected = set(x.lower() for x in selected)
    candidates = {}
    for start, end in blocks:
        labels = []
        for line in lines[start:end]:
            m = re.match(r'^\s*label\s*=\s*([^#;\r\n]+)', line, re.I)
            if m:
                labels.append(m.group(1).strip().lower())
        if len(labels) == 1 and labels[0] in selected:
            candidates.setdefault(labels[0], []).append((start, end))
    if set(candidates) != selected or any(len(v) != 1 for v in candidates.values()):
        raise ValueError("Reader labels are missing or duplicated; no changes made")
    replacements = {}
    for label, ranges in candidates.items():
        start, end = ranges[0]
        enable_lines = [i for i in range(start, end) if re.match(r'^\s*enable\s*=', lines[i], re.I)]
        if len(enable_lines) > 1:
            raise ValueError("Duplicate enable setting; no changes made")
        if enable_lines:
            idx = enable_lines[0]
            replacements[idx] = re.sub(r'(?i)^(\s*enable\s*=\s*)[^\r\n#;]*', r'\g<1>0', lines[idx])
        else:
            # Insert directly after [reader], preserving existing newline convention.
            newline = '\r\n' if lines[start].endswith('\r\n') else '\n'
            replacements[start] = lines[start] + 'enable = 0' + newline
    updated = ''.join(replacements.get(i, line) for i, line in enumerate(lines))
    updated = updated.encode("latin1")
    if updated == original:
        raise ValueError("All selected readers are already disabled")
    stamp = datetime.datetime.now().strftime('%Y%m%d-%H%M%S')
    backup = path + '.levi45-backup-' + stamp
    if os.path.exists(backup):
        raise ValueError("Backup filename already exists; retry later")
    shutil.copy2(path, backup)
    fd, temp = tempfile.mkstemp(prefix='.levi45-', dir=os.path.dirname(path))
    try:
        with os.fdopen(fd, 'wb') as fh:
            fh.write(updated)
            fh.flush()
            os.fsync(fh.fileno())
        shutil.copymode(path, temp)
        # Avoid overwriting edits made after the initial read.
        with open(path, 'rb') as fh:
            if hashlib.sha256(fh.read()).hexdigest() != expected_signature:
                raise ValueError("Configuration changed during edit; backup saved, no changes made")
        os.rename(temp, path)
    finally:
        if os.path.exists(temp):
            os.unlink(temp)
    return backup, len(selected)


def _delete_generated_inactive_readers(path, labels, expected_signature):
    """Delete exact, uniquely labelled reader blocks inside Levi45 markers only."""
    import hashlib
    import tempfile
    if not path or not os.path.isfile(path) or os.path.islink(path):
        raise ValueError("Unsafe or missing server configuration")
    with open(path, "rb") as fh:
        original = fh.read()
    if hashlib.sha256(original).hexdigest() != expected_signature:
        raise ValueError("Configuration changed since scan; rescan first")
    lines = original.decode("latin1").splitlines(True)
    blocks = _managed_reader_blocks(lines)
    if not blocks:
        raise ValueError("No managed reader blocks found")
    selected = set(x.lower() for x in labels)
    if not selected:
        raise ValueError("No eligible readers selected")
    found = {}
    ranges = []
    for start, end in blocks:
        block = lines[start:end]
        # A non-reader section inside the marker makes deletion unsafe.
        if any(line.strip().startswith("[") and
               line.strip().lower() != "[reader]" for line in block):
            raise ValueError("Unexpected section inside generated readers")
        matches = [m.group(1).strip().lower() for line in block
                   for m in [re.match(r'^\s*label\s*=\s*([^#;\r\n]+)', line, re.I)]
                   if m]
        if len(matches) != 1:
            raise ValueError("Missing or repeated reader label; no changes made")
        label = matches[0]
        found[label] = found.get(label, 0) + 1
        if label in selected:
            ranges.append((start, end))
    # A duplicate label anywhere else in the file makes identity ambiguous.
    all_labels = [m.group(1).strip().lower() for line in lines
                  for m in [re.match(r'^\s*label\s*=\s*([^#;\r\n]+)', line, re.I)] if m]
    if any(all_labels.count(label) != found.get(label, 0) for label in selected):
        raise ValueError("Duplicate reader label elsewhere in config; no changes made")
    if any(not found.get(label) for label in selected) or len(ranges) != sum(found[label] for label in selected):
        raise ValueError("Eligible reader label is absent or duplicated")
    # Keep every byte outside selected blocks. Preserve marker lines.
    remove = set(i for start, end in ranges for i in range(start, end))
    updated = "".join(line for i, line in enumerate(lines) if i not in remove).encode("latin1")
    if updated == original:
        raise ValueError("No changes to save")
    stamp = datetime.datetime.now().strftime("%Y%m%d-%H%M%S")
    backup = path + ".levi45-backup-" + stamp
    if os.path.exists(backup):
        raise ValueError("Backup filename already exists")
    shutil.copy2(path, backup)
    fd, temp = tempfile.mkstemp(prefix=".levi45-", dir=os.path.dirname(path))
    try:
        with os.fdopen(fd, "wb") as fh:
            fh.write(updated)
            fh.flush()
            os.fsync(fh.fileno())
        shutil.copymode(path, temp)
        with open(path, "rb") as fh:
            if hashlib.sha256(fh.read()).hexdigest() != expected_signature:
                raise ValueError("Configuration changed during cleanup; no changes made")
        os.rename(temp, path)
    finally:
        if os.path.exists(temp):
            os.unlink(temp)
    return backup, len(ranges)


def _generated_disabled_reader_labels(path):
    """Read only uniquely labelled disabled readers inside generated markers."""
    if not path or not os.path.isfile(path) or os.path.islink(path):
        return []
    with open(path, 'rb') as fh:
        lines = fh.read().decode('latin1').splitlines()
    try:
        blocks = [lines[a:b] for a, b in _managed_reader_blocks(lines)]
    except ValueError:
        return []
    labels = []
    for block in blocks:
        names = [m.group(1).strip() for line in block
                 for m in [re.match(r'^\s*label\s*=\s*([^#;\r\n]+)', line, re.I)] if m]
        enables = [m.group(1).strip() for line in block
                   for m in [re.match(r'^\s*enable\s*=\s*([^#;\r\n]+)', line, re.I)] if m]
        if len(names) == 1 and enables == ['0']:
            labels.append(names[0])
    counts = {}
    for label in labels:
        counts[label.lower()] = counts.get(label.lower(), 0) + 1
    return [label for label in labels if counts[label.lower()] == 1]


def _enable_selected_generated_readers(path, selected, expected_signature):
    """Backup and enable only uniquely labelled, currently disabled generated readers."""
    import hashlib
    import tempfile
    if not path or not os.path.isfile(path) or os.path.islink(path):
        raise ValueError('OSCam configuration file is missing or unsafe')
    with open(path, 'rb') as fh:
        original = fh.read()
    if hashlib.sha256(original).hexdigest() != expected_signature:
        raise ValueError('Configuration changed since selection; reopen Enable Manager')
    lines = original.decode('latin1').splitlines(True)
    blocks = _managed_reader_blocks(lines)
    wanted = set(label.lower() for label in selected)
    found = {}
    for start, end in blocks:
        names = [m.group(1).strip().lower() for line in lines[start:end]
                 for m in [re.match(r'^\s*label\s*=\s*([^#;\r\n]+)', line, re.I)] if m]
        if len(names) == 1 and names[0] in wanted:
            found.setdefault(names[0], []).append((start, end))
    if set(found) != wanted or any(len(v) != 1 for v in found.values()):
        raise ValueError('Reader labels are missing or duplicated; no changes made')
    changes = {}
    for label, ranges in found.items():
        start, end = ranges[0]
        enabled = [(i, m.group(1).strip()) for i in range(start, end)
                   for m in [re.match(r'^\s*enable\s*=\s*([^#;\r\n]+)', lines[i], re.I)] if m]
        if len(enabled) != 1 or enabled[0][1] != '0':
            raise ValueError('Reader is not explicitly disabled; no changes made')
        i = enabled[0][0]
        changes[i] = re.sub(r'(?i)^(\s*enable\s*=\s*)0(?=\s*(?:[#;]|$))',
                            r'\g<1>1', lines[i].rstrip('\r\n')) + ('\r\n' if lines[i].endswith('\r\n') else '\n')
    updated = ''.join(changes.get(i, line) for i, line in enumerate(lines)).encode('latin1')
    if updated == original:
        raise ValueError('No changes to save')
    stamp = datetime.datetime.now().strftime('%Y%m%d-%H%M%S')
    backup = path + '.levi45-backup-' + stamp
    if os.path.exists(backup):
        raise ValueError('Backup already exists; retry in one second')
    shutil.copy2(path, backup)
    fd, temp = tempfile.mkstemp(prefix='.levi45-', dir=os.path.dirname(path))
    try:
        with os.fdopen(fd, 'wb') as fh:
            fh.write(updated)
            fh.flush()
            os.fsync(fh.fileno())
        shutil.copymode(path, temp)
        with open(path, 'rb') as fh:
            if hashlib.sha256(fh.read()).hexdigest() != expected_signature:
                raise ValueError('Configuration changed during edit; backup saved, no changes made')
        os.rename(temp, path)
    finally:
        if os.path.exists(temp):
            os.unlink(temp)
    return backup, len(wanted)


class Levi45PruneReviewScreen(Screen):
    """Read-only, skinned review list; compatible with Python 2/3 Enigma2."""
    def __init__(self, session, items, summary, details=None, config_path=None, scan_signature=None):
        W, H = S(850), S(780)
        self.skin = (
            '<screen name="Levi45PruneReviewScreen" position="center,center" '
            'size="{w},{h}" title="Levi45 Free Server - Smart Prune" backgroundColor="#23343e">'
            '<eLabel position="0,0" size="{w},{header}" backgroundColor="#0b3d5c" zPosition="-1" />'
            '<widget name="heading" position="{pad},{top}" size="{inner},{row}" font="Regular;{font}" '
            'foregroundColor="#ffffff" transparent="1" />'
            '<eLabel position="{pad},{summary_y}" size="{inner},{summary_h}" backgroundColor="#182830" zPosition="-1" />'
            '<widget name="summary" position="{text_x},{summary_text_y}" size="{text_w},{summary_text_h}" '
            'font="Regular;{small}" foregroundColor="#a7d8ff" transparent="1" />'
            '<eLabel position="{pad},{list_y}" size="{inner},{list_h}" backgroundColor="#101820" zPosition="-1" />'
            '<widget name="readers" position="{text_x},{list_text_y}" size="{text_w},{list_text_h}" '
            'font="Regular;{small}" foregroundColor="#ffffff" '
            'transparent="1" zPosition="2" />'
            '<eLabel position="0,{footer_y}" size="{w},{footer_h}" backgroundColor="#0b3d5c" zPosition="-1" />'
            '<widget name="help" position="{pad},{help_y}" size="{inner},{row}" '
            'font="Regular;{small}" foregroundColor="#ffd766" transparent="1" halign="center" />'
            '</screen>'
        ).format(w=W, h=H, header=S(85), pad=S(20), inner=W-S(40), top=S(22),
                 row=S(45), font=S(29), small=S(23), summary_y=S(100),
                 summary_h=S(165), text_x=S(35), text_w=W-S(70),
                 summary_text_y=S(113), summary_text_h=S(145), list_y=S(280),
                 list_h=H-S(370), list_text_y=S(295), list_text_h=H-S(400),
                 footer_y=H-S(75), footer_h=S(75), help_y=H-S(60))
        Screen.__init__(self, session)
        self._review_entries = list(items or [])
        self._review_details = details or {}
        self._config_path = config_path
        self._scan_signature = scan_signature
        self._selected_for_disable = set()
        self["heading"] = Label("Levi45 Free Server  |  Smart Prune  v" + PLUGIN_VERSION)
        self["summary"] = Label(e2_native_text(summary))
        self._review_index = 0
        self["readers"] = Label("")
        self._refresh_review()
        self["help"] = Label("GREEN Details  YELLOW Eligible  BLUE Clean All  EXIT Close")
        self["actions"] = ActionMap(["OkCancelActions", "ColorActions", "DirectionActions"],
            {"ok": self.show_details, "cancel": self.close, "red": self.close,
             "green": self.show_details, "yellow": self.review_selection, "blue": self.request_disable,
             "up": self._review_up, "down": self._review_down,
             "left": self._review_page_up, "right": self._review_page_down}, -1)

    def _refresh_review(self):
        if not self._review_entries:
            self["readers"].setText("No readers to review")
            return
        # Keep only a short page of text in the native label widget.
        page_size = 9
        start = (self._review_index // page_size) * page_size
        rows = []
        for index in range(start, min(start + page_size, len(self._review_entries))):
            label, status = self._review_entries[index]
            selected = "*" if self._eligible(label, status) else " "
            marker = ">" if index == self._review_index else " "
            marker += selected + " "
            rows.append("{}{}. {}  [{}]".format(marker, index + 1, label, status))
        rows.append("\nReader {} of {}".format(self._review_index + 1, len(self._review_entries)))
        self["readers"].setText(e2_native_text("\n".join(rows)))

    def _review_move(self, amount):
        if self._review_entries:
            self._review_index = max(0, min(len(self._review_entries) - 1, self._review_index + amount))
            self._refresh_review()

    def _review_up(self):
        self._review_move(-1)

    def _review_down(self):
        self._review_move(1)

    def _review_page_up(self):
        self._review_move(-9)

    def _review_page_down(self):
        self._review_move(9)

    def _eligible(self, label, status):
        detail = self._review_details.get(label, {})
        raw = str(detail.get('raw', '')).upper().strip()
        # WebIf Unknown includes readers missing from a valid status snapshot.
        # Ambiguous labels and TCP-only results never qualify for this cleanup.
        if detail.get('count', 1) != 1 and not detail.get('group_cleanup'):
            return False
        if raw == '(AMBIGUOUS)':
            return False
        if status == 'Offline (WebIf)':
            return detail.get('matched') is True
        if status == 'Unknown':
            return (detail.get('matched') is True or
                    (raw == '(NOT PRESENT)' and detail.get('matched') is False))
        return False

    def toggle_selection(self):
        if not self._review_entries:
            return
        label, status = self._review_entries[self._review_index]
        if not self._eligible(label, status):
            self.session.open(MessageBox, "Offline, Error and Unknown WebIf readers can be selected.\nOnline, ambiguous labels and TCP-only results are protected.", MessageBox.TYPE_INFO, timeout=7)
            return
        if label in self._selected_for_disable:
            self._selected_for_disable.remove(label)
        else:
            self._selected_for_disable.add(label)
        self._refresh_review()

    def review_selection(self):
        labels = self._eligible_labels()
        msg = ("Eligible for PERMANENT CLEANUP: {}\n\n".format(len(labels)) +
               ("\n".join(labels[:18]) if labels else "No eligible readers."))
        if len(labels) > 18:
            msg += "\n... and {} more".format(len(labels) - 18)
        self.session.open(MessageBox, e2_native_text(msg), MessageBox.TYPE_INFO)

    def _eligible_labels(self):
        labels = [label for label, status in self._review_entries
                  if self._eligible(label, status)]
        # Delete a repeated managed label only if every reviewed occurrence qualifies.
        return sorted(label for label in set(labels)
                      if all(self._eligible(item, status) for item, status in self._review_entries
                             if item == label))

    def request_disable(self):
        labels = self._eligible_labels()
        if not labels:
            self.session.open(MessageBox,
                "No Offline, Error or Unknown WebIf readers eligible for cleanup.",
                MessageBox.TYPE_INFO)
            return
        if not self._config_path or not self._scan_signature:
            self.session.open(MessageBox, "No verified server file. Rescan first.",
                              MessageBox.TYPE_ERROR)
            return
        self.session.openWithCallback(self._confirm_cleanup, MessageBox,
            e2_native_text("PERMANENTLY DELETE {} inactive Levi45 readers?\n\n"
                "Offline, Error and Unknown readers inside Levi45 markers.\n"
                "Any duplicate group containing an Online reader stays untouched.\n"
                "A timestamped backup will be created first.\n\n"
                "Unknown can include working readers absent from WebIf.\n"
                "Proceed?".format(sum(1 for label, _ in self._review_entries if label in labels))), MessageBox.TYPE_YESNO)

    def _confirm_cleanup(self, confirmed):
        if not confirmed:
            return
        labels = self._eligible_labels()
        try:
            backup, count = _delete_generated_inactive_readers(
                self._config_path, labels, self._scan_signature)
        except Exception as exc:
            self.session.open(MessageBox,
                e2_native_text("No readers deleted:\n" + str(exc)),
                MessageBox.TYPE_ERROR)
            return
        self.session.open(MessageBox,
            e2_native_text("Removed {} reader blocks.\nBackup: {}\n\n"
                "Restart your selected softcam and rescan to refresh.".format(count, backup)),
            MessageBox.TYPE_INFO)

    def show_details(self):
        if not self._review_entries:
            return
        label, status = self._review_entries[self._review_index]
        detail = self._review_details.get(label, {})
        raw = detail.get("raw", "(not available)")
        matched = "Yes" if detail.get("matched") else "No"
        reason = detail.get("reason", "No diagnostic details available.")
        entries = detail.get("entries", [])
        count = detail.get("count", len(entries))
        raw_states = ", ".join(str(entry.get("raw", "?")) for entry in entries[:8])
        if len(entries) > 8:
            raw_states += ", ..."
        message = ("Reader: {}\nStatus: {}\nWebIf connection: {}\n"
                   "WebIf label matched: {}\nXML entries: {}\nStates: {}\n"
                   "Reason: {}\n\nSnapshot only. No changes made.").format(
                       label, status, raw, matched, count, raw_states or "(none)", reason)
        self.session.open(MessageBox, e2_native_text(message),
                          MessageBox.TYPE_INFO, timeout=15)


class Levi45EnableManagerScreen(Levi45PruneReviewScreen):
    """Re-enable previously disabled generated readers, independent of WebIf state."""
    def __init__(self, session, path, labels):
        import hashlib
        with open(path, 'rb') as fh:
            signature = hashlib.sha256(fh.read()).hexdigest()
        self._enable_path = path
        self._enable_signature = signature
        items = [(label, 'Disabled (config)') for label in labels]
        Levi45PruneReviewScreen.__init__(self, session, items,
            'Enable Manager (manual restore)\nDisabled readers: {}\nNo changes until confirmed.'.format(len(labels)),
            config_path=path, scan_signature=signature)
        self['heading'].setText('Levi45 Free Server  |  Enable Manager  v' + PLUGIN_VERSION)
        self['help'].setText('GREEN Select   YELLOW Review   BLUE Enable   OK Details   EXIT Close')
        self._selected_for_disable = set()
        self['actions'] = ActionMap(['OkCancelActions', 'ColorActions', 'DirectionActions'],
            {'ok': self.show_details, 'cancel': self.close, 'red': self.close,
             'green': self.toggle_selection, 'yellow': self.review_selection,
             'blue': self.request_enable, 'up': self._review_up, 'down': self._review_down,
             'left': self._review_page_up, 'right': self._review_page_down}, -1)

    def _eligible(self, label, status):
        return status == 'Disabled (config)'

    def toggle_selection(self):
        if not self._review_entries:
            return
        label = self._review_entries[self._review_index][0]
        if label in self._selected_for_disable:
            self._selected_for_disable.remove(label)
        else:
            self._selected_for_disable.add(label)
        self._refresh_review()

    def review_selection(self):
        labels = sorted(self._selected_for_disable)
        msg = 'Selected for ENABLING: {}\n\n{}'.format(len(labels),
            '\n'.join(labels[:18]) if labels else 'Nothing selected.')
        self.session.open(MessageBox, e2_native_text(msg), MessageBox.TYPE_INFO)

    def show_details(self):
        if self._review_entries:
            label = self._review_entries[self._review_index][0]
            self.session.open(MessageBox, e2_native_text('Reader: {}\nConfiguration: enable = 0\n\nGREEN selects for restoring to enable = 1.\nNo changes made.'.format(label)), MessageBox.TYPE_INFO)

    def request_enable(self):
        if not self._selected_for_disable:
            self.session.open(MessageBox, 'Select disabled readers with GREEN first.', MessageBox.TYPE_INFO)
            return
        self.session.openWithCallback(self._confirm_enable, MessageBox,
            e2_native_text('ENABLE {} selected readers?\n\nA timestamped backup will be created first.\nRestart OSCam to apply.\n\nProceed?'.format(len(self._selected_for_disable))),
            MessageBox.TYPE_YESNO)

    def _confirm_enable(self, confirmed):
        if not confirmed:
            return
        try:
            backup, count = _enable_selected_generated_readers(
                self._enable_path, self._selected_for_disable, self._enable_signature)
        except Exception as exc:
            self.session.open(MessageBox, e2_native_text('No changes made:\n' + str(exc)), MessageBox.TYPE_ERROR)
            return
        self._selected_for_disable.clear()
        self.session.open(MessageBox, e2_native_text('Enabled {} readers.\nBackup: {}\n\nRestart OSCam to apply. Close and rescan to refresh.'.format(count, backup)), MessageBox.TYPE_INFO)
        self.close()


class Levi45CaptchaScreen(Screen):
    """Own layout: the question must remain visible even on titleless skins."""
    def __init__(self, session, question):
        width, height = S(760), S(310)
        self.skin = (
            '<screen name="Levi45CaptchaScreen" position="center,center" '
            'size="{w},{h}" title="Dhoom CAPTCHA" backgroundColor="#101820">'
            '<widget name="captcha_question" position="{x},{qy}" size="{inner},{qh}" '
            'font="Regular;{qfont}" foregroundColor="#ffffff" backgroundColor="#101820" '
            'halign="center" valign="center" />'
            '<widget name="input" position="{x},{iy}" size="{inner},{ih}" '
            'font="Regular;{ifont}" foregroundColor="#ffffff" backgroundColor="#263747" '
            'halign="center" valign="center" />'
            '<widget name="captcha_help" position="{x},{hy}" size="{inner},{hh}" '
            'font="Regular;{hfont}" foregroundColor="#ffd766" backgroundColor="#101820" '
            'halign="center" valign="center" />'
            '</screen>'
        ).format(w=width, h=height, x=S(25), inner=width-S(50),
                 qy=S(25), qh=S(90), qfont=S(32),
                 iy=S(130), ih=S(65), ifont=S(36),
                 hy=S(215), hh=S(70), hfont=S(23))
        Screen.__init__(self, session)
        self._captcha_answer = ""
        self["input"] = Label("_")
        self.skinName = ["Levi45CaptchaScreen"]
        self["captcha_question"] = Label(e2_native_text(question))
        self["captcha_help"] = Label("0-9: enter   LEFT: erase   OK: submit   EXIT: cancel")
        actions = {str(number): self._captcha_digit for number in range(10)}
        actions.update({"ok": self._captcha_submit, "cancel": self._captcha_cancel,
                        "left": self._captcha_erase,
                        "deleteBackward": self._captcha_erase,
                        "deleteForward": self._captcha_erase})
        self["captcha_actions"] = NumberActionMap(
            ["NumberActions", "OkCancelActions", "DirectionActions", "InputBoxActions"],
            actions, -2)

    def _captcha_digit(self, number):
        if len(self._captcha_answer) < getattr(self, "_captcha_limit", 2):
            self._captcha_answer += str(number)
            self["input"].setText(self._captcha_answer)

    def _captcha_erase(self):
        self._captcha_answer = self._captcha_answer[:-1]
        self["input"].setText(self._captcha_answer or "_")

    def _captcha_submit(self):
        if self._captcha_answer:
            self.close(self._captcha_answer)

    def _captcha_cancel(self):
        self.close(None)


class Levi45ImageCaptchaScreen(Levi45CaptchaScreen):
    def __init__(self, session, image_path):
        Levi45CaptchaScreen.__init__(self, session, "")
        self._captcha_limit = 3
        self._captcha_image_path = image_path
        self.skinName = ["Levi45ImageCaptchaScreen"]
        self.skin = self.skin.replace('name="Levi45CaptchaScreen"', 'name="Levi45ImageCaptchaScreen"')
        widget = ('<widget name="captcha_image" position="{x},{y}" size="{w},{h}" '
                  'alphatest="on" scale="1" />').format(
                      x=S(230), y=S(25), w=S(300), h=S(90))
        self.skin = self.skin.replace('</screen>', widget + '</screen>')
        self["captcha_image"] = Pixmap()
        self.onLayoutFinish.append(self._show_captcha_image)

    def _show_captcha_image(self):
        self["captcha_image"].instance.setPixmapFromFile(self._captcha_image_path)


class Levi45FreeServerScreen(Screen):
    def __init__(self, session, args=None):
        # Keep the complete main window inside the usable display area.
        S = lambda value: max(1, int(round(globals()["S"](value) * 0.88)))
        W = S(900)
        H = S(940)          # was 920 — a touch taller for the QR strip
        X = S(20)
        CW = W - 2 * X

        # QR strip layout
        QR_SIZE = S(170)                     # ~100 x 100 px on HD (1280x720)
        FOOT_Y  = H - S(245)                 # taller footer to fit complete QR codes
        FOOT_H  = H - FOOT_Y                 # footer height (about 220 design units)
        SUP_Y   = FOOT_Y + S(12)             # support title above QR images
        SUP_H   = S(40)
        QR_Y    = FOOT_Y + S(70)             # QR images fit fully inside footer on HD
        # center the two images with a gap between them
        GAP     = S(140)
        total_w = 2 * QR_SIZE + GAP
        QR1_X   = (W - total_w) // 2
        QR2_X   = QR1_X + QR_SIZE + GAP

        self.skin = (
            '<screen name="Levi45FreeServerScreen" position="center,center" '
            'size="{w},{h}" title="Levi45 Free Server">'

            '<eLabel position="0,0" size="{w},{th}" backgroundColor="#0b3d5c" zPosition="-1" />'
            '<widget name="title_label" position="{x0},{y_t}" size="{tw},{h_t}" '
            'font="Regular;{f_t}" foregroundColor="#ffffff" transparent="1" />'
            '<widget name="version_label" position="{vx},{y_t}" size="{vw},{h_t}" '
            'font="Regular;{f_v}" foregroundColor="#a7d8ff" transparent="1" halign="right" />'

            '<eLabel position="{x},{y_st_box}" size="{cw},{h_st_box}" backgroundColor="#101820" zPosition="-1" />'
            '<widget name="status_label" position="{x},{y_st}" size="{cw},{h_st}" '
            'font="Regular;{f_st}" foregroundColor="#e0f2ff" transparent="1" valign="top" halign="left" />'

            '<eLabel position="{x},{y_sm_box}" size="{cw},{h_sm_box}" backgroundColor="#182830" zPosition="-1" />'
            '<widget name="summary_label" position="{x},{y_sm}" size="{cw},{h_sm}" '
            'font="Regular;{f_sm}" foregroundColor="#a7d8ff" transparent="1" valign="top" halign="left" />'

            '<eLabel position="{x},{y_kbox}" size="{cw},{h_kbox}" backgroundColor="#0f1a22" zPosition="-1" />'

            '<eLabel position="{kx1},{ky1}" size="{kbw},{kbh}" backgroundColor="#0088ff" />'
            '<widget name="key_blue" position="{ktx},{ky1}" size="{ktw},{kbh}" '
            'font="Regular;{f_k}" foregroundColor="#ffffff" transparent="1" />'

            '<eLabel position="{kx1},{ky2}" size="{kbw},{kbh}" backgroundColor="#22aa44" />'
            '<widget name="key_green" position="{ktx},{ky2}" size="{ktw},{kbh}" '
            'font="Regular;{f_k}" foregroundColor="#ffffff" transparent="1" />'

            '<eLabel position="{kx1},{ky3}" size="{kbw},{kbh}" backgroundColor="#d8c000" />'
            '<widget name="key_yellow" position="{ktx},{ky3}" size="{ktw},{kbh}" '
            'font="Regular;{f_k}" foregroundColor="#ffffff" transparent="1" />'

            '<eLabel position="{kx1},{ky4}" size="{kbw},{kbh}" backgroundColor="#cc2222" />'
            '<widget name="key_red" position="{ktx},{ky4}" size="{ktw},{kbh}" '
            'font="Regular;{f_k}" foregroundColor="#ffffff" transparent="1" />'

            '<eLabel position="{kx1},{ky5}" size="{kbw},{kbh}" backgroundColor="#888888" />'
            '<widget name="key_menu" position="{ktx},{ky5}" size="{ktw},{kbh}" '
            'font="Regular;{f_k}" foregroundColor="#ffffff" transparent="1" />'

            '<eLabel position="0,{y_foot}" size="{w},{h_foot}" backgroundColor="#0b3d5c" zPosition="-1" />'
            '<widget name="support" position="{x},{y_sup}" size="{cw},{h_sup}" '
            'font="Regular;{f_sup}" foregroundColor="#ffd766" transparent="1" halign="center" />'

            '<ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/Levi45FreeServer/images/kofi.png" '
            'position="{i1x},{iy}" size="{iw},{ih}" zPosition="5" />'
            '<ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/Levi45FreeServer/images/paypal.png" '
            'position="{i2x},{iy}" size="{iw},{ih}" zPosition="5" />'

            '</screen>'
        ).format(
            w=W, h=H,
            th=S(70),
            x0=S(30), y_t=S(18), tw=S(720), h_t=S(40),
            vx=S(740), vw=S(140), f_t=S(28), f_v=S(24),

            x=X, cw=CW,
            y_st_box=S(85), h_st_box=S(240),
            y_st=S(100), h_st=S(210), f_st=S(24),

            y_sm_box=S(335), h_sm_box=S(95),
            y_sm=S(348), h_sm=S(70), f_sm=S(22),

            y_kbox=S(440), h_kbox=S(260),

            kx1=S(40), ktx=S(75), kbw=S(18), kbh=S(34),
            ktw=S(780),
            ky1=S(458), ky2=S(505), ky3=S(552), ky4=S(599), ky5=S(646),
            f_k=S(24),

            y_foot=FOOT_Y, h_foot=FOOT_H,
            y_sup=SUP_Y, h_sup=SUP_H, f_sup=S(28),

            i1x=QR1_X, i2x=QR2_X, iy=QR_Y, iw=QR_SIZE, ih=QR_SIZE)

        Screen.__init__(self, session)

        self["title_label"]   = Label(PLUGIN_TITLE + "  |  satellite-forum.com")
        self["version_label"] = Label("v" + PLUGIN_VERSION)
        self["status_label"]  = Label("Ready to download free servers...")
        self["summary_label"] = Label("Readers: --   Connected: --   Errors: --   Unknown/OFF: --")

        self["key_blue"]   = Label("Blue   -  Download & save as CCcam")
        self["key_green"]  = Label("Green  -  Download & save as OSCam")
        self["key_yellow"] = Label("Yellow -  Download & save as NCam")
        self["key_red"]    = Label("Red    -  Force immediate download")
        self["key_menu"]   = Label("Menu   -  Prune inactive servers / Settings")
        self["support"]    = Label("Please Support if you like the plugin")

        self["actions"] = ActionMap(
            ["ColorActions", "OkCancelActions", "MenuActions", "SetupActions"],
            {
                "blue":   self.start_download_cccam,
                "green":  self.start_download_oscam,
                "yellow": self.start_download_ncam,
                "red":    self.force_immediate_download,
                "cancel": self.close,
                "menu":   self.open_main_menu,
            }, -1)

        self.servers_to_save = []
        self.scrape_index = 0
        self.format_choice = "cccam"

        self._prune_poller = None
        self._prune_running = False
        self._reader_stats = {"total": 0, "connected": 0, "errors": 0, "unknown": 0}

        self.check_timer = eTimer()
        try:
            self._check_timer_connection = connect_e2_timer(self.check_timer, self.check_auto_download)
        except Exception as exc:
            log("Auto-download timer hookup failed: {}".format(exc))

        self.check_timer.start(60000, False)
        self.onClose.append(self._stop_dreamos_timers)

        try:
            if config.plugins.Levi45FreeServer.checkinactive.value in ("2", "3"):
                self.startup_timer = eTimer()
                self._startup_timer_connection = connect_e2_timer(self.startup_timer, self._startup_prune)
                self.startup_timer.start(5000, True)
        except Exception as e:
            log("Could not set up startup prune timer: {}".format(e))

        self.refresh_summary()

        try:
            with open(LOG_FILE, "a") as f:
                f.write("[{}] Plugin started (v{}, scale={:.2f})\n".format(
                    datetime.datetime.now(), PLUGIN_VERSION, SCALE))
        except Exception as e:
            print("Failed to write to log file: {}".format(e))

    def _stop_dreamos_timers(self):
        """Avoid callbacks to a destroyed screen on DreamOS and Enigma2."""
        if getattr(self, "_trial_poller", None):
            self._trial_poller.stop()
        for timer_name in ("check_timer", "startup_timer"):
            timer = getattr(self, timer_name, None)
            if timer is not None:
                try:
                    timer.stop()
                except Exception:
                    pass

    def open_main_menu(self):
        menu_items = [
            ("Prune Inactive Servers  (Check & Remove)", "prune"),
            ("CCcamIPTV 24h trial (manual request)",        "trial"),
            ("FullPackage 24h trial (manual request)",      "fullpackage"),
            ("Dhoom 24h trial (enter CAPTCHA)",             "dhoom"),
            ("CCcamNinja 24h trial (manual request)",       "ninja"),
            ("Testcline trial (image CAPTCHA)",            "testcline"),
            ("Settings",                                 "settings"),
            ("Cancel",                                   "cancel"),
        ]
        self.session.openWithCallback(self._main_menu_chosen, ChoiceBox,
                                      _("Levi45 Free Server"), menu_items)

    def _main_menu_chosen(self, choice):
        if not choice:
            return
        key = choice[1]
        if key == "prune":
            self.prune_now()
        elif key in ("trial", "fullpackage", "dhoom", "ninja", "testcline"):
            self.open_trial("cccamiptv" if key == "trial" else key)
        elif key == "settings":
            self.open_settings()

    def open_trial(self, provider="cccamiptv"):
        if getattr(self, "_trial_busy", False):
            return
        self._trial_provider = provider
        self._trial_name = {"fullpackage": "FullPackage", "cccamiptv": "CCcamIPTV", "dhoom": "Dhoom", "ninja": "CCcamNinja", "testcline": "Testcline"}[provider]
        prompt = "Request CCcamIPTV 24h trial (one per visitor). Save as:"
        if provider == "fullpackage":
            prompt = "FullPackage: IP bound, no reshare, single channel.\nChoose format to accept rules and request (29s wait):"
        if provider == "ninja":
            prompt = "CCcamNinja 24h trial (one line per IP). Save as:"
        if provider == "dhoom":
            prompt = "Dhoom manual trial: answer CAPTCHA with your remote. Save as:"
        if provider == "testcline":
            self.session.openWithCallback(
                self._testcline_server_chosen, ChoiceBox,
                "Testcline: remove expired lines from your box.\nChoose server to accept agreement (30s wait):",
                [("Public server base {}".format(i + 1), i) for i in range(4)])
            return
        self.session.openWithCallback(
            self._trial_format_chosen, ChoiceBox, prompt,
            [("CCcam", "cccam"), ("OSCam", "oscam"), ("NCam", "ncam")])

    def _testcline_server_chosen(self, choice):
        if not choice:
            return
        self._testcline_server = choice[1]
        self.session.openWithCallback(
            self._trial_format_chosen, ChoiceBox, "Testcline: save as:",
            [("CCcam", "cccam"), ("OSCam", "oscam"), ("NCam", "ncam")])

    def _trial_format_chosen(self, choice):
        if not choice or getattr(self, "_trial_busy", False):
            return
        self._trial_format = choice[1]
        self._trial_path = get_path_for_softcam(self._trial_format)
        self._trial_busy = True
        self["status_label"].setText("Requesting {} trial...\n{}No automatic retries.".format(
            self._trial_name, "Provider wait: 30 seconds.\n" if self._trial_provider == "testcline" else ("Provider wait: 29 seconds.\n" if self._trial_provider == "fullpackage" else "Please wait.\n")))
        poller = ThreadedProgressPoller(self)
        self._trial_poller = poller
        poller.set_finished_handler(self._dhoom_prepared if self._trial_provider in ("dhoom", "testcline") else self._trial_received)
        poller.start()

        def worker():
            try:
                if self._trial_provider == "testcline":
                    from .trial import TestclineTrial
                    trial = TestclineTrial("/etc/enigma2/levi45-testcline.cookies", self._testcline_server)
                    try:
                        image_path = trial.prepare()
                    except Exception:
                        trial.cleanup()
                        raise
                    poller.post_finished(((trial, image_path), ""))
                    return
                if self._trial_provider == "dhoom":
                    from .trial import DhoomTrial
                    trial = DhoomTrial("/etc/enigma2/levi45-dhoom.cookies")
                    question = trial.prepare()
                    poller.post_finished(((trial, question), ""))
                    return
                from .trial import request_trial, request_fullpackage, request_ninja
                request = {"cccamiptv": request_trial, "fullpackage": request_fullpackage, "ninja": request_ninja}[self._trial_provider]
                line = request("/etc/enigma2/levi45-{}.cookies".format(self._trial_provider))
                poller.post_finished((line, ""))
            except Exception as exc:
                poller.post_finished((None, str(exc)))
        thread = threading.Thread(target=worker)
        thread.daemon = True
        thread.start()

    def _dhoom_prepared(self, payload, error):
        if error:
            self._trial_received(None, error)
            return
        self._dhoom_session, question = payload
        dialog = Levi45ImageCaptchaScreen if self._trial_provider == "testcline" else Levi45CaptchaScreen
        self.session.openWithCallback(
            self._dhoom_answered, dialog, question)

    def _dhoom_answered(self, answer):
        if answer is None or not str(answer).strip():
            if hasattr(self._dhoom_session, "cleanup"):
                self._dhoom_session.cleanup()
            self._dhoom_session = None
            self._trial_busy = False
            self["status_label"].setText("Trial cancelled. Existing readers unchanged.")
            return
        answer = str(answer).strip()
        trial = self._dhoom_session
        self._dhoom_session = None
        self["status_label"].setText("Submitting your CAPTCHA answer...")
        poller = ThreadedProgressPoller(self)
        self._trial_poller = poller
        poller.set_finished_handler(self._trial_received)
        poller.start()

        def worker():
            try:
                poller.post_finished((trial.submit(answer), ""))
            except Exception as exc:
                poller.post_finished((None, str(exc)))
            finally:
                if hasattr(trial, "cleanup"):
                    trial.cleanup()
        thread = threading.Thread(target=worker)
        thread.daemon = True
        thread.start()

    def _trial_received(self, line, error):
        self._trial_busy = False
        if error:
            self["status_label"].setText("Trial request failed. Existing readers unchanged.")
            self.session.open(MessageBox, error, MessageBox.TYPE_ERROR)
            return
        try:
            from .trial import save_trial
            content = line if self._trial_format == "cccam" else convert_to_oscam_reader(line)
            if not content:
                raise ValueError("Cannot convert the trial line.")
            save_trial(self._trial_path, content, self._trial_provider)
            self["status_label"].setText(
                "24h trial saved as {}.\n{}\nRestart your softcam to use it.\nOther readers preserved; backup: .trial.bak".format(
                    self._trial_format.upper(), self._trial_path))
            self.refresh_summary()
        except Exception as exc:
            self.session.open(MessageBox, "Cannot save trial: " + str(exc), MessageBox.TYPE_ERROR)

    def _count_readers_in_file(self):
        stats = {"total": 0, "connected": 0, "errors": 0, "unknown": 0}
        try:
            softcam = config.plugins.Levi45FreeServer.softcam.value
            file_path = get_path_for_softcam(softcam)
            if not file_path or not os.path.exists(file_path):
                return stats
            with open(file_path, "r") as f:
                content = f.read()
            lines = content.splitlines()
            block_lines = [line for a, b in _managed_ranges(lines) for line in lines[a + 1:b]]
            if block_lines is None:
                return stats
            if softcam in ("oscam", "ncam"):
                stats["total"] = len([l for l in block_lines if l.strip().lower() == "[reader]"])
            else:
                stats["total"] = len([l for l in block_lines
                                      if _parse_cccam_line(l) or _parse_newcamd_line(l)])
        except Exception as e:
            log("_count_readers_in_file error: {}".format(e))
        return stats

    def refresh_summary(self):
        try:
            softcam = config.plugins.Levi45FreeServer.softcam.value.upper()
            s = self._reader_stats
            if s.get("total", 0) > 0:
                txt = "{} file  |  Total: {}   Connected: {}   Errors: {}   Unknown/OFF: {}".format(
                    softcam, s["total"], s["connected"], s["errors"], s["unknown"])
            else:
                base = self._count_readers_in_file()
                txt = "{} file  |  Total: {}   (Menu to check)".format(
                    softcam, base["total"])
            if "summary_label" in self:
                self["summary_label"].setText(txt)
        except Exception as e:
            log("refresh_summary error: {}".format(e))

    def close(self):
        if self._prune_running:
            self.session.openWithCallback(
                self._confirm_close_during_prune,
                MessageBox,
                _("A prune is still running. Close anyway?"),
                MessageBox.TYPE_YESNO
            )
            return
        Screen.close(self)

    def _confirm_close_during_prune(self, result):
        if result:
            self._prune_running = False
            if self._prune_poller:
                self._prune_poller.stop()
                self._prune_poller = None
            Screen.close(self)

    def check_auto_download(self):
        if not is_autodownload_enabled():
            return
        now = datetime.datetime.now()
        download_time = config.plugins.Levi45FreeServer.downloadtime.value
        scheduled_time_today = datetime.datetime(now.year, now.month, now.day,
                                           download_time[0], download_time[1])
        if last_download_time is None or last_download_time.date() != now.date():
            if now >= scheduled_time_today:
                self.auto_download()
                return
        interval_hours = config.plugins.Levi45FreeServer.downloadinterval.value
        if last_download_time:
            time_diff = (now - last_download_time).total_seconds()
            if time_diff >= interval_hours * 3600:
                self.auto_download()
                return

    def force_immediate_download(self):
        global last_download_time
        last_download_time = None
        self.auto_download()

    def open_settings(self):
        self.session.openWithCallback(self.settingsClosed, Levi45FreeServerSettings)

    def settingsClosed(self, result):
        if result:
            enabled = is_autodownload_enabled()
            active = config.plugins.Levi45FreeServer.softcam.value
            status_text = "Settings saved.\n\nAuto-download: {}\nActive softcam: {}\nActive path: {}".format(
                "ENABLED" if enabled else "DISABLED",
                active.upper(),
                get_path_for_softcam(active))
            try:
                if "status_label" in self:
                    self["status_label"].setText(status_text)
                self.refresh_summary()
            except Exception as e:
                log("Error updating status label: {}".format(e))

    def auto_download(self):
        global last_download_time
        if "status_label" in self:
            self["status_label"].setText("Auto-download in progress...")
        softcam_type = config.plugins.Levi45FreeServer.softcam.value
        last_download_time = datetime.datetime.now()
        save_last_download_time()
        self.start_download(softcam_type)

    def start_download_cccam(self):
        config.plugins.Levi45FreeServer.softcam.value = "cccam"
        sync_active_outputfile()
        write_softcam_state()
        write_outputfile_state()
        self.start_download("cccam")

    def start_download_oscam(self):
        config.plugins.Levi45FreeServer.softcam.value = "oscam"
        sync_active_outputfile()
        write_softcam_state()
        write_outputfile_state()
        self.start_download("oscam")

    def start_download_ncam(self):
        config.plugins.Levi45FreeServer.softcam.value = "ncam"
        sync_active_outputfile()
        write_softcam_state()
        write_outputfile_state()
        self.start_download("ncam")

    def start_download(self, format_choice):
        if "status_label" in self:
            self["status_label"].setText(
                "Starting download for {}...\nPlease wait while sources are scraped.".format(format_choice.upper()))
        self.servers_to_save = []
        self.scrape_index = 0
        self.format_choice = format_choice
        self.scrape_next_url()

    def scrape_next_url(self):
        if self.scrape_index < len(SCRAPE_URLS):
            url_entry = SCRAPE_URLS[self.scrape_index]
            if isinstance(url_entry, dict) and "url_generator" in url_entry:
                url = url_entry["url_generator"]()
                parser_name = url_entry["parser_name"]
            else:
                url = url_entry[0]
                parser_name = url_entry[1]

            if "status_label" in self:
                self["status_label"].setText(
                    "Scraping source {}/{}:\n{}".format(
                        self.scrape_index + 1, len(SCRAPE_URLS), url))

            try:
                cmd = ["curl", "-k", "-s", "-L", "--max-time", "30",
                       "-A", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
                       url]
                if find_executable("curl"):
                    process = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
                    stdout, stderr = process.communicate()
                    download_ok = process.returncode == 0
                    html_content_decoded = stdout.decode('utf-8', 'ignore') if download_ok else ""
                else:
                    html_content_decoded = _http_get(url, timeout=30) or ""
                    download_ok = bool(html_content_decoded)
                    stderr = "HTTP request failed"

                if download_ok:
                    parser_func = PARSERS.get(parser_name)
                    if parser_func:
                        new_servers = parser_func(html_content_decoded)
                        self.servers_to_save.extend(new_servers)
                        if "status_label" in self:
                            self["status_label"].setText(
                                "Scraped source {}/{}\nFound {} servers. Total so far: {}".format(
                                    self.scrape_index + 1, len(SCRAPE_URLS),
                                    len(new_servers), len(self.servers_to_save)))
                else:
                    log("Failed to download from {}: {}".format(url, stderr))
            except Exception as e:
                log("Error executing curl: {}".format(e))

            self.scrape_index += 1
            self.scrape_next_url()
        else:
            self.save_servers_to_file()

    def save_servers_to_file(self):
        if not self.servers_to_save:
            if "status_label" in self:
                self["status_label"].setText("No servers were found.\nCheck /tmp/downloader.log for details.")
            return

        try:
            check_mode = config.plugins.Levi45FreeServer.checkinactive.value
        except Exception:
            check_mode = "0"

        if check_mode in ("1", "3") and self.servers_to_save:
            timeout = config.plugins.Levi45FreeServer.checktimeout.value
            max_workers = config.plugins.Levi45FreeServer.checkthreads.value
            before = len(self.servers_to_save)
            if "status_label" in self:
                self["status_label"].setText(
                    "Reachability check in progress...\nTotal servers: {}\nThreads: {}".format(before, max_workers))

            targets = []
            parsed_idx = []
            for idx, line in enumerate(self.servers_to_save):
                p = _parse_cccam_line(line) or _parse_newcamd_line(line)
                if p:
                    targets.append((len(parsed_idx), p[0], p[1]))
                    parsed_idx.append(idx)

            def prog(done, total, host, port, ok):
                if done == total or done % 5 == 0:
                    if "status_label" in self:
                        try:
                            self["status_label"].setText(
                                "Reachability: {}/{}\n{}:{}\n{}".format(
                                    done, total, host, port,
                                    "OK" if ok else "DEAD"))
                        except Exception:
                            pass

            results = _probe_batch_parallel(targets, timeout, max_workers, progress_cb=prog)

            kept = []
            removed_count = 0
            for local_i, orig_idx in enumerate(parsed_idx):
                if results.get(local_i, False):
                    kept.append(self.servers_to_save[orig_idx])
                else:
                    removed_count += 1
            self.servers_to_save = kept
            after = len(self.servers_to_save)
            log("Scrape reachability check: {} -> {} (removed {})".format(before, after, removed_count))

            if not self.servers_to_save:
                if "status_label" in self:
                    self["status_label"].setText("All scraped servers were unreachable.\nNothing to write.")
                return

        file_path = get_path_for_softcam(self.format_choice)

        try:
            existing_content = ""
            if os.path.exists(file_path):
                with open(file_path, "r") as f:
                    existing_content = f.read()

            if _has_markers(existing_content):
                before_lines, _b, after_lines = _split_file_into_sections(existing_content)
                cleaned_content = "\n".join(before_lines + after_lines)
            else:
                cleaned_content = existing_content

            parent = os.path.dirname(file_path)
            if parent and not os.path.exists(parent):
                try:
                    os.makedirs(parent)
                except:
                    pass

            with open(file_path, "w") as f:
                f.write(cleaned_content.strip())

                if self.format_choice in ("oscam", "ncam"):
                    oscam_servers = [convert_to_oscam_reader(s) for s in self.servers_to_save]
                    oscam_servers = [s for s in oscam_servers if s]
                    if oscam_servers:
                        f.write("\n\n" + START_MARKER + "\n")
                        for server_line in oscam_servers:
                            f.write(server_line + "\n\n")
                        f.write(END_MARKER + "\n")
                else:
                    if self.servers_to_save:
                        f.write("\n\n" + START_MARKER + "\n")
                        for server_line in self.servers_to_save:
                            f.write(server_line + "\n")
                        f.write(END_MARKER + "\n")

            msg = "Success!\n\nAppended {} servers to:\n{}".format(
                len(self.servers_to_save), file_path)
            if "status_label" in self:
                self["status_label"].setText(msg)
            log("Success! Appended {} servers to {}.".format(len(self.servers_to_save), file_path))
            self.refresh_summary()

        except Exception as e:
            if "status_label" in self:
                self["status_label"].setText(
                    "Failed to write to file:\n{}\n\n{}".format(file_path, e))
            log("Failed to write to file {}: {}".format(file_path, e))

    def prune_now(self):
        if self._prune_running:
            self.session.open(MessageBox, _("A prune is already running."),
                              MessageBox.TYPE_INFO, timeout=3)
            return
        active = config.plugins.Levi45FreeServer.softcam.value
        path = get_path_for_softcam(active)
        self.session.openWithCallback(
            self._do_prune,
            MessageBox,
            _("Preview server status (no deletion)?\n\n"
              "Only entries in the plugin-generated block are reviewed.\n"
              "No readers or server files will be changed.\n\n"
              "File: {}\nSoftcam: {}\nPrune Mode: {}\n"
              "Timeout: {}s/server\nThreads: {}").format(
                path, active.upper(),
                config.plugins.Levi45FreeServer.prunemode.value,
                config.plugins.Levi45FreeServer.checktimeout.value,
                config.plugins.Levi45FreeServer.checkthreads.value),
            MessageBox.TYPE_YESNO)

    def _do_prune(self, result):
        if not result:
            return
        if self._prune_running:
            return
        self._prune_scan_path = None
        self._prune_scan_signature = None
        if config.plugins.Levi45FreeServer.softcam.value in ("oscam", "ncam"):
            try:
                import hashlib
                scan_path = get_path_for_softcam(config.plugins.Levi45FreeServer.softcam.value)
                with open(scan_path, "rb") as fh:
                    self._prune_scan_signature = hashlib.sha256(fh.read()).hexdigest()
                self._prune_scan_path = scan_path
            except Exception as exc:
                log("Cleanup unavailable: cannot snapshot server file: {}".format(exc))
        self._prune_running = True
        self._prune_report = None
        self._prune_review_items = []
        active = config.plugins.Levi45FreeServer.softcam.value
        self._reader_stats = {"total": 0, "connected": 0, "errors": 0, "unknown": 0}

        self._prune_poller = ThreadedProgressPoller(self, interval_ms=400)
        self._prune_poller.set_status_handler(self._on_prune_status)
        self._prune_poller.set_finished_handler(self._on_prune_finished)

        def status_cb(text):
            try:
                self._prune_poller.post_status(text)
            except Exception:
                pass

        def finished_cb(checked, removed, error):
            try:
                self._prune_poller.post_finished((checked, removed, error))
            except Exception:
                pass

        if "status_label" in self:
            self["status_label"].setText("Starting prune...\nPlease wait.")

        self._prune_poller.start()
        prune_inactive_servers_threaded(
            softcam=active,
            status_cb=status_cb,
            finished_cb=finished_cb,
            progress_every=5)

    def _on_prune_status(self, text):
        if text.startswith("REVIEW_ITEMS:"):
            try:
                self._prune_review_items = json.loads(text[len("REVIEW_ITEMS:"):])
            except Exception as e:
                log("Review list decode failed: {}".format(e))
            return
        if text.startswith("PREVIEW_REPORT:"):
            try:
                payload = json.loads(text[len("PREVIEW_REPORT:"):])
                self._prune_report = payload["summary"]
                self._prune_review_items = payload["items"]
                self._prune_review_details = payload.get("details", {})
            except Exception:
                self._prune_report = text[len("PREVIEW_REPORT:"):]
            text = self._prune_report
        try:
            if "status_label" in self:
                self["status_label"].setText(e2_native_text(text))
        except Exception as e:
            log("_on_prune_status error: {}".format(e))

    def _on_prune_finished(self, checked, removed, error):
        self._prune_running = False
        self._prune_poller = None

        if error:
            self.session.open(MessageBox, _("Prune failed:\n\n{}").format(error),
                              MessageBox.TYPE_ERROR, timeout=6)
            self.refresh_summary()
            return

        msg = getattr(self, "_prune_report", None) or ("Prune complete.\n\nChecked: {}\nRemoved: {}\nKept:    {}").format(
            checked, removed, max(0, checked - removed))
        if getattr(self, "_prune_review_items", None):
            self.session.open(Levi45PruneReviewScreen, self._prune_review_items, e2_native_text(msg),
                              getattr(self, "_prune_review_details", {}),
                              getattr(self, "_prune_scan_path", None), getattr(self, "_prune_scan_signature", None))
        else:
            self.session.open(MessageBox, msg, MessageBox.TYPE_INFO, timeout=8)
        try:
            if "status_label" in self:
                self["status_label"].setText(e2_native_text(msg))
            self.refresh_summary()
        except Exception:
            pass

    def _prune_review_choice(self, choice):
        if choice and choice[1] == "review":
            items = getattr(self, "_prune_review_items", [])
            if not items:
                self.session.open(MessageBox, "No entries to review.", MessageBox.TYPE_INFO, timeout=5)
                return
            # Enigma2 ChoiceBox scrolls, so 100+ entries need no separate pages.
            entries = [("{}  [{}]".format(label, status), i)
                       for i, (label, status) in enumerate(items)]
            self.session.openWithCallback(self._prune_review_item, ChoiceBox,
                title="Reader status (informational; no deletion)", list=entries)

    def _prune_review_item(self, choice):
        if not choice:
            return
        idx = choice[1]
        try:
            label, status = self._prune_review_items[idx]
            self.session.open(MessageBox,
                "Reader: {}\nStatus: {}\n\nThis is a preliminary status, not proof of failure. No entries were deleted.".format(label, status),
                MessageBox.TYPE_INFO, timeout=10)
        except Exception as e:
            log("Review item error: {}".format(e))

    def _startup_prune(self):
        if self._prune_running:
            return
        active = config.plugins.Levi45FreeServer.softcam.value
        self._prune_running = True
        self._prune_poller = ThreadedProgressPoller(self, interval_ms=500)
        self._prune_poller.set_status_handler(self._on_prune_status)
        self._prune_poller.set_finished_handler(self._on_startup_prune_finished)

        def status_cb(text):
            try:
                self._prune_poller.post_status(text)
            except Exception:
                pass

        def finished_cb(checked, removed, error):
            try:
                self._prune_poller.post_finished((checked, removed, error))
            except Exception:
                pass

        if "status_label" in self:
            self["status_label"].setText("Startup check: scanning for inactive servers...")

        self._prune_poller.start()
        prune_inactive_servers_threaded(
            softcam=active,
            status_cb=status_cb,
            finished_cb=finished_cb,
            progress_every=10)

    def _on_startup_prune_finished(self, checked, removed, error):
        self._prune_running = False
        self._prune_poller = None
        if error:
            log("Startup prune failed: {}".format(error))
            return
        log("Startup prune: checked={}, removed={}".format(checked, removed))
        if "status_label" in self:
            try:
                self["status_label"].setText(
                    "Startup prune complete.\n\nChecked: {}\nRemoved: {}".format(checked, removed))
                self.refresh_summary()
            except Exception:
                pass


try:
    create_cron_script()
    write_softcam_state()
    write_outputfile_state()
    setup_cron_job()
except Exception as e:
    log("Error during plugin initialization: {}".format(e))


def main(session, **kwargs):
    session.open(Levi45FreeServerScreen)


def menu(menuid, **kwargs):
    if menuid == 'mainmenu':
        if config.plugins.Levi45FreeServer.showinmainmenu.value == "1":
            return [(('Levi45 Free Server'), main, 'Levi45 Free Server', 45)]
    return []


def Plugins(**kwargs):
    plugin_list = []
    plugin_list.append(PluginDescriptor(
        icon='images/plugin.png',
        name='Levi45FreeServer',
        description='satellite-forum.com V {}'.format(PLUGIN_VERSION),
        where=PluginDescriptor.WHERE_PLUGINMENU,
        fnc=main))
    plugin_list.append(PluginDescriptor(
        icon='images/plugin.png',
        name='Levi45FreeServer',
        description='satellite-forum.com V {}'.format(PLUGIN_VERSION),
        where=PluginDescriptor.WHERE_MENU,
        fnc=menu))
    plugin_list.append(PluginDescriptor(
        icon='images/plugin.png',
        name='Levi45FreeServer',
        description='satellite-forum.com V {}'.format(PLUGIN_VERSION),
        where=PluginDescriptor.WHERE_EXTENSIONSMENU,
        fnc=main))
    return plugin_list
