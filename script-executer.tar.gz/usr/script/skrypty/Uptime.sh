#!/bin/sh
#crash

uptime
echo ""
exit 0