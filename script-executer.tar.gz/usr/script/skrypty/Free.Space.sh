#!/bin/sh
#crash

df -h
echo ""
exit 0