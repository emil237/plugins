#!/bin/sh
#crash

netstat | grep tcp
netstat | grep unix
echo " "
echo " "