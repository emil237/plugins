#!/bin/sh
#crash

free
echo ""
exit 0