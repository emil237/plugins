#!/bin/sh
#crash

if [ -e /tmp/ecm.info ]; then
	cat /tmp/ecm.info
else
	echo "Brak ECM w /tmp/ecm.info"
fi
echo " "
echo " "
