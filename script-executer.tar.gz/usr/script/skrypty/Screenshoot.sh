#!/bin/sh
#crash

grab -v /tmp/screenshot.png
