#!/bin/sh
#mintaj

/usr/bin/ledcontrol -job fanoff 
echo "FAN : OFF"
echo ""
echo "(Only work e2 mod PKT)"
echo ""
exit 0