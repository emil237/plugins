#!/bin/sh
#crash

newcs_cardinfo()
{
	echo "newcs"
	sleep 1
	echo "sub -1"
	sleep 2
	echo "quit"
	sleep 3
}


if [ -e /tmp/karta.tmp ]; then
	rm /tmp/karta.tmp
fi


	echo "NewCS SmartCard information" >> /tmp/karta.tmp
	newcs_cardinfo | telnet 127.0.0.1 1001  >> /tmp/karta.tmp

	
linia1=`sed -n '21p' /tmp/karta.tmp | awk '{print $2; print $4; print$6; print$9; print$12;}'`
linia2=`sed -n '22p' /tmp/karta.tmp | awk '{print $2; print $4; print$6; print$9; print$12;}'`



echo $linia1
echo $linia2
echo " "
echo " "