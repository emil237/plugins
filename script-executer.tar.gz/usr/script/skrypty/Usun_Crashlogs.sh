#!/bin/sh
#crash

rm -rf /media/hdd/enigma2_crash*