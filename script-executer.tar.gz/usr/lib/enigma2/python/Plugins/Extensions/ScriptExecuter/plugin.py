##
## ScriptExecuter
## by AliAbdul
## mod by crash
##
from Components.ActionMap import ActionMap
from Components.MenuList import MenuList
from os import listdir
from Plugins.Plugin import PluginDescriptor
from Screens.Console import Console
from Screens.Screen import Screen

############################################

class ScriptExecuter(Screen):
	skin = """
	<screen position="150,100" size="420,400" title="Script Executer" >
		<widget name="list" position="0,0" size="420,400" scrollbarMode="showOnDemand" />
	</screen>"""

	def __init__(self, session, args=None):
		Screen.__init__(self, session)
		self.session = session
		
		self["list"] = MenuList([])
		self["actions"] = ActionMap(["OkCancelActions"], {"ok": self.run, "cancel": self.close}, -1)
		
		self.onLayoutFinish.append(self.loadScriptList)

	def loadScriptList(self):
		try:
			list = listdir("/usr/script/skrypty")
			list = [x[:-3] for x in list if x.endswith('.sh')]
		except:
			list = []
		
		self["list"].setList(list)

	def run(self):
		try:
			script = self["list"].getCurrent()
		except:
			script = None
		
		if script is not None:
			title = script
			script = "/usr/script/skrypty/%s.sh" % script
			
			self.session.open(Console, title, cmdlist=[script])

############################################

def main(session, **kwargs):
	session.open(ScriptExecuter)

def menu(menuid, **kwargs):
	if menuid == "camsetup":
		return [(_("Script..."), main, "ScriptExecuter", 45)]
	return []	

def Plugins(**kwargs):
    return [PluginDescriptor(name=_("Skrypty -mod by crash-"), description=_("INFO: Skrypty musza byc w /usr/script/skrypty"), where = PluginDescriptor.WHERE_PLUGINMENU, icon="skrypty.png", fnc=main),
			PluginDescriptor(name=_("Skrypty -mod by crash-"), description=_("INFO: Skrypty musza byc w /usr/script/skrypty"), where = PluginDescriptor.WHERE_EXTENSIONSMENU, icon="skrypty.png", fnc=main)]
